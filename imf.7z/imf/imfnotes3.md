




































www-data@imf:/var/www/html/imfadministrator/uploads$ export TERM=xterm
www-data@imf:/var/www/html/imfadministrator/uploads$ export SHELL=bash
www-data@imf:/var/www/html/imfadministrator/uploads$ stty -a
speed 38400 baud; rows 24; columns 80; line = 0;
intr = ^C; quit = ^\; erase = ^?; kill = ^U; eof = ^D; eol = <undef>;
eol2 = <undef>; swtch = <undef>; start = ^Q; stop = ^S; susp = ^Z; rprnt = ^R;
werase = ^W; lnext = ^V; discard = ^O; min = 1; time = 0;
-parenb -parodd -cmspar cs8 -hupcl -cstopb cread -clocal -crtscts
-ignbrk brkint ignpar -parmrk -inpck -istrip -inlcr -igncr icrnl ixon -ixoff
-iuclc -ixany imaxbel -iutf8
opost -olcuc -ocrnl onlcr -onocr -onlret -ofill -ofdel nl0 cr0 tab0 bs0 vt0 ff0
isig icanon iexten echo echoe echok -echonl -noflsh -xcase -tostop -echoprt
echoctl echoke -flusho -extproc
www-data@imf:/var/www/html/imfadministrator/uploads$ls  
1811027d6690.jpg   3fa253b151c8.gif  8a8db3eebc72.jpg	flag5_abc123def.txt
3a6f3336604f.jpeg  45d46500aa4e.jpg  ae3ad874f9b9.jpeg
www-data@imf:/var/www/html/imfadministrator/uploads$ echo -n "YWdlbnRzZXJ2aWNlc^C
www-data@imf:/var/www/html/imfadministrator/uploads$ ^C
www-data@imf:/var/www/html/imfadministrator/uploads$ echo -n "YWdlbnRzZXJ2aWNlcw 
www-data@imf:/var/www/html/imfadministrator/uploads$ ls
1811027d6690.jpg   3fa253b151c8.gif  8a8db3eebc72.jpg	flag5_abc123def.txt
3a6f3336604f.jpeg  45d46500aa4e.jpg  ae3ad874f9b9.jpeg
www-data@imf:/var/www/html/imfadministrator/uploads$ cat flag5_abc123def.txt 
flag5{YWdlbnRzZXJ2aWNlcw==}
=='-data@imf:/var/www/html/imfadministrator/uploads$ echo -n 'YWdlbnRzZXJ2aWNlcw 
services" 2>/dev/nullww-data@imf:/var/www/html/imfadministrator/uploads$ find / -type f -name "agent 
www-data@imf:/var/www/html/imfadministrator/uploads$ ^C
www-data@imf:/var/www/html/imfadministrator/uploads$ stty rows 57 columns 189
www-data@imf:/var/www/html/imfadministrator/uploads$ 








www-data@imf:/var/www/html/imfadministrator/uploads$ find / -type f -name "agentservices" 2>/dev/null
www-data@imf:/var/www/html/imfadministrator/uploads$ find / -type f -name "agent" 2>/dev/null
/usr/local/bin/agent
/etc/xinetd.d/agent
www-data@imf:/var/www/html/imfadministrator/uploads$ lsb_release -a
No LSB modules are available.
Distributor ID:	Ubuntu
Description:	Ubuntu 16.04.1 LTS
Release:	16.04
Codename:	xenial
www-data@imf:/var/www/html/imfadministrator/uploads$ ss -ltn4
State       Recv-Q Send-Q                                                 Local Address:Port                                                                Peer Address:Port              
LISTEN      0      80                                                         127.0.0.1:3306                                                                           *:*                  
LISTEN      0      64                                                                 *:7788                                                                           *:*                  
LISTEN      0      128                                                                *:22                                                                             *:*                  
www-data@imf:/var/www/html/imfadministrator/uploads$file /usr/local/bin/agent
/usr/local/bin/agent: ELF 32-bit LSB executable, Intel 80386, version 1 (SYSV), dynamically linked, interpreter /lib/ld-linux.so.2, for GNU/Linux 2.6.32, BuildID[sha1]=444d1910b8b99d492e6e79fe2383fd346fc8d4c7, not stripped
www-data@imf:/var/www/html/imfadministrator/uploads$ cat /etc/xinetd.d/agent 
# default: on
# description: The agent server serves agent sessions
# unencrypted agentid for authentication.
service agent
{
       flags          = REUSE
       socket_type    = stream
       wait           = no
       user           = root
       server         = /usr/local/bin/agent
       log_on_failure += USERID
       disable        = no
       port           = 7788
}

www-data@imf:/var/www/html/imfadministrator/uploads$ ps -faux | grep agent
www-data 16456  0.0  0.0  11284   968 pts/0    S+   06:25   0:00  |                           \_ grep agent
www-data@imf:/var/www/html/imfadministrator/uploads$ nc localhost 7788
  ___ __  __ ___ 
 |_ _|  \/  | __|  Agent
  | || |\/| | _|   Reporting
 |___|_|  |_|_|    System


Agent ID : ^C
www-data@imf:/var/www/html/imfadministrator/uploads$ nc localhost 7788 &>/dev/null &
[1] 16460
www-data@imf:/var/www/html/imfadministrator/uploads$ ps -faux | grep agent
root     16461  0.0  0.0   2192   532 ?        Ss   06:25   0:00  \_ agent
www-data 16463  0.0  0.1  11284  1088 pts/0    S+   06:25   0:00  |                           \_ grep agent
www-data@imf:/var/www/html/imfadministrator/uploads$ ls -l /usr/local/bin/agent
-rwxr-xr-x 1 root root 11896 Oct 12  2016 /usr/local/bin/agent

[1]+  Stopped                 nc localhost 7788 &> /dev/null
www-data@imf:/var/www/html/imfadministrator/uploads$#getcap !
www-data@imf:/var/www/html/imfadministrator/uploads$ getcat /usr/local/bin/agent
No command 'getcat' found, did you mean:
 Command 'gencat' from package 'libc-dev-bin' (main)
 Command 'petcat' from package 'vice' (multiverse)
 Command 'netcat' from package 'netcat-traditional' (universe)
 Command 'netcat' from package 'netcat-openbsd' (main)
 Command 'getcap' from package 'libcap2-bin' (main)
getcat: command not found
www-data@imf:/var/www/html/imfadministrator/uploads$ getcap /usr/local/bin/agent
www-data@imf:/var/www/html/imfadministrator/uploads$ string !$
string /usr/local/bin/agent
No command 'string' found, did you mean:
 Command 'spring' from package 'ruby-spring' (universe)
 Command 'spring' from package 'spring' (universe)
 Command 'strings' from package 'binutils' (main)
 Command 'strings' from package 'binutils-multiarch' (main)
string: command not found
www-data@imf:/var/www/html/imfadministrator/uploads$ strings /usr/local/bin/agent
/lib/ld-linux.so.2
I.ny
libc.so.6
_IO_stdin_used
strncmp
__isoc99_scanf
puts
stdin
fgets
getchar
stdout
asprintf
setbuf
__libc_start_main
__gmon_start__
GLIBC_2.7
GLIBC_2.0
PTRh
UWVS
t$,U
[^_]
  ___ __  __ ___ 
 |_ _|  \/  | __|  Agent
  | || |\/| | _|   Reporting
 |___|_|  |_|_|    System
Agent ID : 
Invalid Agent ID 
Login Validated 
Exiting...
Main Menu:
1. Extraction Points
2. Request Extraction
3. Submit Report
0. Exit
Enter selection: 
Extraction Points:
Staatsoper, Vienna, Austria
Blenheim Palace, Woodstock, Oxfordshire, England, UK
Great Windmill Street, Soho, London, England, UK
Fawley Power Station, Southampton, England, UK
Underground Station U4 Schottenring, Vienna, Austria
Old Town Square, Old Town, Prague, Czech Republic
Drake Hotel - 140 E. Walton Pl., Near North Side, Chicago, Illinois, USA
Ashton Park, Mosman, Sydney, New South Wales, Australia
Argyle Place, The Rocks, Sydney, New South Wales, Australia
Extraction Request
Enter extraction location: 
Location: %s
Extraction team has been deployed.
Enter report update: 
Report: %s
Submitted for review.
;*2$",
GCC: (Ubuntu 5.4.0-6ubuntu1~16.04.2) 5.4.0 20160609
crtstuff.c
__JCR_LIST__
deregister_tm_clones
__do_global_dtors_aux
completed.7200
__do_global_dtors_aux_fini_array_entry
frame_dummy
__frame_dummy_init_array_entry
sbo.c
__FRAME_END__
__JCR_END__
__init_array_end
_DYNAMIC
__init_array_start
__GNU_EH_FRAME_HDR
_GLOBAL_OFFSET_TABLE_
__libc_csu_fini
setbuf@@GLIBC_2.0
_ITM_deregisterTMCloneTable
__x86.get_pc_thunk.bx
getchar@@GLIBC_2.0
fgets@@GLIBC_2.0
_edata
menu
extractionpoints
__data_start
puts@@GLIBC_2.0
__gmon_start__
__dso_handle
_IO_stdin_used
__libc_start_main@@GLIBC_2.0
__libc_csu_init
stdin@@GLIBC_2.0
_fp_hw
asprintf@@GLIBC_2.0
stdout@@GLIBC_2.0
__bss_start
main
_Jv_RegisterClasses
__isoc99_scanf@@GLIBC_2.7
__TMC_END__
_ITM_registerTMCloneTable
report
strncmp@@GLIBC_2.0
requestextraction
.symtab
.strtab
.shstrtab
.interp
.note.ABI-tag
.note.gnu.build-id
.gnu.hash
.dynsym
.dynstr
.gnu.version
.gnu.version_r
.rel.dyn
.rel.plt
.init
.plt.got
.text
.fini
.rodata
.eh_frame_hdr
.eh_frame
.init_array
.fini_array
.jcr
.dynamic
.got.plt
.data
.bss
.comment
www-data@imf:/var/www/html/imfadministrator/uploads$