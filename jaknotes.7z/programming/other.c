#include <stdio.h>

void clean_stdin(void)
{
	int c;
	do
	{
		c = getchar();
	} while (c != '\n' && c != EOF);
}


struct pais
{
	char nombre[40];
	int cantidadhab;
};

int main()
{
	struct pais country1,country2;
	printf("Introduce el nombre del pais: ");
	fgets(country1.nombre, sizeof(country1.nombre), stdin);
	printf("Introduce la cantidad de habitantes: ");
	scanf("%i",&country1.cantidadhab);
	void_clean();
	printf("Introduce el nombre del pais: ");
	fgets(country2.nombre, sizeof(country2.nombre), stdin);
	printf("Introduce la cantidad de habitantes: ");
	scanf("%i",&country2.cantidadhab);
	void_clean();
	if (country2.cantidadhab > country1.cantidadhab)
	{
		printf("El pais %s tiene mayor numero de habitantes",country2.cantidadhab);
	}
	getchar();
	return 0;
}

