#include <stdio.h>

void clean_stdin(void)
{
	int c;
	do {
		c = getchar();
	} while (c != '\n' && c != EOF);
}

struct producto {
	int codigo;
	char descripcion[40];
	float precio;
};
int main() {
	struct producto pro1,pro2;
	printf("Ingrese el codigo del producto: ");
	scanf("%i",&pro1.codigo);
	clean_stdin();
	printf("Ingrese la descripcion: ");
	fgets(pro1.descripcion, sizeof(pro1.descripcion), stdin);
	printf("Ingrese el precio: ");
	scanf("%f",&pro1.precio);
	printf("\n-----");
	printf("Ingrese el codigo del producto: ");
	scanf("%i",&pro2.codigo);
	clean_stdin();
	printf("Ingrese la descripcion: ");
	fgets(pro2.descripcion, sizeof(pro2.descripcion), stdin);
	printf("Ingrese el precio: ");
	scanf("%f",&pro2.precio);
	if(pro1.precio > pro2.precio)
	{
		printf("El producto %s tiene un precio mayor",pro1.descripcion);
	}
	else
	{
		printf("El producto %s tiene un precio mayor",pro2.descripcion);
	}
	getchar();
	return 0;
}


