# Tools
[Freemind](http://freemind.sourceforge.net/wiki/index.php/Download) //Mind mapping
Your penetration test report's target audience groups are:
Target group  | Description
-- | --
Executive| You have to speak in terms of metrics, risk mitigation and money loss
IT Department| Which areas or departments are more affected and to what kind of vulnerabilities
Development| Your exploits, your POCs, remediation tips, source code, etc
A typical structure
Executive summary(2-3 pages)
```txt
"The purpose of this assessment and report is to identify any web application issues that could affect ABC, Inc and the web server hosting it and to provide solutions to remedy these same issues. "
```
