# Shells
## Bind shells
1. [Bind shells](https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Methodology%20and%20Resources/Bind%20Shell%20Cheatsheet.md)
## Reverse shells
* *[PayloadAllTheThings](https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Methodology%20and%20Resources/Reverse%20Shell%20Cheatsheet.md)
* [Revshells](https://www.revshells.com/)
* [Highon.coffe](https://highon.coffee/blog/reverse-shell-cheat-sheet/)

