cd s
bash: cd: s: No such file or directory

┌──(user㉿kali)-[~/Documents/testing]
└─$ ls
searchUsers.php  secDevLabs  sqli_boolean_based_blind.py  sqli.py  sqli_time_based_blind.py

┌──(user㉿kali)-[~/Documents/testing]
└─$ cd secDevLabs/

┌──(user㉿kali)-[~/Documents/testing/secDevLabs]
└─$ ls
docs  images  LICENSE.md  owasp-top10-2016-mobile  owasp-top10-2021-apps  README.md

┌──(user㉿kali)-[~/Documents/testing/secDevLabs]
└─$ cd owasp-top10-2021-apps/

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps]
└─$ ls
a1  a2  a3  a5  a6  a7  a8  a9

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps]
└─$ cd a3

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3]
└─$ ls
comment-killer  copy-n-paste  gossip-world  mongection  sstype  streaming

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3]
└─$ cd gossip-world/

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ ls
app  deployments  images  Makefile  README.md

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$make ^C

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ 
┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ ls
app  deployments  images  Makefile  README.md

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ make install
Traceback (most recent call last):
  File "/usr/lib/python3/dist-packages/urllib3/connectionpool.py", line 704, in urlopen
    httplib_response = self._make_request(
                       ^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/urllib3/connectionpool.py", line 399, in _make_request
    conn.request(method, url, **httplib_request_kw)
  File "/usr/lib/python3.11/http/client.py", line 1282, in request
    self._send_request(method, url, body, headers, encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1328, in _send_request
    self.endheaders(body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1277, in endheaders
    self._send_output(message_body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1037, in _send_output
    self.send(msg)
  File "/usr/lib/python3.11/http/client.py", line 975, in send
    self.connect()
  File "/usr/lib/python3/dist-packages/docker/transport/unixconn.py", line 30, in connect
    sock.connect(self.unix_socket)
PermissionError: [Errno 13] Permission denied

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/usr/lib/python3/dist-packages/requests/adapters.py", line 489, in send
    resp = conn.urlopen(
           ^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/urllib3/connectionpool.py", line 788, in urlopen
    retries = retries.increment(
              ^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/urllib3/util/retry.py", line 550, in increment
    raise six.reraise(type(error), error, _stacktrace)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/six.py", line 718, in reraise
    raise value.with_traceback(tb)
  File "/usr/lib/python3/dist-packages/urllib3/connectionpool.py", line 704, in urlopen
    httplib_response = self._make_request(
                       ^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/urllib3/connectionpool.py", line 399, in _make_request
    conn.request(method, url, **httplib_request_kw)
  File "/usr/lib/python3.11/http/client.py", line 1282, in request
    self._send_request(method, url, body, headers, encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1328, in _send_request
    self.endheaders(body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1277, in endheaders
    self._send_output(message_body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1037, in _send_output
    self.send(msg)
  File "/usr/lib/python3.11/http/client.py", line 975, in send
    self.connect()
  File "/usr/lib/python3/dist-packages/docker/transport/unixconn.py", line 30, in connect
    sock.connect(self.unix_socket)
urllib3.exceptions.ProtocolError: ('Connection aborted.', PermissionError(13, 'Permission denied'))

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/usr/lib/python3/dist-packages/docker/api/client.py", line 214, in _retrieve_server_version
    return self.version(api_version=False)["ApiVersion"]
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/docker/api/daemon.py", line 181, in version
    return self._result(self._get(url), json=True)
                        ^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/docker/utils/decorators.py", line 46, in inner
    return f(self, *args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/docker/api/client.py", line 237, in _get
    return self.get(url, **self._set_request_timeout(kwargs))
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/requests/sessions.py", line 600, in get
    return self.request("GET", url, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/requests/sessions.py", line 587, in request
    resp = self.send(prep, **send_kwargs
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/requests/sessions.py", line 701, in send
    r = adapter.send(request, **kwargs)
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/requests/adapters.py", line 547, in send
    raise ConnectionError(err, request=request)
requests.exceptions.ConnectionError: ('Connection aborted.', PermissionError(13, 'Permission denied'))

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/usr/bin/docker-compose", line 33, in <module>
    sys.exit(load_entry_point('docker-compose==1.29.2', 'console_scripts', 'docker-compose')())
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/compose/cli/main.py", line 81, in main
    command_func()
  File "/usr/lib/python3/dist-packages/compose/cli/main.py", line 200, in perform_command
    project = project_from_options('.', options)
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/compose/cli/command.py", line 60, in project_from_options
    return get_project(
           ^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/compose/cli/command.py", line 152, in get_project
    client = get_client(
             ^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/compose/cli/docker_client.py", line 41, in get_client
    client = docker_client(
             ^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/compose/cli/docker_client.py", line 170, in docker_client
    client = APIClient(use_ssh_client=not use_paramiko_ssh, **kwargs)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/docker/api/client.py", line 197, in __init__
    self._version = self._retrieve_server_version()
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/docker/api/client.py", line 221, in _retrieve_server_version
    raise DockerException(
docker.errors.DockerException: Error while fetching server API version: ('Connection aborted.', PermissionError(13, 'Permission denied'))make: *** [Makefile:23: compose-down] Error 1

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ apt install make -y
E: Could not open lock file /var/lib/dpkg/lock-frontend - open (13: Permission denied)
E: Unable to acquire the dpkg frontend lock (/var/lib/dpkg/lock-frontend), are you root?

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ sudo apt install make -y
Reading package lists... Done
Building dependency tree... Done
Reading state information... Done
make is already the newest version (4.3-4.1).
make set to manually installed.
The following packages were automatically installed and are no longer required:
  libboost-python1.74.0 libgs9-common libidn11 libntfs-3g883 python3-bluez python3-cachecontrol python3-cssselect python3-ctypescrypto
  python3-enchant python3-flask-cors python3-fleep python3-gattlib python3-gevent python3-imapclient python3-libarchive-c python3-pem
  python3-pyquery python3-pywebcopy python3-zope.event
Use 'sudo apt autoremove' to remove them.
0 upgraded, 0 newly installed, 0 to remove and 538 not upgraded.

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ sudo make 

A3 Gossip World
------
awk: cmd. line:1: warning: regexp escape sequence `\_' is not a known regexp operator
$ make compose: Runs project using docker-compose
$ make compose-down: Down project using docker-compose
$ make deploy: Deploys project and view docker logs
$ make help: Prints help message
$ make install: Installs a development environment using docker-compose
$ make msg: Prints initialization message after compose phase


┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ss -ltn4
State            Recv-Q           Send-Q                     Local Address:Port                      Peer Address:Port           Process           
LISTEN           0                511                            127.0.0.1:44143                          0.0.0.0:*                                
LISTEN           0                128                            127.0.0.1:631                            0.0.0.0:*                                
LISTEN           0                4096                           127.0.0.1:37413                          0.0.0.0:*                                

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ ls
app  deployments  images  Makefile  README.md

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ make install
Traceback (most recent call last):
  File "/usr/lib/python3/dist-packages/urllib3/connectionpool.py", line 704, in urlopen
    httplib_response = self._make_request(
                       ^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/urllib3/connectionpool.py", line 399, in _make_request
    conn.request(method, url, **httplib_request_kw)
  File "/usr/lib/python3.11/http/client.py", line 1282, in request
    self._send_request(method, url, body, headers, encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1328, in _send_request
    self.endheaders(body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1277, in endheaders
    self._send_output(message_body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1037, in _send_output
    self.send(msg)
  File "/usr/lib/python3.11/http/client.py", line 975, in send
    self.connect()
  File "/usr/lib/python3/dist-packages/docker/transport/unixconn.py", line 30, in connect
    sock.connect(self.unix_socket)
PermissionError: [Errno 13] Permission denied

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/usr/lib/python3/dist-packages/requests/adapters.py", line 489, in send
    resp = conn.urlopen(
           ^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/urllib3/connectionpool.py", line 788, in urlopen
    retries = retries.increment(
              ^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/urllib3/util/retry.py", line 550, in increment
    raise six.reraise(type(error), error, _stacktrace)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/six.py", line 718, in reraise
    raise value.with_traceback(tb)
  File "/usr/lib/python3/dist-packages/urllib3/connectionpool.py", line 704, in urlopen
    httplib_response = self._make_request(
                       ^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/urllib3/connectionpool.py", line 399, in _make_request
    conn.request(method, url, **httplib_request_kw)
  File "/usr/lib/python3.11/http/client.py", line 1282, in request
    self._send_request(method, url, body, headers, encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1328, in _send_request
    self.endheaders(body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1277, in endheaders
    self._send_output(message_body, encode_chunked=encode_chunked)
  File "/usr/lib/python3.11/http/client.py", line 1037, in _send_output
    self.send(msg)
  File "/usr/lib/python3.11/http/client.py", line 975, in send
    self.connect()
  File "/usr/lib/python3/dist-packages/docker/transport/unixconn.py", line 30, in connect
    sock.connect(self.unix_socket)
urllib3.exceptions.ProtocolError: ('Connection aborted.', PermissionError(13, 'Permission denied'))

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/usr/lib/python3/dist-packages/docker/api/client.py", line 214, in _retrieve_server_version
    return self.version(api_version=False)["ApiVersion"]
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/docker/api/daemon.py", line 181, in version
    return self._result(self._get(url), json=True)
                        ^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/docker/utils/decorators.py", line 46, in inner
    return f(self, *args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/docker/api/client.py", line 237, in _get
    return self.get(url, **self._set_request_timeout(kwargs))
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/requests/sessions.py", line 600, in get
    return self.request("GET", url, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/requests/sessions.py", line 587, in request
    resp = self.send(prep, **send_kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/requests/sessions.py", line 701, in send
    r = adapter.send(request, **kwargs)
        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/requests/adapters.py", line 547, in send
    raise ConnectionError(err, request=request)
requests.exceptions.ConnectionError: ('Connection aborted.', PermissionError(13, 'Permission denied'))

During handling of the above exception, another exception occurred:

Traceback (most recent call last):
  File "/usr/bin/docker-compose", line 33, in <module>
    sys.exit(load_entry_point('docker-compose==1.29.2', 'console_scripts', 'docker-compose')())
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/compose/cli/main.py", line 81, in main
    command_func()
  File "/usr/lib/python3/dist-packages/compose/cli/main.py", line 200, in perform_command
    project = project_from_options('.', options)
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/compose/cli/command.py", line 60, in project_from_options
    return get_project(
           ^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/compose/cli/command.py", line 152, in get_project
    client = get_client(
             ^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/compose/cli/docker_client.py", line 41, in get_client
    client = docker_client(
             ^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/compose/cli/docker_client.py", line 170, in docker_client
    client = APIClient(use_ssh_client=not use_paramiko_ssh, **kwargs)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/docker/api/client.py", line 197, in __init__
    self._version = self._retrieve_server_version()
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3/dist-packages/docker/api/client.py", line 221, in _retrieve_server_version
    raise DockerException(
docker.errors.DockerException: Error while fetching server API version: ('Connection aborted.', PermissionError(13, 'Permission denied'))make: *** [Makefile:23: compose-down] Error 1

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ sudo su
root@kali:/home/user/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world# make install
Removing network secdevlabs_a7_net
WARNING: Network secdevlabs_a7_net not found.
Removing volume secdevlabs_storage-a7-database
WARNING: Volume secdevlabs_storage-a7-database not found.
Creating network "secdevlabs_a7_net" with the default driver
Creating volume "secdevlabs_storage-a7-database" with default driver
Pulling mysqldb-a7 (mariadb:10.6.3)...
10.6.3: Pulling from library/mariadb
16ec32c2132b: Pull complete
cbf20e69555c: Pull complete
a69afd1ffc85: Pull complete
5e720dc7fcd8: Pull complete
3a81d177e410: Pull complete
827c8c103c89: Pull complete
2108ccd01374: Pull complete
daa89fc536ce: Pull complete
5313da4066cc: Pull complete
2ed11818346e: Pull complete
Digest: sha256:3b6f9fa1d406e168998d62501b2ee4f27d53138bebfcdac03540758996c5ff1d
Status: Downloaded newer image for mariadb:10.6.3
Building app
Sending build context to Docker daemon  1.757MB
Step 1/5 : FROM python:3.8
3.8: Pulling from library/python
d52e4f012db1: Pulling fs layer 
7dd206bea61f: Pulling fs layer 
2320f9be4a9c: Pulling fs layer 
6e5565e0ba8d: Waiting 
d3797e13cc41: Waiting 
9d8ab9ac5a7d: Waiting 
43ed38f1d568: Waiting 
164b4060be55: Waiting Digest: sha256:7421ee70f509a949a914932320dcec83d9bded7e15121d3e63dcc05d577b7971
Status: Downloaded newer image for python:3.8
 ---> db2bf59cb82f
Step 2/5 : WORKDIR /app
 ---> Running in 17a8d2176645
Removing intermediate container 17a8d2176645
 ---> b36e3574aa1c
Step 3/5 : ADD app/requirements.txt /app/requirements.txt
 ---> 4dc08fcc2faf
Step 4/5 : RUN pip install -r requirements.txt
 ---> Running in 04a55975b82e
Collecting Click==7.0
  Downloading Click-7.0-py2.py3-none-any.whl (81 kB)
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 81.3/81.3 kB 1.4 MB/s eta 0:00:00
Collecting dominate==2.3.4
  Downloading dominate-2.3.4-py2.py3-none-any.whl (25 kB)
Collecting Flask==1.0.2
  Downloading Flask-1.0.2-py2.py3-none-any.whl (91 kB)
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 91.4/91.4 kB 3.2 MB/s eta 0:00:00
Collecting Flask-Bootstrap==3.3.7.1
  Downloading Flask-Bootstrap-3.3.7.1.tar.gz (456 kB)
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 456.4/456.4 kB 4.6 MB/s eta 0:00:00
  Preparing metadata (setup.py): started
  Preparing metadata (setup.py): finished with status 'done'
Collecting Flask-Cors==3.0.7
  Downloading Flask_Cors-3.0.7-py2.py3-none-any.whl (13 kB)
Collecting itsdangerous==1.1.0
  Downloading itsdangerous-1.1.0-py2.py3-none-any.whl (16 kB)
Collecting Jinja2==2.10
  Downloading Jinja2-2.10-py2.py3-none-any.whl (126 kB)
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 126.4/126.4 kB 4.0 MB/s eta 0:00:00
Collecting MarkupSafe==1.1.0
  Downloading MarkupSafe-1.1.0.tar.gz (18 kB)
  Preparing metadata (setup.py): started  Preparing metadata (setup.py): finished with status 'done'
Collecting mysqlclient==1.3.13
  Downloading mysqlclient-1.3.13.tar.gz (90 kB)
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 90.4/90.4 kB 2.6 MB/s eta 0:00:00
  Preparing metadata (setup.py): started
  Preparing metadata (setup.py): finished with status 'done'
Collecting six==1.11.0
  Downloading six-1.11.0-py2.py3-none-any.whl (10 kB)
Collecting visitor==0.1.3
  Downloading visitor-0.1.3.tar.gz (3.3 kB)
  Preparing metadata (setup.py): started
  Preparing metadata (setup.py): finished with status 'done'
Collecting Werkzeug==0.14.1
  Downloading Werkzeug-0.14.1-py2.py3-none-any.whl (322 kB)
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 322.9/322.9 kB 2.1 MB/s eta 0:00:00
Building wheels for collected packages: Flask-Bootstrap, MarkupSafe, mysqlclient, visitor
  Building wheel for Flask-Bootstrap (setup.py): started
  Building wheel for Flask-Bootstrap (setup.py): finished with status 'done'
  Created wheel for Flask-Bootstrap: filename=Flask_Bootstrap-3.3.7.1-py3-none-any.whl size=460123 sha256=c3d935d4a4287c610ed127aae24fecc5650803db05a97edf68b8020c10c9a431
  Stored in directory: /root/.cache/pip/wheels/f2/a3/85/fe8b65a65a447c9906e3b7edb7d9e6c74dfa9c8425c3dd3007
  Building wheel for MarkupSafe (setup.py): started
  Building wheel for MarkupSafe (setup.py): finished with status 'done'
  Created wheel for MarkupSafe: filename=MarkupSafe-1.1.0-cp38-cp38-linux_x86_64.whl size=28370 sha256=823593f5ea85fe831063c4e296cb46f232331bd282bb2bc026a720b18cc661a8
  Stored in directory: /root/.cache/pip/wheels/3a/bc/6f/c7c1715c62131d7028d6172ba160ce6be1c23145b16a1fe551
  Building wheel for mysqlclient (setup.py): started
  Building wheel for mysqlclient (setup.py): finished with status 'done'
  Created wheel for mysqlclient: filename=mysqlclient-1.3.13-cp38-cp38-linux_x86_64.whl size=117451 sha256=f815af7501f1a9e0d7b04fe386e3ba57d6f76c0683c3d481f13c95e970f4bc77
  Stored in directory: /root/.cache/pip/wheels/c0/2b/ea/5be7472867cd586fd0210e527a791db2a7a5a904ffdaf00c48
  Building wheel for visitor (setup.py): started
  Building wheel for visitor (setup.py): finished with status 'done'
  Created wheel for visitor: filename=visitor-0.1.3-py3-none-any.whl size=3944 sha256=d6ce9948848bb5afab4b70b3a8fc1a17e10c968c3ba26502f629bdc7a541c0ac
  Stored in directory: /root/.cache/pip/wheels/d3/40/52/5dae7760434a82caf8b8f88323029188b2d4ea3ac1235e550a
Successfully built Flask-Bootstrap MarkupSafe mysqlclient visitorInstalling collected packages: Werkzeug, visitor, six, mysqlclient, MarkupSafe, itsdangerous, dominate, Click, Jinja2, Flask, Flask-Cors, Flask-Bootstrap
Successfully installed Click-7.0 Flask-1.0.2 Flask-Bootstrap-3.3.7.1 Flask-Cors-3.0.7 Jinja2-2.10 MarkupSafe-1.1.0 Werkzeug-0.14.1 dominate-2.3.4 itsdangerous-1.1.0 mysqlclient-1.3.13 six-1.11.0 visitor-0.1.3
WARNING: Running pip as the 'root' user can result in broken permissions and conflicting behaviour with the system package manager. It is recommended to use a virtual environment instead: https://pip.pypa.io/warnings/venv

[notice] A new release of pip is available: 23.0.1 -> 23.1.2
[notice] To update, run: pip install --upgrade pip
Removing intermediate container 04a55975b82e
 ---> bc1f0169f578
Step 5/5 : CMD python routes.py
 ---> Running in 25d91b32129f
Removing intermediate container 25d91b32129f
 ---> 0c3cfecaeae7
Successfully built 0c3cfecaeae7
Successfully tagged secdevlabs_app:latest
Creating mysqldb-a7 ... done
Creating app-a7     ... done
SecDevLabs: 👀  Your app is starting!
SecDevLabs: 👀  Your app is still starting... (-*------) 
SecDevLabs: 🔥  A7 - Gossip World is now running at http://localhost:10007
root@kali:/home/user/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world# exit
exit

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$
┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ sudo python3 -m http.server 80
Traceback (most recent call last):
  File "<frozen runpy>", line 198, in _run_module_as_main
  File "<frozen runpy>", line 88, in _run_code
  File "/usr/lib/python3.11/http/server.py", line 1309, in <module>
    test(
  File "/usr/lib/python3.11/http/server.py", line 1256, in test
    with ServerClass(addr, HandlerClass) as httpd:
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3.11/socketserver.py", line 456, in __init__
    self.server_bind()
  File "/usr/lib/python3.11/http/server.py", line 1303, in server_bind
    return super().server_bind()
           ^^^^^^^^^^^^^^^^^^^^^
  File "/usr/lib/python3.11/http/server.py", line 136, in server_bind
    socketserver.TCPServer.server_bind(self)
  File "/usr/lib/python3.11/socketserver.py", line 472, in server_bind
    self.socket.bind(self.server_address)
OSError: [Errno 98] Address already in use

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ sudo python3 -m http.server 4126
Serving HTTP on 0.0.0.0 port 4126 (http://0.0.0.0:4126/) ...
10.137.0.19 - - [04/Jul/2023 12:35:45] "GET /?email=superadmin@evilcorp.com HTTP/1.1" 200 -10.137.0.19 - - [04/Jul/2023 12:39:40] "GET /?email=superadmin@evilcorp.com HTTP/1.1" 200 -
l^C
Keyboard interrupt received, exiting.

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ ip a
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
    link/ether 00:16:3e:5e:6c:00 brd ff:ff:ff:ff:ff:ff
    inet 10.137.0.19/32 scope global eth0
       valid_lft forever preferred_lft forever
    inet6 fe80::216:3eff:fe5e:6c00/64 scope link 
       valid_lft forever preferred_lft forever
3: docker0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default 
    link/ether 02:42:52:86:ad:bf brd ff:ff:ff:ff:ff:ff
    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0
       valid_lft forever preferred_lft forever
    inet6 fe80::42:52ff:fe86:adbf/64 scope link 
       valid_lft forever preferred_lft forever
4: br-5d15665ab790: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default 
    link/ether 02:42:8c:44:65:b3 brd ff:ff:ff:ff:ff:ff
    inet 172.18.0.1/16 brd 172.18.255.255 scope global br-5d15665ab790
       valid_lft forever preferred_lft forever
    inet6 fe80::42:8cff:fe44:65b3/64 scope link 
       valid_lft forever preferred_lft forever
8: vethe34e47f@if7: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master br-5d15665ab790 state UP group default 
    link/ether f6:90:b9:40:9c:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f490:b9ff:fe40:9cc6/64 scope link 
       valid_lft forever preferred_lft forever
26: veth71b7b76@if25: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master br-5d15665ab790 state UP group default 
    link/ether fe:6e:0d:43:cb:00 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::fc6e:dff:fe43:cb00/64 scope link 
       valid_lft forever preferred_lft forever

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
    link/ether 00:16:3e:5e:6c:00 brd ff:ff:ff:ff:ff:ff
    inet 10.137.0.19/32 scope global eth0
       valid_lft forever preferred_lft forever
    inet6 fe80::216:3eff:fe5e:6c00/64 scope link 
       valid_lft forever preferred_lft forever
3: docker0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default 
    link/ether 02:42:52:86:ad:bf brd ff:ff:ff:ff:ff:ff
    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0
       valid_lft forever preferred_lft forever
    inet6 fe80::42:52ff:fe86:adbf/64 scope link 
       valid_lft forever preferred_lft forever
4: br-5d15665ab790: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default 
    link/ether 02:42:8c:44:65:b3 brd ff:ff:ff:ff:ff:ff
    inet 172.18.0.1/16 brd 172.18.255.255 scope global br-5d15665ab790
       valid_lft forever preferred_lft forever
    inet6 fe80::42:8cff:fe44:65b3/64 scope link 
       valid_lft forever preferred_lft forever
8: vethe34e47f@if7: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master br-5d15665ab790 state UP group default 
    link/ether f6:90:b9:40:9c:c6 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f490:b9ff:fe40:9cc6/64 scope link 
       valid_lft forever preferred_lft forever
26: veth71b7b76@if25: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue master br-5d15665ab790 state UP group default 
    link/ether fe:6e:0d:43:cb:00 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::fc6e:dff:fe43:cb00/64 scope link 
       valid_lft forever preferred_lft forever

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ sudo python3 -m http.server 4126
Serving HTTP on 0.0.0.0 port 4126 (http://0.0.0.0:4126/) ...
10.137.0.19 - - [04/Jul/2023 12:47:29] "GET /?email=payaso@payasocorp.com HTTP/1.1" 200 -
^C
Keyboard interrupt received, exiting.

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ ^C

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ sudo python3 -m http.server 4126
Serving HTTP on 0.0.0.0 port 4126 (http://0.0.0.0:4126/) ...┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ ^C

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ sudo python3 -m http.server 4126
Serving HTTP on 0.0.0.0 port 4126 (http://0.0.0.0:4126/) ...
^C
Keyboard interrupt received, exiting.

┌──(user㉿kali)-[~/Documents/testing/secDevLabs/owasp-top10-2021-apps/a3/gossip-world]
└─$ sudo python3 -m http.server 4126
Serving HTTP on 0.0.0.0 port 4126 (http://0.0.0.0:4126/) ...
10.137.0.19 - - [04/Jul/2023 12:57:26] code 404, message File not found
10.137.0.19 - - [04/Jul/2023 12:57:26] "GET /j HTTP/1.1" 404 -
10.137.0.19 - - [04/Jul/2023 12:57:26] code 404, message File not found
10.137.0.19 - - [04/Jul/2023 12:57:26] "GET /jb HTTP/1.1" 404 -
10.137.0.19 - - [04/Jul/2023 12:57:26] code 404, message File not found
10.137.0.19 - - [04/Jul/2023 12:57:26] "GET /jbn HTTP/1.1" 404 -
10.137.0.19 - - [04/Jul/2023 12:57:28] code 404, message File not found
10.137.0.19 - - [04/Jul/2023 12:57:28] "GET /jbnp HTTP/1.1" 404 -
10.137.0.19 - - [04/Jul/2023 12:57:28] code 404, message File not found
10.137.0.19 - - [04/Jul/2023 12:57:28] "GET /jbnpu HTTP/1.1" 404 -
10.137.0.19 - - [04/Jul/2023 12:57:28] code 404, message File not found
10.137.0.19 - - [04/Jul/2023 12:57:28] "GET /jbnpue HTTP/1.1" 404 -
10.137.0.19 - - [04/Jul/2023 12:57:28] code 404, message File not found
10.137.0.19 - - [04/Jul/2023 12:57:28] "GET /jbnpued HTTP/1.1" 404 -
10.137.0.19 - - [04/Jul/2023 12:57:29] code 404, message File not found
10.137.0.19 - - [04/Jul/2023 12:57:29] "GET /jbnpuede HTTP/1.1" 404 -
10.137.0.19 - - [04/Jul/2023 12:57:29] code 404, message File not found
10.137.0.19 - - [04/Jul/2023 12:57:29] "GET /jbnpuede HTTP/1.1" 404 -
10.137.0.19 - - [04/Jul/2023 12:57:29] code 404, message File not found
10.137.0.19 - - [04/Jul/2023 12:57:29] "GET /jbnpuede%20s HTTP/1.1" 404 -