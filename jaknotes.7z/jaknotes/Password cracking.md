# Hashing 
You can't encrypt the passwords, as the key has to be stored somewhere. If someone gets the key, they can just decrypt the passwords. This is where hashing comes in. What if, instead of storing the password, you just stored the hash of the password? This means you never have to store the user's password, and if your database was leaked then an attacker would have to crack each password to find out what the password was. That sounds fairly useful.

There's just one problem with this. What if two users have the same password? As a hash function will always turn the same input into the same output, you will store the same password hash for each user. That means if someone cracks that hash, they get into more than one account. It also means that someone can create a "Rainbow table" to break the hashes.

A rainbow table is a lookup table of hashes to plaintexts, so you can quickly find out what password a user had just from the hash. A rainbow table trades time taken to crack a hash for hard disk space, but they do take time to create. To protect against rainbow tables, we add a salt to the passwords. _The salt is randomly generated and stored in the database, unique to each user. In theory, you could use the same salt for all users but that means that duplicate passwords would still have the same hash, and a rainbow table could still be created specific passwords with that salt_.

The salt is added to either the start or the end of the password before it’s hashed, and this means that every user will have a different password hash even if they have the same password. Hash functions like bcrypt and sha512crypt handle this automatically. Salts don’t need to be kept private.

# John the ripper
```bash
john --format=[format] --wordlist=[path]
```
A Note on Formats: When you are telling john to use formats, if you're dealing with a standard hash type, e.g. md5 as in the example above, you have to prefix it with `raw-` to tell john you're just dealing with a standard hash type, though this doesn't always apply. To check if you need to add the prefix or not, you can list all of John's formats using `john --list=formats` and either check manually, or grep for your hash type using something like `john --list=formats | grep -iF "md5"`.
## NTHash / NTLM
NThash is the hash format that modern Windows Operating System machines will store user and service passwords in. It's also commonly referred to as "NTLM" which references the previous version of Windows format for hashing passwords known as "LM", thus "NT/LM".

A little bit of history, the NT designation for Windows products originally meant "New Technology", and was used- starting with Windows NT, to denote products that were not built up from the MS-DOS Operating System. Eventually, the "NT" line became the standard Operating System type to be released by Microsoft and the name was dropped, but it still lives on in the names of some Microsoft technologies. 

You can acquire NTHash/NTLM hashes by dumping the SAM database on a Windows machine, by using a tool like Mimikatz or from the Active Directory database: NTDS.dit. 
## Unshadowing
```bash
unshadow [path to passwd] [path to shadow]
unshadow - Invokes the unshadow tool
[path to passwd] - The file that contains the copy of the /etc/passwd file you've taken from the target machine
[path to shadow] - The file that contains the copy of the /etc/shadow file you've taken from the target machine 
```
## Using single crack mode
```bash
  john --single --format=[format] [path to file]
```
`A Note on File Formats in Single Crack Mode`: If you're cracking hashes in single crack mode, you need to change the file format that you're feeding john for it to understand what data to create a wordlist from. You do this by prepending the hash with the username that the hash belongs to, so according to the above example- we would change the file hashes.txt
From: `efee03cdcb96d90ad48ccc7b8666033` to `mike:1efee03cdcb96d90ad48ccc7b8666033`
## To display the password recovered
```bash
john --show crackme
```
## Default file where the cracked passwords are stored by John
```bash
/root/.john/john.pot
```
## It is a good idea if we are in Linux to check the 
`/etc/login.defs` to see the hash algorithm used to hash the password present in the shadow file
## How to create Custom Rules
Custom rules are defined in the john.conf file, usually located in `/etc/john/john.conf` if you have installed John using a package manager or built from source with make and in `/opt/john/john.conf`.

Let's go over the syntax of these custom rules, using the example above as our target pattern. Note that there is a massive level of granular control that you can define in these rules, I would suggest taking a look at the wiki here in order to get a full view of the types of modifier you can use, as well as more examples of rule implementation.

We could then call this custom rule as a John argument using the  `--rule=PoloPassword` flag.
As a full command
```bash
john --wordlist=[path to wordlist] --rule=PoloPassword [path to file]
```
As a note I find it helpful to talk out the patterns if you're writing a rule- as shown above, the same applies to writing RegEx patterns too.

Jumbo John already comes with a large list of custom rules, which contain modifiers for use almost all cases. If you get stuck, try looking at those rules [around line 678] if your syntax isn't working properly.
# Encryption
## Basic concepts
### What is a passphrase?
Passphrase - Separate to the key, a passphrase is similar to a password and used to protect a key.

DO NOT encrypt passwords unless you’re doing something like a password manager. Passwords should not be stored in plaintext, and you should use hashing to manage them safely.
An important thing to remember about modulo is that it’s not reversible. If I gave you an equation: x % 5 = 4, there are infinite values of x that will be valid.
### Encryption categories
The two main categories of Encryption are symmetric and asymmetric.
- Symmetric encryption uses the _same key to encrypt and decrypt the data_. Examples of Symmetric encryption are DES (Broken) and AES. These algorithms tend to be faster than asymmetric cryptography, and use smaller keys (128 or 256 bit keys are common for AES, DES keys are 56 bits long).
- Asymmetric encryption _uses a pair of keys, one to encrypt and the other in the pair to decrypt_. Examples are RSA and Elliptic Curve Cryptography. Normally these keys are referred to as a public key and a private key. Data encrypted with the private key can be decrypted with the public key, and vice versa. Your private key needs to be kept private, hence the name. Asymmetric encryption tends to be slower and uses larger keys, for example RSA typically uses 2048 to 4096 bit keys.

=-=-=-=-=
The math(s) side

  RSA is based on the mathematically difficult problem of working out the factors of a large number. It’s very quick to multiply two prime numbers together, say 17*23 = 391, but it’s quite difficult to work out what two prime numbers multiply together to make 14351 (113x127 for reference).
  The attacking side

  The maths behind RSA seems to come up relatively often in CTFs, normally requiring you to calculate variables or break some encryption based on them. The wikipedia page for RSA seems complicated at first, but will give you almost all of the information you need in order to complete challenges.

  There are some excellent tools for defeating RSA challenges in CTFs, and my personal favorite is https://github.com/Ganapati/RsaCtfTool which has worked very well for me. I’ve also had some success with https://github.com/ius/rsatool.

  The key variables that you need to know about for RSA in CTFs are p, q, m, n, e, d, and c.

  “p” and “q” are large prime numbers, “n” is the product of p and q.

  The public key is n and e, the private key is n and d.

  “m” is used to represent the message (in plaintext) and “c” represents the ciphertext (encrypted text).

-=-=-=-=-=-
SSH authentication
ssh-keygen
  It’s very important to mention that the passphrase to decrypt the key isn’t used to identify you to the server at all, all it does is decrypt the SSH key. The passphrase is never transmitted, and never leaves your system.

ssh -i [keyNameGoesHere] user@host

gpg2john

# Credential stuffing
There are various databases that keep a running list of known default credentials. One of them is the [DefaultCreds-Cheat-Sheet](https://github.com/ihebski/DefaultCreds-cheat-sheet)
Besides the default credentials for applications, some lists offer them for routers. One of these lists can be found [here](https://www.softwaretestinghelp.com/default-router-username-and-password-list/)