# Text processing
## Redirect STDIN Stream to a File
We can also use the double lower-than characters `<<` to add our standard input through a stream. We can use the so-called End-Of-File `EOF` function of a Linux system file, which defines the input's end
```bash
cat << EOF > stream.txt
```
An option for further locking down Linux systems is Security-Enhanced Linux `SELinux` or `AppArmor`. This is a kernel security module that can be used for security access control policies. In SELinux, every process, file, directory, and system object is given a label. Policy rules are created to control access between these labeled processes and objects and are enforced by the kernel. This means that access can be set up to control which users and applications can access which resources. SELinux provides very granular access controls, such as specifying who can append to a file or move it. Besides, there are different applications and services such as Snort, chkrootkit, rkhunter, Lynis, and others that can contribute to Linux's security.
## Regex
| Option       | Description                                                                        |
| ------------ | ---------------------------------------------------------------------------------- |
| `[abc]`      | Every occurrence of each letter                                                    |
| `[abc]zz`    | Will match azz, bzz and czz                                                        |
| `[a-c]zz`    | Is the same as above                                                               |
| `[a-cx-z]zz` | Will match azz, bzz, czz, xzz, yzz and zzz                                         |
| `[a-zA-Z]`   | Will match any single letter (lowercase or uppercase)                              |
| `file[1-3]`  | Will match file1, file2 and file3                                                  |
| `[^k]ing`    | Will match ring, sing, $ing but not king                                           |
| `[^a-c]at`   | Will match fat and hat, but not bat or cat                                         |
| `[0-9]`      | Will include numbers 0-9                                                                                   |
| `.`          | Is the wildcard that is used to match any single character (except the line break) |
| `a.c`        | Will match aac, abc, a0c, a!c and so on                                            |
| `a\.c`       | If you want to search for a literal dot                                            |
| `?`          | Character optional                                                                 |
| `abc?`       | Will match ab and abc since c is optional                                          |
| `\d`         | Matches a digit, like 9                                                            |
| `\D`         | Matches a non-digit, like A or @                                                   |
| `\w`         | Matches an alphanumeric character, like a or 3                                     |
| `\W`         | Matches a non-alphanumeric character, like ! or #                                  |
| `\s`         | Matches a whitespace character (spaces, tabs and line breaks)                      |
| `\S`         | Matches everything else (alphanumeric, characters and symbols)                     |
| `{12}`       | Exactly 12 times                                                                   |
| `{1,5}`      | 1 to 5 times                                                                       |
| `{2,}`       | 2 or more times                                                                    |
| `*`          | 0 or more times                                                                    |
| `+`          | 1 or more times                                                                    |

## vim
| Option           | Description                                                                               |
| ---------------- | ----------------------------------------------------------------------------------------- |
| `/`              | To search                                                                                 |
| `n`              | To search for the same prase again                                                        |
| `N`              | In the opposite direction                                                                 |
| `?`              | To search for a phrase in the backward direction                                          |
| `Ctrl o`         | To go back further                                                                        |
| `Ctrl i`         | Goes forward                                                                              |
| `%`              | Move the cursor to the other `(` or `{`                                                   |
| `:s/old/new/g`   | To substitute 'new' for 'old'                                                             |
| `#,#s/old/new/g` | Where `#` are the line numbers of the range of lines where the substitution is to be done |
| `%s/old/new/gc`  | To find every occurrence in the whole file, with a prompt whether to substitute or not    |
| `!ls`            | Execute an external command                                                               |
| `:set xxx`       | Where `ic` => Ignore upper/lower case when searching. `is` => Show partial matches for a search phrase. `hls` => Highligth all matching phrases                                                                                          |

# Commands
## Find
| Option          | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| --------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `-type d`       | Only directories                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| `-type f`       | Only files                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| `-name`         | Search name                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| `-iname`        | Search name case insensitive                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| `-user`         | The username of the owner of a file                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| `-size -n/+n/n` | Where n is a number. To specify a size, you also need a sufix. c=bytes, k=KB and M=MBs. Example: If you want to specify a size less than 30 bytes, the argument -30c should be used                                                                                                                                                                                                                                                                                           |
| `-perm`         | To specify permissions. You can use `-` prefix to return files with at least the permissions you specify. This means that the -444 mode will match files that are readable by everyone, even if someone also has write and/or execute permissions. Using the `/` prefix will return files that match any of the permissions you have set. This means that the /666 mode will match files that are readable and writeable by at least one of the groups(owner,group or others) |
| `-a`            | Accesed. A file accesed more than 30 minutes ago: `-amin +30`                                                                                                                                                                                                                                                                                                                                                                                                                 |
| `-m`            | Modified. Modified less than 7 days ago: `-mtime -7`. A file modified within the last 24 hours: `-mtime 0`                                                                                                                                                                                                                                                                                                                                                                                                                          |
| `-c`            | Changed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|`-exec`| Example: `-exec whoami \;`

# Bash scripting
## Useful resource
[Advanced bash scripting](https://tldp.org/LDP/abs/html/)
## To debug code
```bash
set -x and set +x 
```
	#!/bin/bash
## To remove an element in an array
```bash
unset transport[1]
```
## Examples
```bash
if [ x ]; then
  docommand
elif [ y ]; then
  doothercommand
else
  dosomethingelse
fi
```
```bash
//Another
#!/bin/bash
for i in $( ls ); do
  echo item: $i
done
```
```bash
//Other with seq
#!/bin/bash
for i in `seq 1 10`;
do 
  echo $i
done
```
## While loop
```bash
while [condition]; do <command1>;<command2>;done
```
## Read line
```bash
while read line; do echo $line; done < file.txt
```
## Options
| Option | Description |
| ------ | ----------- |
| `-eq`       |      Checks if the value of two operands are equal or not; if yes, then the condition becomes true.       |
| `-ne`| Checks if the value of two operands are equal or not; if values are not equal, then the condition becomes true.
|`-gt`|  Checks if the value of left operand is greater than the value of right operand; if yes, then the condition becomes true.
|`-lt`|  Checks if the value of left operand is less than the value of right operand; if yes, then the condition becomes true.
|`-ge`|  Checks if the value of left operand is greater than or equal to the value of right operand; if yes, then the condition becomes true.
|`-f`| Checks if the file exists
|`-w`| Checks if the file is writable. Without write permissions we would not be able to output our text into the file
| `read`|  To insert text
