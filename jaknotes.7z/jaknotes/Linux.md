# Text processing
## Redirect STDIN Stream to a File
We can also use the double lower-than characters `<<` to add our standard input through a stream. We can use the so-called End-Of-File `EOF` function of a Linux system file, which defines the input's end
```bash
cat << EOF > stream.txt
```
An option for further locking down Linux systems is Security-Enhanced Linux `SELinux` or `AppArmor`. This is a kernel security module that can be used for security access control policies. In SELinux, every process, file, directory, and system object is given a label. Policy rules are created to control access between these labeled processes and objects and are enforced by the kernel. This means that access can be set up to control which users and applications can access which resources. SELinux provides very granular access controls, such as specifying who can append to a file or move it. Besides, there are different applications and services such as Snort, chkrootkit, rkhunter, Lynis, and others that can contribute to Linux's security.
## Regex
| Option       | Description                                                                        |
| ------------ | ---------------------------------------------------------------------------------- |
| `[abc]`      | Every occurrence of each letter                                                    |
| `[abc]zz`    | Will match azz, bzz and czz                                                        |
| `[a-c]zz`    | Is the same as above                                                               |
| `[a-cx-z]zz` | Will match azz, bzz, czz, xzz, yzz and zzz                                         |
| `[a-zA-Z]`   | Will match any single letter (lowercase or uppercase)                              |
| `file[1-3]`  | Will match file1, file2 and file3                                                  |
| `[^k]ing`    | Will match ring, sing, $ing but not king                                           |
| `[^a-c]at`   | Will match fat and hat, but not bat or cat                                         |
| `[0-9]`      | Will include numbers 0-9                                                           |
| `.`          | Is the wildcard that is used to match any single character (except the line break) |
| `a.c`        | Will match aac, abc, a0c, a!c and so on                                            |
| `a\.c`       | If you want to search for a literal dot                                            |
| `?`          | Character optional                                                                 |
| `abc?`       | Will match ab and abc since c is optional                                          |
| `\d`         | Matches a digit, like 9                                                            |
| `\D`         | Matches a non-digit, like A or @                                                   |
| `\w`         | Matches an alphanumeric character, like a or 3                                     |
| `\W`         | Matches a non-alphanumeric character, like ! or #                                  |
| `\s`         | Matches a whitespace character (spaces, tabs and line breaks)                      |
| `\S`         | Matches everything else (alphanumeric, characters and symbols)                     |
| `{12}`       | Exactly 12 times                                                                   |
| `{1,5}`      | 1 to 5 times                                                                       |
| `{2,}`       | 2 or more times                                                                    |
| `*`          | 0 or more times                                                                    |
| `+`          | 1 or more times                                                                    |

| Operators | Description |
| --------- | ----------- |
| (a) | 	The round brackets are used to group parts of a regex. Within the brackets, you can define further patterns which should be processed together.
| [a-z]| 	The square brackets are used to define character classes. Inside the brackets, you can specify a list of characters to search for.
| {1,10}| 	The curly brackets are used to define quantifiers. Inside the brackets, you can specify a number or a range that indicates how often a previous pattern should be repeated.
| |	| Also called the OR operator and shows results when one of the two expressions matches
| .*	| Also called the AND operator and displayed results only if both expressions match

Suppose we use the OR operator. The regex searches for one of the given search parameters. In the next example, we search for lines containing the word my or false. To use these operators, you need to apply the extended regex using the -E option in grep.
### OR operator
```bash
cry0l1t3@htb:~$ grep -E "(my|false)" /etc/passwd

lxd:x:105:65534::/var/lib/lxd/:/bin/false
pollinate:x:109:1::/var/cache/pollinate:/bin/false
mysql:x:116:120:MySQL Server,,:/nonexistent:/bin/false
```
Since one of the two search parameters always occurs in the three lines, all three lines are displayed accordingly. However, if we use the AND operator, we will get a different result for the same search parameters.
### AND operator
```bash
cry0l1t3@htb:~$ grep -E "(my.*false)" /etc/passwd

mysql:x:116:120:MySQL Server,,:/nonexistent:/bin/false
```
Basically, what we are saying with this command is that we are looking for a line where we want to see both my and false. A simplified example would also be to use grep twice and look like this:
```bash
cry0l1t3@htb:~$ grep -E "my" /etc/passwd | grep -E "false"

mysql:x:116:120:MySQL Server,,:/nonexistent:/bin/false
```

Here are some optional tasks to practice regex that can help us to handle it better and more efficiently. For all exercises, we will use the /etc/ssh/sshd_config file on our Pwnbox instance.
	
1 	Show all lines that do not contain the # character.
2 	Search for all lines that contain a word that starts with Permit.
3 	Search for all lines that contain a word ending with Authentication.
4 	Search for all lines containing the word Key.
5 	Search for all lines beginning with Password and containing yes.
6 	Search for all lines that end with yes.

## vim
| Option           | Description                                                                               |
| ---------------- | ----------------------------------------------------------------------------------------- |
| `/`              | To search                                                                                 |
| `n`              | To search for the same prase again                                                        |
| `N`              | In the opposite direction                                                                 |
| `?`              | To search for a phrase in the backward direction                                          |
| `Ctrl o`         | To go back further                                                                        |
| `Ctrl i`         | Goes forward                                                                              |
| `%`              | Move the cursor to the other `(` or `{`                                                   |
| `:s/old/new/g`   | To substitute 'new' for 'old'                                                             |
| `#,#s/old/new/g` | Where `#` are the line numbers of the range of lines where the substitution is to be done |
| `%s/old/new/gc`  | To find every occurrence in the whole file, with a prompt whether to substitute or not    |
| `!ls`            | Execute an external command                                                               |
| `:set xxx`       | Where `ic` => Ignore upper/lower case when searching. `is` => Show partial matches for a search phrase. `hls` => Highligth all matching phrases                                                                                          |

# Commands
## Find
| Option          | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| --------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `-type d`       | Only directories                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| `-type f`       | Only files                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| `-name`         | Search name                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| `-iname`        | Search name case insensitive                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| `-user`         | The username of the owner of a file                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| `-size -n/+n/n` | Where n is a number. To specify a size, you also need a sufix. c=bytes, k=KB and M=MBs. Example: If you want to specify a size less than 30 bytes, the argument -30c should be used                                                                                                                                                                                                                                                                                           |
| `-perm`         | To specify permissions. You can use `-` prefix to return files with at least the permissions you specify. This means that the -444 mode will match files that are readable by everyone, even if someone also has write and/or execute permissions. Using the `/` prefix will return files that match any of the permissions you have set. This means that the /666 mode will match files that are readable and writeable by at least one of the groups(owner,group or others) |
| `-a`            | Accesed. A file accesed more than 30 minutes ago: `-amin +30`                                                                                                                                                                                                                                                                                                                                                                                                                 |
| `-m`            | Modified. Modified less than 7 days ago: `-mtime -7`. A file modified within the last 24 hours: `-mtime 0`                                                                                                                                                                                                                                                                                                                                                                                                                          |
| `-c`            | Changed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
|`-exec`| Example: `-exec whoami \;`

# Bash scripting
## Useful resource
[Advanced bash scripting](https://tldp.org/LDP/abs/html/)
## To debug code
```bash
set -x and set +x 
```
	#!/bin/bash
## To remove an element in an array
```bash
unset transport[1]
```
## Examples
```bash
if [ x ]; then
  docommand
elif [ y ]; then
  doothercommand
else
  dosomethingelse
fi
```
```bash
//Another
#!/bin/bash
for i in $( ls ); do
  echo item: $i
done
```
```bash
//Other with seq
#!/bin/bash
for i in `seq 1 10`;
do 
  echo $i
done
```
## While loop
```bash
while [condition]; do <command1>;<command2>;done
```
## Read line
```bash
while read line; do echo $line; done < file.txt
```
## Options
| Option | Description |
| ------ | ----------- |
| `-eq`       |      Checks if the value of two operands are equal or not; if yes, then the condition becomes true.       |
| `-ne`| Checks if the value of two operands are equal or not; if values are not equal, then the condition becomes true.
|`-gt`|  Checks if the value of left operand is greater than the value of right operand; if yes, then the condition becomes true.
|`-lt`|  Checks if the value of left operand is less than the value of right operand; if yes, then the condition becomes true.
|`-ge`|  Checks if the value of left operand is greater than or equal to the value of right operand; if yes, then the condition becomes true.
|`-f`| Checks if the file exists
|`-w`| Checks if the file is writable. Without write permissions we would not be able to output our text into the file
| `read`|  To insert text

# Task scheduling
Task scheduling is a feature in Linux systems that allows users to schedule and automate tasks. It allows administrators and users to run tasks at a specific time or within specific frequencies without having to start them manually. It can be used in Linux systems such as Ubuntu, Redhat Linux, and Solaris to manage a variety of tasks. Examples include automatically updating software, running scripts, cleaning databases, and automating backups. This also allows users to schedule regular and repetitive tasks to ensure they are run regularly. In addition, alerts can be set up to display when certain events occur or to contact administrators or users. There are many different use cases for automation of this type, but these cover most cases.
## Systemd
Systemd is a service used in Linux systems such as Ubuntu, Redhat Linux, and Solaris to start processes and scripts at a specific time. With it, we can set up processes and scripts to run at a specific time or time interval and can also specify specific events and triggers that will trigger a specific task. To do this, we need to take some steps and precautions before our scripts or processes are automatically executed by the system.
- Create a timer
- Create a service
- Activate the timer
### Create a Timer
To create a timer for systemd, we need to create a directory where the timer script will be stored.
```bash
m1l0js@htb[/htb]$ sudo mkdir /etc/systemd/system/mytimer.timer.d
m1l0js@htb[/htb]$ sudo vim /etc/systemd/system/mytimer.timer
```
Next, we need to create a script that configures the timer. The script must contain the following options: "Unit", "Timer" and "Install". The "Unit" option specifies a description for the timer. The "Timer" option specifies when to start the timer and when to activate it. Finally, the "Install" option specifies where to install the timer.
```bash
[Unit]
Description=My Timer

[Timer]
OnBootSec=3min
OnUnitActiveSec=1hour

[Install]
WantedBy=timers.target
```
Here it depends on how we want to use our script. For example, if we want to run our script only once after the system boot, we should use `OnBootSec` setting in `Timer`. However, if we want our script to run regularly, then we should use the `OnUnitActiveSec` to have the system run the script at regular intervals. Next, we need to create our service.

### Create a Service
```bash
m1l0js@htb[/htb]$ sudo vim /etc/systemd/system/mytimer.service
```
Here we set a description and specify the full path to the script we want to run. The "multi-user.target" is the unit system that is activated when starting a normal multi-user mode. It defines the services that should be started on a normal system startup.
```bash
[Unit]
Description=My Service

[Service]
ExecStart=/full/path/to/my/script.sh

[Install]
WantedBy=multi-user.target
```
After that, we have to let systemd read the folders again to include the changes.
### Reload Systemd
```bash
m1l0js@htb[/htb]$ sudo systemctl daemon-reload
```
After that, we can use systemctl to start the service manually and enable the autostart.
### Start the Timer & Service
```bash
m1l0js@htb[/htb]$ sudo systemctl start mytimer.service
m1l0js@htb[/htb]$ sudo systemctl enable mytimer.service
```

## Cron
Cron is another tool that can be used in Linux systems to schedule and automate processes. It allows users and administrators to execute tasks at a specific time or within specific intervals. For the above examples, we can also use Cron to automate the same tasks. We just need to create a script and then tell the cron daemon to call it at a specific time.

With Cron, we can automate the same tasks, but the process for setting up the Cron daemon is a little different than Systemd. To set up the cron daemon, we need to store the tasks in a file called crontab and then tell the daemon when to run the tasks. Then we can schedule and automate the tasks by configuring the cron daemon accordingly. The structure of Cron consists of the following components:
| Time Frame             | Description                                                           |
| ---------------------- | --------------------------------------------------------------------- |
| `Minutes (0-59)`         | This specifies in which minute the task should be executed.           |
| Hours (0-23)           | This specifies in which hour the task should be executed.             |
| Days of month (1-31)   | This specifies on which day of the month the task should be executed. |
| Months (1-12)          | This specifies in which month the task should be executed.            |
| Days of the week (0-7) | This specifies on which day of the week the task should be executed.  |

For example, such a crontab could look like this:
```bash
# System Update
* */6 * * /path/to/update_software.sh

# Execute scripts
0 0 1 * * /path/to/scripts/run_scripts.sh

# Cleanup DB
0 0 * * 0 /path/to/scripts/clean_database.sh

# Backups
0 0 * * 7 /path/to/scripts/backup.sh
```

The "System Update" should be executed every sixth hour. This is indicated by the entry `*/6` in the hour column. The task is executed by the script `update_software.sh`, whose path is given in the last column.
The task `execute scripts` is to be executed every first day of the month at midnight. This is indicated by the entries 0 and 0 in the minute and hour columns and 1 in the days-of-the-month column. The task is executed by the `run_scripts.sh` script, whose path is given in the last column.
The third task, `Cleanup DB`, is to be executed every Sunday at midnight. This is specified by the entries 0 and 0 in the minute and hour columns and 0 in the days-of-the-week column. The task is executed by the `clean_database.sh` script, whose path is given in the last column.
The fourth task, `backups`, is to be executed every Sunday at midnight. This is indicated by the entries 0 and 0 in the minute and hour columns and 7 in the days-of-the-week column. The task is executed by the `backup.sh` script, whose path is given in the last column.

It is also possible to receive notifications when a task is executed successfully or unsuccessfully. In addition, we can create logs to monitor the execution of the tasks.
## Systemd vs. Cron

Systemd and Cron are both tools that can be used in Linux systems to schedule and automate processes. The key difference between these two tools is how they are configured. With Systemd, you need to create a timer and services script that tells the operating system when to run the tasks. On the other hand, with Cron, you need to create a crontab file that tells the cron daemon when to run the tasks.
# Web Server
## Apache2
### Install Apache Web Server
```bash
m1l0js@htb[/htb]$ sudo apt install apache2 -y
```
For Apache2, to specify which folders can be accessed, we can edit the file `/etc/apache2/apache2.conf` with a text editor. This file contains the global settings. We can change the settings to specify which directories can be accessed and what actions can be performed on those directories.
### Apache Configuration
```txt
<Directory /var/www/html>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
</directory>
```
This section specifies that the default `/var/www/html` folder is accessible, that users can use the Indexes and FollowSymLinks options, that changes to files in this directory can be overridden with AllowOverride All, and that Require all granted grants all users access to this directory. For example, if we want to transfer files to one of our target systems using a web server, we can put the appropriate files in the `/var/www/html` folder and use wget or curl or other applications to download these files on the target system.

It is also possible to customize individual settings at the directory level by using the `.htaccess` file, which we can create in the directory in question. This file allows us to configure certain directory-level settings, such as access controls, without having to customize the Apache configuration file. We can also add modules to get features like `mod_rewrite`,`mod_security`, and `mod_ssl` that help us improve the security of our web application.

## Python web server
Python Web Server is a simple, fast alternative to Apache and can be used to host a single folder with a single command to transfer files to another system. To install Python Web Server, we need to install Python3 on our system and then run the following command:
### Install Python & Web Server
```bash
m1l0js@htb[/htb]$ sudo apt install python3 -y
m1l0js@htb[/htb]$ python3 -m http.server
```
When we run this command, our Python Web Server will be started on the TCP/8000 port, and we can access the folder we are currently in. We can also host another folder with the following command:
```bash
m1l0js@htb[/htb]$ python3 -m http.server --directory /home/cry0l1t3/target_files
```
This will start a Python web server on the TCP/8000 port, and we can access the /home/cry0l1t3/target_files folder from the browser, for example. When we access our Python web server, we can transfer files to the other system by typing the link in our browser and downloading the files. We can also host our Python web server on a port other than the default port by using the -p option:
```bash
m1l0js@htb[/htb]$ python3 -m http.server 443
```

## VPN
Virtual Private Network (VPN) is a technology that allows us to connect securely to another network as if we were directly in it. This is done by creating an encrypted tunnel connection between the client and the server, which means that all data transmitted over this connection is encrypted.
VPNs are mainly used by companies to provide their employees with secure access to the internal network without having to be physically located at the corporate network. This allows employees to access the internal network and its resources and applications from any location. In addition, VPNs can also be used to anonymize traffic and prevent outside access.
Some of the most popular VPN servers for Linux servers are OpenVPN, L2TP/IPsec, PPTP, SSTP, and SoftEther. OpenVPN is a popular open-source VPN server available for various operating systems, including Ubuntu, Solaris, and Redhat Linux. OpenVPN is used by administrators for various purposes, including enabling secure remote access to the corporate network, encrypting network traffic, and anonymizing traffic.
OpenVPN can also be used by us as a penetration tester to connect to internal networks. It can happen that a VPN access is created by the customer so that we can test the internal network for security vulnerabilities. This is an alternative for cases when the penetration tester is too far away from the customer. OpenVPN provides us with a variety of features, including encryption, tunneling, traffic shaping, network routing, and the ability to adapt to dynamically changing networks. We can install the server and client with the following command:
### Install OpenVPN
```bash
m1l0js@htb[/htb]$ sudo apt install openvpn -y
```
OpenVPN can be customized and configured by editing the configuration file `/etc/openvpn/server.conf`. This file contains the settings for the OpenVPN server. We can change the settings to configure certain features such as encryption, tunneling, traffic shaping, etc.
If we want to connect to an OpenVPN server, we can use the .ovpn file we received from the server and save it on our system. We can do this with the following command on the command line:
### Connect to VPN
```bash
m1l0js@htb[/htb]$ sudo openvpn --config internal.ovpn
```
After the connection is established, we can communicate with the internal hosts on the internal network.
# Backup and restore
Linux systems offer a variety of software tools for backing up and restoring data. These tools are designed to be efficient and secure, ensuring that data is protected while also allowing us to easily access the data we need.

When backing up data on an Ubuntu system, we can utilize tools such as:
- Rsync
- Deja Dup
- Duplicity

Rsync is an open-source tool that allows us to quickly and securely back up files and folders to a remote location. It is particularly useful for transferring large amounts of data over the network, as it only transmits the changed parts of a file. It can also be used to create backups locally or on remote servers. If we need to back up large amounts of data over the network, Rsync might be the better option.

Duplicity is another graphical backup tool for Ubuntu that provides users with comprehensive data protection and secure backups. It also uses Rsync as a backend and additionally offers the possibility to encrypt backup copies and store them on remote storage media, such as FTP servers, or cloud storage services, such as Amazon S3.

Deja Dup is a graphical backup tool for Ubuntu that simplifies the backup process, allowing us to quickly and easily back up our data. It provides a user-friendly interface to create backup copies of data on local or remote storage media. It uses Rsync as a backend and also supports data encryption.

In order to ensure the security and integrity of backups, we should take steps to encrypt their backups. Encrypting backups ensures that sensitive data is protected from unauthorized access. Alternatively, we can encrypt backups on Ubuntu systems by utilizing tools such as GnuPG, eCryptfs, and LUKS.

Backing up and restoring data on Ubuntu systems is an essential part of data protection. By utilizing the tools discussed, we can ensure that our data is securely backed up and can be easily restored when needed.

In order to install Rsync on Ubuntu, we can use the apt package manager:
## Install Rsync
```bash
m1l0js@htb[/htb]$ sudo apt install rsync -y
```
This will install the latest version of Rsync on the system. Once the installation is complete, we can begin using the tool to back up and restore data. To backup an entire directory using rsync, we can use the following command:
## Rsync - Backup a local Directory to our Backup-Server
```bash
m1l0js@htb[/htb]$ rsync -av /path/to/mydirectory user@backup_server:/path/to/backup/directory
```
This command will copy the entire directory (/path/to/mydirectory) to a remote host (backup_server), to the directory /path/to/backup/directory. The option archive (-a) is used to preserve the original file attributes, such as permissions, timestamps, etc., and using the verbose (-v) option provides a detailed output of the progress of the rsync operation.

We can also add additional options to customize the backup process, such as using compression and incremental backups. We can do this like the following:
```bash
m1l0js@htb[/htb]$ rsync -avz --backup --backup-dir=/path/to/backup/folder --delete /path/to/mydirectory user@backup_server:/path/to/backup/directory
```
With this, we back up the mydirectory to the remote backup_server, preserving the original file attributes, timestamps, and permissions, and enabled compression `-z` for faster transfers. The `--backup` option creates incremental backups in the directory /path/to/backup/folder, and the `--delete` option removes files from the remote host that is no longer present in the source directory.

## Rsync - Restore our Backup
If we want to restore our directory from our backup server to our local directory, we can use the following command:
```bash
m1l0js@htb[/htb]$ rsync -av user@remote_host:/path/to/backup/directory /path/to/mydirectory
```

## Encrypted Rsync
To ensure the security of our rsync file transfer between our local host and our backup server, we can combine the use of SSH and other security measures. By using SSH, we are able to encrypt our data as it is being transferred, making it much more difficult for any unauthorized individual to access it. Additionally, we can also use firewalls and other security protocols to ensure that our data is kept safe and secure during the transfer. By taking these steps, we can be confident that our data is protected and our file transfer is secure. Therefore we tell rsync to use SSH like the following:
### Secure Transfer of our Backup
```bash
m1l0js@htb[/htb]$ rsync -avz -e ssh /path/to/mydirectory user@backup_server:/path/to/backup/directory
```
The data transfer between our local host and the backup server occurs over the encrypted SSH connection, which provides confidentiality and integrity protection for the data being transferred. This encryption process ensures that the data is protected from any potential malicious actors who would otherwise be able to access and modify the data without authorization. The encryption key itself is also safeguarded by a comprehensive set of security protocols, making it even more difficult for any unauthorized person to gain access to the data. In addition, the encrypted connection is designed to be highly resistant to any attempts to breach security, allowing us to have confidence in the protection of the data being transferred.
## Auto-Synchronization
To enable auto-synchronization using rsync, you can use a combination of cron and rsync to automate the synchronization process. Scheduling the cron job to run at regular intervals ensures that the contents of the two systems are kept in sync. This can be especially beneficial for organizations that need to keep their data synchronized across multiple machines. Furthermore, setting up auto-synchronization with rsync can be a great way to save time and effort, as it eliminates the need for manual synchronization. It also helps to ensure that the files and data stored in the systems are kept up-to-date and consistent, which helps to reduce errors and improve efficiency.

Therefore we create a new script called `RSYNC_Backup.sh`, which will trigger the rsync command to sync our local directory with the remote one.
### RSYNC_Backup.sh
```bash
#!/bin/bash

rsync -avz -e ssh /path/to/mydirectory user@backup_server:/path/to/backup/directory
```
Then, in order to ensure that the script is able to execute properly, we must provide the necessary permissions. Additionally, it's also important to make sure that the script is owned by the correct user, as this will ensure that only the correct user has access to the script and that the script is not tampered with by any other user.
```bash
m1l0js@htb[/htb]$ chmod +x RSYNC_Backup.sh
```
After that, we can create a crontab that tells `cron` to run the script every hour at the 0th minute. We can adjust the timing to suit our needs. To do so, the crontab needs the following content:
### Auto-Sync - Crontab
```bash
0 * * * * /path/to/RSYNC_Backup.sh
```
With this setup, cron will be responsible for executing the script at the desired interval, ensuring that the rsync command is run and the contents of the local directory are synchronized with the remote host.
# File system management
File system management on Linux is a complex process that involves organizing and maintaining the data stored on a disk or other storage device. Linux is a powerful operating system that supports a wide range of file systems, including ext2, ext3, ext4, XFS, Btrfs, NTFS, and more. Each of these file systems offers unique features and benefits, and the best choice for any given situation will depend upon the specific requirements of the application or user. For example, ext2 is suitable for basic file system management tasks, while Btrfs offers robust data integrity and snapshot capabilities. Additionally, NTFS is useful when compatibility with Windows is required. No matter the situation, it is important to properly analyze the needs of the application or user before selecting a file system.

The Linux file system is based on the Unix file system, which is a hierarchical structure that is composed of various components. At the top of this structure is the inode table, the basis for the entire file system. The inode table is a table of information associated with each file and directory on a Linux system. Inodes contain metadata about the file or directory, such as its permissions, size, type, owner, and so on. The inode table is like a database of information about every file and directory on a Linux system, allowing the operating system to quickly access and manage files. Files can be stored in the Linux file system in one of two ways:

- Regular files
- Directories

Regular files are the most common type of file, and they are stored in the root directory of the file system. Directories are used to store collections of files. When a file is stored in a directory, the directory is known as the parent directory for the files. In addition to regular files and directories, Linux also supports symbolic links, which are references to other files or directories. Symbolic links can be used to quickly access files that are located in different parts of the file system. Each file and directory needs to be managed in terms of permissions. Permissions control who has access to files and directories. Each file and directory has an associated set of permissions that determines who can read, write, and execute the file. The same permissions apply to all users, so if the permissions of one user are changed, all other users will also be affected.
```bash
m1l0js@htb[/htb]$ ls -il

total 0
10678872 -rw-r--r--  1 cry0l1t3  htb  234123 Feb 14 19:30 myscript.py
10678869 -rw-r--r--  1 cry0l1t3  htb   43230 Feb 14 11:52 notes.txt
```
## Disks & Drives
Disk management on Linux involves managing physical storage devices, including hard drives, solid-state drives, and removable storage devices. The main tool for disk management on Linux is the fdisk, which allows us to create, delete, and manage partitions on a drive. It can also display information about the partition table, including the size and type of each partition. Partitioning a drive on Linux involves dividing the physical storage space into separate, logical sections. Each partition can then be formatted with a specific file system, such as ext4, NTFS, or FAT32, and can be mounted as a separate file system. The most common partitioning tool on Linux is also `fdisk`, `gpart`, and `GParted`.
### Fdisk
```bash
m1l0js@htb[/htb]$ sudo fdisk -l

Disk /dev/vda: 160 GiB, 171798691840 bytes, 335544320 sectors
Units: sectors of 1 * 512 = 512 bytes
Sector size (logical/physical): 512 bytes / 512 bytes
I/O size (minimum/optimal): 512 bytes / 512 bytes
Disklabel type: dos
Disk identifier: 0x5223435f

Device     Boot     Start       End   Sectors  Size Id Type
/dev/vda1  *         2048 158974027 158971980 75.8G 83 Linux
/dev/vda2       158974028 167766794   8792767  4.2G 82 Linux swap / Solaris

Disk /dev/vdb: 452 KiB, 462848 bytes, 904 sectors
Units: sectors of 1 * 512 = 512 bytes
Sector size (logical/physical): 512 bytes / 512 bytes
I/O size (minimum/optimal): 512 bytes / 512 bytes
```
## Mounting
Each logical partition or drive needs to be assigned to a specific directory on Linux. This process is called mounting. Mounting involves attaching a drive to a specific directory, making it accessible to the file system hierarchy. Once a drive is mounted, it can be accessed and manipulated just like any other directory on the system. The mount tool is used to mount file systems on Linux, and the /etc/fstab file is used to define the default file systems that are mounted at boot time.
### Mounted File systems at Boot
```bash
m1l0js@htb[/htb]$ cat /etc/fstab

# /etc/fstab: static file system information.
#
# Use 'blkid' to print the universally unique identifier for a device; this may
# be used with UUID= as a more robust way to name devices that works even if
# disks are added and removed. See fstab(5).
#
# <file system>                      <mount point>  <type>  <options>  <dump>  <pass>
UUID=3d6a020d-...SNIP...-9e085e9c927a /              btrfs   subvol=@,defaults,noatime,nodiratime,nodatacow,space_cache,autodefrag 0 1
UUID=3d6a020d-...SNIP...-9e085e9c927a /home          btrfs   subvol=@home,defaults,noatime,nodiratime,nodatacow,space_cache,autodefrag 0 2
UUID=21f7eb94-...SNIP...-d4f58f94e141 swap           swap    defaults,noatime 0 0
```
To view the currently mounted file systems, we can use the "mount" command without any arguments. The output will show a list of all the currently mounted file systems, including the device name, file system type, mount point, and options.
### List Mounted Drives
```bash
m1l0js@htb[/htb]$ mount

sysfs on /sys type sysfs (rw,nosuid,nodev,noexec,relatime)
proc on /proc type proc (rw,nosuid,nodev,noexec,relatime)
udev on /dev type devtmpfs (rw,nosuid,relatime,size=4035812k,nr_inodes=1008953,mode=755,inode64)
devpts on /dev/pts type devpts (rw,nosuid,noexec,relatime,gid=5,mode=620,ptmxmode=000)
tmpfs on /run type tmpfs (rw,nosuid,nodev,noexec,relatime,size=814580k,mode=755,inode64)
/dev/vda1 on / type btrfs (rw,noatime,nodiratime,nodatasum,nodatacow,space_cache,autodefrag,subvolid=257,subvol=/@)
```
### Mount a USB drive
To mount a file system, we can use the mount command followed by the device name and the mount point. For example, to mount a USB drive with the device name /dev/sdb1 to the directory /mnt/usb, we would use the following command:
```bash
m1l0js@htb[/htb]$ sudo mount /dev/sdb1 /mnt/usb
m1l0js@htb[/htb]$ cd /mnt/usb && ls -l

total 32
drwxr-xr-x 1 root root   18 Oct 14  2021 'Account Takeover'
drwxr-xr-x 1 root root   18 Oct 14  2021 'API Key Leaks'
drwxr-xr-x 1 root root   18 Oct 14  2021 'AWS Amazon Bucket S3'
drwxr-xr-x 1 root root   34 Oct 14  2021 'Command Injection'
drwxr-xr-x 1 root root   18 Oct 14  2021 'CORS Misconfiguration'
drwxr-xr-x 1 root root   52 Oct 14  2021 'CRLF Injection'
drwxr-xr-x 1 root root   30 Oct 14  2021 'CSRF Injection'
drwxr-xr-x 1 root root   18 Oct 14  2021 'CSV Injection'
drwxr-xr-x 1 root root 1166 Oct 14  2021 'CVE Exploits'
...SNIP...
```
### Unmount
To unmount a file system in Linux, we can use the umount command followed by the mount point of the file system we want to unmount. The mount point is the location in the file system where the file system is mounted and is accessible to us. For example, to unmount the USB drive that was previously mounted to the directory /mnt/usb, we would use the following command:
```bash
m1l0js@htb[/htb]$ sudo umount /mnt/usb
```
It is important to note that we must have sufficient permissions to unmount a file system. We also cannot unmount a file system that is in use by a running process. To ensure that there are no running processes that are using the file system, we can use the lsof command to list the open files on the file system.
```bash
cry0l1t3@htb:~$ lsof | grep cry0l1t3

vncserver 6006        cry0l1t3  mem       REG      0,24       402274 /usr/bin/perl (path dev=0,26)
vncserver 6006        cry0l1t3  mem       REG      0,24      1554101 /usr/lib/locale/aa_DJ.utf8/LC_COLLATE (path dev=0,26)
vncserver 6006        cry0l1t3  mem       REG      0,24       402326 /usr/lib/x86_64-linux-gnu/perl-base/auto/POSIX/POSIX.so (path dev=0,26)
vncserver 6006        cry0l1t3  mem       REG      0,24       402059 /usr/lib/x86_64-linux-gnu/perl/5.32.1/auto/Time/HiRes/HiRes.so (path dev=0,26)
vncserver 6006        cry0l1t3  mem       REG      0,24      1444250 /usr/lib/x86_64-linux-gnu/libnss_files-2.31.so (path dev=0,26)
vncserver 6006        cry0l1t3  mem       REG      0,24       402327 /usr/lib/x86_64-linux-gnu/perl-base/auto/Socket/Socket.so (path dev=0,26)
vncserver 6006        cry0l1t3  mem       REG      0,24       402324 /usr/lib/x86_64-linux-gnu/perl-base/auto/IO/IO.so (path dev=0,26)
...SNIP...
```
## Fstab File
If we find any processes that are using the file system, we need to stop them before we can unmount the file system. Additionally, we can also unmount a file system automatically when the system is shut down by adding an entry to the `/etc/fstab` file. The /etc/fstab file contains information about all the file systems that are mounted on the system, including the options for automatic mounting at boot time and other mount options. To unmount a file system automatically at shutdown, we need to add the `noauto` option to the entry in the /etc/fstab file for that file system. This would like, for example, like following:
```txt
/dev/sda1 / ext4 defaults 0 0
/dev/sda2 /home ext4 defaults 0 0
/dev/sdb1 /mnt/usb ext4 rw,auto,user 0 0
192.168.1.100:/nfs /mnt/nfs nfs defaults 0 0
```
## SWAP
Swap space is a crucial aspect of memory management in Linux, and it plays an important role in ensuring that the system runs smoothly, even when the available physical memory is depleted. When the system runs out of physical memory, the kernel transfers inactive pages of memory to the swap space, freeing up physical memory for use by active processes. This process is known as swapping.

Swap space can be created either during the installation of the operating system or at any time afterward using the mkswap and swapon commands. The mkswap command is used to set up a Linux swap area on a device or in a file, while the swapon command is used to activate a swap area. The size of the swap space is a matter of personal preference and depends on the amount of physical memory installed in the system and the type of usage the system will be subjected to. When creating a swap space, it is important to ensure that it is placed on a dedicated partition or file, separate from the rest of the file system. This helps to prevent fragmentation of the swap space and ensures that the system has adequate swap space available when it is needed. It is also important to ensure that the swap space is encrypted, as sensitive data may be stored in the swap space temporarily.

In addition to being used as an extension of physical memory, swap space can also be used for hibernation, which is a power management feature that allows the system to save its state to disk and then power off instead of shutting down completely. When the system is later powered on, it can restore its state from the swap space, returning to the state it was in before it was powered off.
Linux systems offer a variety of software tools for backing up and restoring data. These tools are designed to be efficient and secure, ensuring that data is protected while also allowing us to easily access the data we need.

