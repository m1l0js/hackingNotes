# Vulnerable machines/applications
1. [OWASP Juice Shop](https://owasp.org/www-project-juice-shop/): Is a modern vulnerable web application written in Node.js, Express, and Angular which showcases the entire OWASP Top Ten along with many other real-world application security flaws
2. [Metasploitable 2](https://docs.rapid7.com/metasploit/metasploitable-2-exploitability-guide/) : Is a purposefully vulnerable Ubuntu Linux VM that can be used to practice enumeration, automated, and manual exploitation
4. [Metasploitable 3](https://github.com/rapid7/metasploitable3): Is a template for building a vulnerable Windows VM configured with a wide range of vulnerabilities.
5. [DVWA ](https://github.com/digininja/DVWA): This is a vulnerable PHP/MySQL web application showcasing many common web application vulnerabilities with varying degrees of difficulty

# Youtube channels
- [IppSec](https://ippsec.rocks/?#)
- VbScrub: HTB videos mainly focusing on AD exploitation
- STÖK : Bug bounties and web pentest
- LiveOverflow 

# Blogs
1. [0xdf](https://0xdf.gitlab.io/)
2. [RastaMouse](https://rastamouse.me/) writes excellent content on Red-Teaming, C2 infrastructure, pivoting, payloads, etc. 
3. [SpecterOps](https://posts.specterops.io/offensive-security-guide-to-ssh-tunnels-and-proxies-b525cbd4d4c6) has written a great post covering SSH Tunneling and the use of proxies over a multitude of protocols. It's a must-read for anyone looking to know more about the subject and would make a handy resource to have during an engagement.
4. [SANS](https://www.sans.org/webcasts/dodge-duck-dip-dive-dodge-making-the-pivot-cheat-sheet-119115/) puts out plenty of great infosec related information and webcasts like the one linked here are a great example of that. This will cover many different Pivoting tools and avenues of use.
5. [Plaintext's Pivoting Workshop](https://youtu.be/B3GxYyGFYmQ) is an incredible workshop that our very own Academy Training Developer, Plaintext, put together to help prepare players for Cyber Apocalypse CTF 2022. The workshop is delivered in an engaging & entertaining manner, and viewers will benefit from it for years to come. Check it out if you get the chance.
# Tutorial websites
1. [underthewire](https://www.underthewire.tech/)
2. [overthewire](https://overthewire.org/wargames/)
3. [hacking apis](https://www.apisec.ai/)


# Usage of tools
1. [socat](https://blog.ropnop.com/upgrading-simple-shells-to-fully-interactive-ttys/#method-2-using-socat)
2. [Draw.io](https://draw.io/) //Network diagram
3. [iptables](https://www.frozentux.net/iptables-tutorial/iptables-tutorial.html)
sslscan

# LOL
1. [Linux](https://lolbas-project.github.io/)
2. [Windows](https://gtfobins.github.io/)

# List of ports
1. [All ports](https://web.mit.edu/rhel-doc/3/RH-DOCS/rhel-sg-en-4/ch-ports.html)
2. [Common ports](https://packetlife.net/media/library/22/common-ports.pdf)

# Coding exercises
1. [Rosettacode.org](https://rosettacode.org/wiki/Execute_a_system_command)

# Hacking for bounties
1. [hackerone](https://www.hackerone.com/)
2. [bugcrowd](https://bugcrowd.com/)

# Useful tools
1. [diagram](https://app.diagrams.net/))