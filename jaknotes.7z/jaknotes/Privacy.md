# Firejail
```bash
firejail --private --dns=1.1.1.1 --dns=9.9.9.9 firefox -no-remote
firejail --private=/home/m1l0js/work firefox --dns=1.1.1.1 --dns=9.9.9.9 -no-remote &
```
