# IPs
```bash
└─$ dig statcounter.com A | grep 104 | awk '{print $5}'
104.20.218.77
104.20.219.77
```

