# Salario de un trabajador
```c
#include <stdio.h>

int main() 
{
    int horasTrabajadas;
    float costoHora;
    float sueldo;
    printf("Ingrese las horas trabajadas por empleado: ");
    scanf("%i",&horasTrabajadas);
    printf("Ingrese el pago por hora: ");
    scanf("%f",&costoHora);
    sueldo=horasTrabajadas*costoHora;
    printf("El sueldo total del operario es: ");
    printf("%f",sueldo);
    getch();
    return 0;
}

```
# Superficie de un cuadrado
```C
#include <stdio.h>

int main()
{
        float lado;
        float superficie;
        printf("Introduce el lado: ");
        scanf("%f",&lado);
        superficie = lado * lado;
        printf("La superficie es: ");
        printf("%f", superficie);
        getchar();
        return 0;
}
```