# Diagrama de flujo
![Representacion grafica de un algoritmo](https://www.tutorialesprogramacionya.com/cya/imagentema/foto001.jpg)

- La función `main` es la primera que se ejecuta al iniciarse un programa en el lejguaje C
- Tener en cuenta que debemos ingresar el caracter "." en lugar del caracter "," si ingresamos un costo por hora con decimales
- En C las palabras claves deben ir obligatoriamente en minúsculas, sino se produce un error sintáctico. Ej:  `int` horasTrabajadas
- Se propone que el nombre de la variable comience con minúscula y en caso de estar constituida por dos palabras o más deben ir en mayúsculas el primer caracter (un nombre de variable no puede tener espacios en blanco, empezar con un número, ni tampoco utilizar caracteres especiales)
- Para hacer la entrada de datos por teclado en C debemos utilizar la función `scanf`
- La función `getch()` (detiene la ejecución del programa hasta que se presiona una tecla
- Tener en cuenta que el lenguaje C es sensible a mayúsculas y minúsculas por lo que no podemos escribir:
```C
#INCLUDE<stdio.h>
```
Para poder utilizar las funciones printf y scanf debemos importar el archivo donde se las declaran:
`#include<stdio.h>`

Para poder utilizar la función getch debemos importar:
`#include<conio.h>`
# Operadores
## Operadores Relacionales:
```C
>  (mayor)	
<  (menor)
>= (mayor o igual)
<= (menor o igual)
== (igual)
!= (distinto)
```

## Operadores Matemáticos
```C
+ (más)
- (menos)
* (producto)
/ (división)
% (resto de una división)  Ej.:  x=13%5;  {se guarda 3}``
```
## Operadores logicos
```txt
&&
||).
```
# Comentarios
Para definir un comentario en nuestro programa en C debemos anteceder dos caracteres //  
Todo lo que dispongamos después de estos caracteres el compilador no lo tiene en cuenta y solo le es útil al programador para recordar el objetivo de esa parte del algoritmo:
```c
//Carga del vector
```
# Array
Un vector en el lenguaje C es una estructura de datos que permite almacenar un CONJUNTO de datos del MISMO tipo. Con un único nombre se define un vector y por medio de un subíndice hacemos referencia a cada elemento del mismo (componente)
```c
int sueldos[5]
```
La estructura de programación que más se adapta para cargar en forma completa las componentes de un vector es un for, ya que sabemos de antemano la cantidad de valores a cargar, de todos modos no es obligatorio tener que utilizar un for.
Para mostrar solo dos decimales antecedemos un 0.2 a la f en la cadena de formato de la función printf:
```c
printf("%0.2f",promedio);
```
## Vectores (mayor y menor elemento)
```C
#include <stdio.h>


void cargaValores(float simpleVector[5])
{
    for(int x=0;x<5;x++)
    {
        printf("Inserte valor: ");
        scanf("%f",&simpleVector[x]);
    }
}


void ordenarValores(float sueldos[5])
{
    float aux = sueldos[0];
    for(int k=0;k<4;k++)
    {
        for(int x=0;x<4-k;x++)
        {
            if(sueldos[x] > sueldos[x+1])
            {
                aux = sueldos[x];
                sueldos[x] = sueldos[x+1];
                sueldos[x+1] = aux;
            }
        }
    }
}

void imprimirValores(float sueldos[5])
{
    for(int x=0;x<5;x++)
    {
        printf("\n%0.2f",sueldos[x]);
    }

}
int main() 
{
    float elementos[5];
    cargaValores(elementos);
    ordenarValores(elementos);
    imprimirValores(elementos);
    printf("\n");
    getchar();
    return 0;
}
```
#  Estructura de datos tipo matriz
## Elementos int y float
Una matriz es una estructura de datos que permite almacenar un CONJUNTO de datos del MISMO tipo.  

Con un único nombre se define la matriz y por medio de DOS subíndices hacemos referencia a cada elemento de la misma (componente)
![](https://www.tutorialesprogramacionya.com/cya/imagentema/foto053.jpg)
Hemos graficado una matriz de 3 filas y 5 columnas. Para hacer referencia a cada elemento debemos indicar primero la fila y luego la columna, por ejemplo en la componente 1,4 se almacena el valor 97.  
En este ejemplo almacenamos valores enteros. Todos los elementos de la matriz deben ser del mismo tipo.  
Las filas y columnas comienzan a numerarse a partir de cero, similar a los vectores.
```C
void cargar(int mat[3][5])
{
    int f,c;
    for(f=0;f<3;f++)
    {
        for(c=0;c<5;c++)
        {
            printf("Ingrese componente:");
            scanf("%i",&mat[f][c]);
        }
    }
}
```
## Elementos char
Las matrices de tipo de dato char se utilizan fundamentalmente para guardar un conjunto de cadenas de caracteres (varios nombres de personas, nombres de artículos etc.)

Cuando trabajamos una matriz de tipo char para almacenar cadenas de caracteres cada fila almacena un string:

![matrices de tipo char en lenguaje C](https://www.tutorialesprogramacionya.com/cya/imagentema/foto054.jpg)  

Para trabajar una matriz de tipo char se parece a trabajar con un vector, debemos indicar un solo subíndice y estaremos accediendo a toda la fila.
```C
#include<stdio.h>
#include<conio.h>

void cargar(char articulos[3][31])
{
    int f;
    for(f=0;f<3;f++)
    {
        printf("Ingrese el nombre del articulo:");
        gets(articulos[f]);
    }
}

void imprimir(char articulos[3][31])
{
    int f;
    printf("Listado completo de articulos\n");
    for(f=0;f<3;f++)
    {
        printf("%s\n",articulos[f]);
    }
}


int main()
{
    char articulos[3][31];
    cargar(articulos);
    imprimir(articulos);
    getch();
    return 0;
}
```
# Tipo de dato char
En una variable de tipo char podemos almacenar un valor entero comprendido entre -128 y 127. Como podemos ver cuando asignamos el valor del caracter ASCII debemos encerrarlo entre comillas simples.
```C
char letra2='A';
char letra1=65;
```
Para la carga de un valor de tipo char por teclado empleamos la función scanf y en el primer parámetro indicamos en la cadena de formato que se trata de un caracter el dato a ingresar " %c" y será fundamental agregar un espacio en blanco previo al caracter %. El espacio en blanco libera el valor que queda en el buffer del teclado luego de ingresar el entero
```C
scanf(" %c",&letra3);
```
Tener en cuenta que una variable char es idéntica a una variable int con la salvedad que puede tomar valores comprendidos entre -128 y 127. Una variable char podemos asignarle directamente un entero comprendido entre -128 y 127:
```c
char letra1=65;
```
Luego si imprimimos indicando en la función printf que se trata de un caracter %c lo que se obtiene es el valor para dicho caracter ASCII, es decir la letra A:
```c
printf("%c",letra1);
```
## Tabla caracteres ASCII
Los valores enteros positivos de las variables de tipo char están relacionadas con la tabla de caracteres ASCII:

```txt
ASCII Valor
0     NUL 
1
2
3
4
5
6
7
8
9     TAB
10    LF
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32    Tecla espaciadora
33    !
34    "
35    #
36    $
37    %
38    &
39    '
40    (
41    )
42    *
43    +
44    ,
45    -
46    .
47    /
48    0
49    1
50    2
51    3
52    4
53    5
54    6
55    7
56    8
57    9
58    :
59    ;
60    %lt;
61    =
62    >
63    ?
64    @
65    A
66    B
67    C
68    D
69    E
70    F
71    G
72    H
73    I
74    J
75    K
76    L
77    M
78    N
79    O
80    P
81    Q
82    R
83    S
84    T
85    U
86    V
87    W
88    X
89    Y
90    Z
91    [
92    \
93    ] 
94    ^
95    _
96    `
97    a
98    b
99    c
100   d 
101   e
102   f
103   g
104   h
105   i
106   j
107   k
108   l
109   m
110   n
111   o
112   p
113   q
114   r
115   s
116   t
117   u
118   v
119   w
120   x
121   y
122   z
123   {
124   |
125   }
126   ~
127   
```

# Cadenas o vectores de caracteres en C (elementos de tipo char)
Para definir un vector de caracteres en C debemos indicar entre corchetes la cantidad de caracteres a reservar y tener en cuenta que uno de esas posiciones se utilizará como caracter de control, es decir que si tenemos que almacenar 10 caracteres al vector lo definiremos de 11 caracteres.
En memoria se almacenan en cada posición del vector el caracter respectivo y cuando se ejecuta el programa y se muestran los datos mediante la función printf se muestran todos hasta que encuentra el caracter NULL que coincide con el caracter ASCII 0. No hay problema si el vector reserva más de 16 caracteres, en cambio se generarán errores inesperados si el vector tiene menos de 16 caracteres.
```C
componente   [0]  [1]  [2]  [3]  [4]  [5]  [6]  [7]  [8]  [9]  [10] [11] [12] [13] [14] [15]
programador  'P'  'a'  'b'  'l'  'o'  ' '  'R'  'o'  'd'  'r'  'i'  'g'  'u'  'e'  'z'  '\0'
```
Lo que se almacena luego del caracter '\0' no nos importa y se lo considera basura (puede haber cualquier caracter ASCII). Para imprimir un vector de caracteres con la función printf debemos indicar en la cadena de formato el caracter s (string):
```C
printf("%s",programador);
```
## Carga por teclado de una cadena con `gets`
Para cargar por teclado una cadena de caracteres debemos emplear por ahora la función gets. La función gets tiene como parámetro el nombre de la variable:
```C
gets(nombre del vector);
```
El problema de esta función que si el operador carga más caracteres que los reservados en la variable produce errores inesperados. Más adelante veremos otras soluciones de carga de cadenas de caracteres.
Algo nuevo que hay que tener en cuenta cuando hacemos la entrada de datos por teclado es que luego de cargar la edad1 mediante la función scanf queda en el buffer de teclado el valor de la tecla "enter", luego para eliminarlo y que no se cargue en la siguiente variable debemos llamar a la función fflush. Si probamos de no llamar a la función fflush podremos comprobar que en la variable "nombre2" se carga una cadena vacía.
```C
fflush(stdin);
```
Otra cosa que iremos incorporando a partir de ahora con la función printf es la impresión de mensajes y múltiples variables con la llamada de una única vez a printf:
```C
printf("La cantidad de vocales que tiene la palabra %s es %i",palabra,cant);
```
## Funciones que facilitan el trabajo con cadenas de caracteres `string.h`
```C
#include <string.h>
```
### Using strlen
Tener en cuenta que la llamada a la función strlen nos evita implementar el while con el contador de caracteres:
```C
while (palabra[cant]!='\0')
```
### Using strcmp
Hasta ahora no desarrollamos programas que comparen el contenido de dos cadenas de caracteres. Lo primero que hay que decir que no están definidos los operadores relacionales `==, >, <` etc. Es incorrecto tratar de comparar si dos cadenas son iguales.
```C
~~if (nombre1==nombre2)~~
```
Podemos implementar nosotros un análisis dentro de un while y comparar caracter a caracter, pero este algoritmo no es tan fácil y cómodo de implementar cada vez que tenemos que comparar dos cadenas. Entonces el lenguaje C tiene otra función llamada strcmp que le pasamos dos cadenas a comparar y nos retorna un entero:
```C
int strcmp(cadena1,cadena2)
```
- Retorna un cero si las dos cadenas son exactamente iguales.
- Retorna un valor mayor a cero si la cadena1 es mayor alfabéticamente que la segunda.
- Retorna un valor menor a cero si la cadena2 es mayor alfabéticamente que la primera.
#### #### Funcionamiento interno de strcmp.
Definimos dos cadenas de 7 elementos y las inicializamos:
```C
char cadena1[7]="Bien";
char cadena2[7]="Bueno";
```
El contenido de las componente de cada una de las cadenas es el siguiente:
```C
componente	[0]	[1]	[2]	[3]	[4]	[5]	[6]
cadena1	        ‘B’	‘i’	‘e’	‘n’	‘\0’
cadena2	        ‘B’	‘u’	‘e’	‘n’	‘o’	‘\0’
```
El contenido de las componente de cada una de las cadenas (en valores ASCII) es el siguiente:
```C
componente	[0]	[1]	[2]	[3]	[4]	[5]	[6]
cadena1	        66	105	101	110	0
cadena2	        66	117	101	110	111	0
```
Seguidamente llamamos a la función strcmp, la cual devuelve un valor entero que le asignamos a una variable resultado:
```C
int resultado=strcmp(cadena1,cadena2);
```
Internamente la función hace lo siguiente:  
Resta al valor ASCII de la primer componente de cadena1 (66) el valor de la primer componente de cadena2 (66). Como el resultado es cero (0), continúa con la siguiente componente. Resta al valor de la segunda componente de cadena1 (105) el valor de la segunda componente de cadena2 (117), como el resultado es diferente de cero no sigue comparando y devuelve ese valor (-12):
```C
componente	[0]	[1]	[2]	[3]	[4]	[5]
cadena1	        66	105	101	110	0
cadena2	        66	117	101	110	111	0
Resultado	 0	-12
```

Esa es la explicación de porque strcmp retorna 0 si son iguales las dos cadenas y un valor mayor a 0 si la primer cadena es mayor a la segunda y viceversa.
### Using strcpy
Hemos visto que si necesitamos comparar dos string (string es sinónimo de cadenas de caracteres o vectores) no tenemos disponibles los operadores relacionales `==, >` etc.  Si necesitamos copiar un string en otro tampoco funciona el operador de asignación =, para resolver este problema el lenguaje C nos proporciona la función srtcpy. La función strcpy tiene dos parámetros de tipo string, al primer parámetro se le copia el string del segundo parámetro:
```C
strcpy(cadena1,cadena2)
```
Es decir que en cadena1 se copia el contenido de cadena2, si ya tenía información previa cadena1 se le borra el contenido anterior.
Si en un problema necesitamos dejar un string vacío podemos utilizar la función strcpy pasando un string sin caracteres (no debe haber ni un espacio en blanco):
```C
strcpy(cadena,"");
```
Otra forma de hacer lo mismo sin utilizar la función strpy es asignar el terminador de cadena a la primer posición del string:
```C
cadena[0]='\0';
```
### Using strcat
Si necesitamos agregar a un string otro string podemos utilizar la función strcat. La función strcat tiene dos parámetros de tipo string, al primer parámetro se le añade o agrega al final el string del segundo parámetro, es obligatorio que el primer parámetro esté inicializado:
```C
strcat(cadena1,cadena2)
```
# Funciones
## Concepto de funciones
Previo al nombre de la función indicamos el dato que devuelve la función, con la palabra clave void indicamos que la función no retorna valor (no requiere que tenga la palabra clave return como hemos dispuesto siempre en la función main)

Luego del nombre de la función indicamos entre paréntesis los parámetros, si no los tiene disponemos los paréntesis abiertos y cerrados y no disponemos un punto y coma al final:

```C
void cargaSuma()
{
    int valor1,valor2,suma;
    printf("Ingrese el primer valor:");
    scanf("%i",&valor1);
    printf("Ingrese el segundo valor:");
    scanf("%i",&valor2);
    suma=valor1+valor2;
    printf("La suma de los dos valores es: %i",suma);
}
```
La función cargaSuma no tiene parámetros y no devuelve datos (void)

Dentro del algoritmo de la función cargaSuma definimos tres variables llamadas locales a la función cargaSuma. Estas variables solo existen mientras se ejecuta la función cargaSuma y no pueden ser utilizadas por las otras funciones de nuestro programa.

## Funciones con parametros de tipo int, float y char
La sintaxis cuando una función recibe parámetros es:
```txt
[valor que retorna]   [nombre de la función] ([parámetros de la función])
{
    [altoritmo]
}
```

No hay ningún problema que las variables que definimos en la función main se llamen igual que los parámetros definidos en la otra función:
```C
int main()
{
    float costoHora;
    int cantidadHoras;
```

Y los parámetros de la otra función:
```C
void calcularSueldo(float costoHora, int cantidadHoras)
```

Pero recordar que en la memoria de la computadora se almacenan en lugares distintos las variables de la función main y los parámetros de la función calcularSueldo.

## Funciones con retorno de un valor
Hay un cambio importante cuando llamamos o invocamos a una función que devuelve un dato:
```C
sup=retornarSuperficie(valor);
```

Es decir el valor devuelto por la función retornarSuperficie se almacena en la variable sup.
Es un error lógico llamar a la función retornarSuperficie y no asignar el valor a una variable:

```C
retornarSuperficie(valor);
```

El dato devuelto por la función(en nuestro caso la superficie del cuadrado) no se almacena y se pierde sin que podamos imprimirlo.

Si podemos utilizar el valor devuelto para pasarlo a otra función como por ejemplo a printf:

```C
printf("La superficie del cuadrado es %i",retornarSuperficie(valor));
```

La función retornarSuperficie devuelve un entero y se lo pasamos a la función printf para que lo muestre.

Ahora podemos entender porque la función main tiene obligatoriamente la palabra clave return al final devolviendo un 0. Es obligatorio que la función main retorne un int. El dato devuelto podrá ser capturado si nuestro programa es llamado desde otro programa.

Cuando una función encuentra la palabra return no sigue ejecutando el resto de la función sino que sale a la línea del programa desde donde llamamos a dicha función.
## # Funciones con parámetros de tipo vector
Vimos en conceptos anteriores que un vector en el lenguaje C es una estructura de datos que permite almacenar un CONJUNTO de datos del MISMO tipo. Con un único nombre se define el vector y por medio de un subíndice hacemos referencia a cada elemento del mismo (componente)

Ahora veremos que una función puede recibir como parámetros tipos de dato vector.

**Importante**
Lo más importante de un vector que cuando se pasa como parámetro a una función no se hace una copia como sucede con los tipos de dato char, int y float sino se pasa la dirección de memoria donde se almacena el vector original.

Esta forma de pasaje de datos tipo vector hace que si modificamos el parámetro dentro de la función lo que sucede es que se modifica la variable definida en la función main o donde se haya definido.
