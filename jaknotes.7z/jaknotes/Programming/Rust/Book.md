# Getting started
Cargo does not watch your files by default. But you can use plugins like [cargo-watch](https://crates.io/crates/cargo-watch) for this purpose.

| Option        | Description            |
| ------------- | ---------------------- |
| `cargo new`   | Create a project       |
| `cargo build` | Build a project        |
| `cargo run`   | Build an run a project |
| `cargo check` | Build a project without producing a binary to check for errors                       |
Instead of saving the result of the build in the same directory as our code, Cargo stores it in the target/debug directory.
# Common programming concepts
## Keywords
The Rust language has a set of keywords that are reserved for use by the language only, much as in other languages. Keep in mind that you cannot use these words as names of variables or functions. Most of the keywords have special meanings, and you’ll be using them to do various tasks in your Rust programs; a few have no current functionality associated with them but have been reserved for functionality that might be added to Rust in the future. You can find a list of the keywords in [Appendix A](https://rust-book.cs.brown.edu/appendix-01-keywords.html)
## Variables and mutability
Variables are immutable. However, you still have the option to make your variables mutable.When a variable is immutable, once a value is bound to a name, you can’t change that value. To illustrate this, generate a new project called variables in your projects directory by using cargo new variables
```rust
fn main() {
    let x = 5;
    println!("The value of x is: {x}");
    x = 6;
    println!("The value of x is: {x}");
}
```
This results in _error_.
Although variables are immutable by default, you can make them mutable by adding mut in front of the variable name. Adding `mut` also conveys intent to future readers of the code by indicating that other parts of the code will be changing this variable’s value
```rust
fn main() {
    let mut x = 5;
    println!("The value of x is: {x}");
    x = 6;
    println!("The value of x is: {x}");
}

$ cargo run
   Compiling variables v0.1.0 (file:///projects/variables)
    Finished dev [unoptimized + debuginfo] target(s) in 0.30s
     Running `target/debug/variables`
The value of x is: 5
The value of x is: 6
```
## Constants
First, you aren’t allowed to use mut with constants. Constants aren’t just immutable by default—they’re always immutable. You declare constants using the const keyword instead of the let keyword, and the type of the value must be annotated. 