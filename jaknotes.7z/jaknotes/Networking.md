# Basics VPN

At a high-level, VPN works by routing our connecting device's internet connection through the target VPN's private server instead of our internet service provider (ISP). **When connected to a VPN, data originates from the VPN server rather than our computer and will appear to originate from a public IP address other than our own**.

VPN uses cryptogrpahy to extend a private network over a public one, like the Internet. When you are connected via VPN, you are actually running the same protocols of the private network. _This lets you perform even low-level network operations (i.e. Wireshark)_

There are two main types of remote access VPNs:  
1. Client-based VPN: Client-based VPN requires the use of client software to establish the VPN connection. Once connected, _the user's host will work mostly as if it were connected directly to the company network and will be able to access any resources (applications, hosts, subnets, etc.) allowed by the server configuration_. Some corporate VPNs will provide employees with full access to the internal corporate network, while others will place users on a specific segment reserved for remote workers.  
2. SSL VPN: SSL VPN uses the web browser as the VPN client. The connection is established between the browser and an SSL VPN gateway can be configured to only allow access to web-based applications such as email and intranet sites, or even the internal network but _without the need for the end user to install or use any specialized software_.

# Hexadecimal arithmetic
In order to distinguish them from decimal numbers, we add `0x` at the beginning or `h` at the end
# Layer 2
## Encapsulation 
If every protocol has a header and a payload, how can a protocol use the one on its lowe layer? The entire upper protocol packet(header plus payload) is the payload of the lower one; this is called encapsulation
## Frames
Layer 2 packets ==> frames
## What is the CAM?
The CAM (Content Addressable Memory) table is stored in the device's RAM and is constantly refreshed with new information
## Check arp
* Linux
```bash
ip neighbour
```
* Windows
```powershell
arp -a 
```
* MAC 
```bash
arp
```
# Layer 3
IP packets are called datagrams. IP runs on the Internet layer. _Routers do not forward packets coming from one interface if they have ff:ff:ff:ff:ff:ff broadcast MAC address_.
## IPv6
There are prefixes instead of subnets blocks
* Reserved addresses => IPv4 mapped addresses
	* ::1/128 is a loopback address 
	* ::FFFF:0:0/96 
### Principal components
64 bits [network part] : 64 bits [device part]
48 bits ==> global unicast address ==> Global ones and reside in global internet. This are for Internet global addressing.
16 bits ==> subnet id. Used for defining subnets

Unique local and link local ==> Reside only in internal networks
	* Unique local ==> Scope internal network or VPN - Internally routable but not routed on Internet
	* Link Local ==> Scope network link - Not routed internally or externally
## Check opened ports
* Linux
`netstat -tunp` 
`lsof -n i4tcp -i4udp
* Windows
`netstat -ano`
`netstat -p tcp`
`netstat -p udp`
_Tcpview_ from sysinternals
## Check routes
* Linux
`ip route`
* Windows
`route print`
* Mac
`netstat -r`
## Add routes
`route add -net 192.168.222.0 netmask 255.255.255.0 gw 10.175.34.1`
`ip route add 192.168.222.0/24 via 10.175.34.1`
## Check ip
* Linux
`ip addr`
* Windows
`ipconfig /all`
* Mac 
`ifconfig`

# Layer 7
## DNS
### Interesting info
1. [DNS](https://wiki.archlinux.org/title/Domain_name_resolution)
2. [DNS-over-TLS Vs. DNS-over-HTTPS](https://www.dnsfilter.com/blog/dns-over-tls)
3. [What are zone transfers in DNS](https://digi.ninja/projects/zonetransferme.php)