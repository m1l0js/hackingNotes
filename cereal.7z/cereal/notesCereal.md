cat targeted       
# Nmap 7.94 scan initiated Tue Jul 11 13:06:00 2023 as: nmap -sCV -n -vvv -p 21,22,80,139,445,3306,11111,22222,22223,33333,33334,44441,44444,55551,55555 -oN targeted 192.168.0.116
Nmap scan report for 192.168.0.116
Host is up, received syn-ack (0.00044s latency).
Scanned at 2023-07-11 13:06:00 BST for 298s

PORT      STATE SERVICE         REASON  VERSION
21/tcp    open  ftp             syn-ack vsftpd 3.0.3
| ftp-anon: Anonymous FTP login allowed (FTP code 230)
|_drwxr-xr-x    2 0        0               6 Apr 12  2021 pub
| ftp-syst: 
|   STAT: 
| FTP server status:
|      Connected to ::ffff:192.168.0.111
|      Logged in as ftp
|      TYPE: ASCII
|      No session bandwidth limit
|      Session timeout in seconds is 300
|      Control connection is plain text
|      Data connections will be plain text
|      At session startup, client count was 1
|      vsFTPd 3.0.3 - secure, fast, stable
|_End of status
22/tcp    open  ssh             syn-ack OpenSSH 8.0 (protocol 2.0)
| ssh-hostkey: 
|   3072 00:24:2b:ae:41:ba:ac:52:d1:5d:4f:ad:00:ce:39:67 (RSA)
| ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC1YeWXB5by9kXGB7MuGgw5mQ0+E1oj2buX5ReuNg7llxWF88qnGPVL3w+IAKBtFVf+WBtHs49AndSFp7zKFfgCbEvZ8GiBP9/EZvRFPiZ/nuvhsOgJKrtDdPPtdrUpaT7H21bu0c7zUk6H5QH6Ut8U4ekGOEFj41ofG6iypewjowyk2I93Tdx10oiyTYHzYb20S7PsfZpLccEoOqL7QmWTxwzcHEqcerpw4lB3WqGAe/PvQIuvMUe9wGahi5nhaFeTA/VEWcXldQeWecZTkhcBo5gaJJcFnyN1ipCSDBhanMK0J4k6BxvEX6DKxMiyRuMVVgvT+rysvJ3gIMnzP+/JHpVQHV8q5XvZj8OyWYdqHNMNf2Zq5E9jxfY1/KXOrRYHZ9Vcw5uz2x/bZR2VfUNEJDhJ31MgFhZoiL+/VfbKr+9LdrXJ7ayp9FBajwwle8zLZzbG6OdJp/BqH4emVwhLuCxMYaT/hTwKIMQs3f4R4U36OT6Md9uaK+gxVK4DwuU=
|   256 1a:e3:c7:37:52:2e:dc:dd:62:61:03:27:55:1a:86:6f (ECDSA)
| ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBBF9Am1a9LxKgFbVFzdq7u0NA7c27U+45x7ZbKcKvoPwarkpCoTzNAnL/2Zc2OQYifaqFO455pysgVpkX7F8mCA=
|   256 24:fd:e7:80:89:c5:57:fd:f3:e5:c9:2f:01:e1:6b:30 (ED25519)
|_ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIB/z2UKBK9zWIKPuHJXEkheH7z0qbtQCrL/wSb8Fu71c
80/tcp    open  http            syn-ack Apache httpd 2.4.37 (())
|_http-server-header: Apache/2.4.37 ()
| http-methods: 
|   Supported Methods: OPTIONS HEAD GET POST TRACE
|_  Potentially risky methods: TRACE
|_http-title: Apache HTTP Server Test Page powered by: Rocky Linux
139/tcp   open  netbios-ssn?    syn-ack
445/tcp   open  microsoft-ds?   syn-ack
3306/tcp  open  mysql?          syn-ack
| mysql-info: 
|_  MySQL Error: Host '192.168.0.111' is not allowed to connect to this MariaDB server
| fingerprint-strings: 
|   NULL: 
|_    Host '192.168.0.111' is not allowed to connect to this MariaDB server
11111/tcp open  vce?            syn-ack
22222/tcp open  easyengine?     syn-ack
|_ssh-hostkey: ERROR: Script execution failed (use -d to debug)
22223/tcp open  unknown         syn-ack
33333/tcp open  dgi-serv?       syn-ack
33334/tcp open  speedtrace?     syn-ack
44441/tcp open  http            syn-ack Apache httpd 2.4.37 (())
| http-methods: 
|   Supported Methods: OPTIONS HEAD GET POST TRACE
|_  Potentially risky methods: TRACE
|_http-server-header: Apache/2.4.37 ()
|_http-title: Site doesn't have a title (text/html; charset=UTF-8).
44444/tcp open  cognex-dataman? syn-ack
55551/tcp open  unknown         syn-ack
55555/tcp open  unknown         syn-ack
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port3306-TCP:V=7.94%I=7%D=7/11%Time=64AD45A8%P=x86_64-pc-linux-gnu%r(NU
SF:LL,4C,"H\0\0\x01\xffj\x04Host\x20'192\.168\.0\.111'\x20is\x20not\x20all
SF:owed\x20to\x20connect\x20to\x20this\x20MariaDB\x20server");
Service Info: OS: Unix

Host script results:
| p2p-conficker: 
|   Checking for Conficker.C or higher...
|   Check 1 (port 38950/tcp): CLEAN (Couldn't connect)
|   Check 2 (port 65368/tcp): CLEAN (Couldn't connect)
|   Check 3 (port 38179/udp): CLEAN (Failed to receive data)
|   Check 4 (port 42879/udp): CLEAN (Timeout)
|_  0/4 checks are positive: Host is CLEAN or ports are blocked
|_smb2-time: Protocol negotiation failed (SMB2)
|_smb2-security-mode: Couldn't establish a SMBv2 connection.

Read data files from: /usr/bin/../share/nmap
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Tue Jul 11 13:10:58 2023 -- 1 IP address (1 host up) scanned in 298.39 seconds
                                                                                             ┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ gobuster dir -u http://192.168.0.116:80/ -w /usr/share/seclists/Discovery/Web-Content/directory-list-2.3-medium.txt   
===============================================================
Gobuster v3.5
by OJ Reeves (@TheColonial) & Christian Mehlmauer (@firefart)
===============================================================
[+] Url:                     http://192.168.0.116:80/
[+] Method:                  GET
[+] Threads:                 10
[+] Wordlist:                /usr/share/seclists/Discovery/Web-Content/directory-list-2.3-medium.txt
[+] Negative Status codes:   404
[+] User Agent:              gobuster/3.5
[+] Timeout:                 10s
===============================================================
2023/07/11 13:15:28 Starting gobuster in directory enumeration mode
===============================================================
/blog                 (Status: 301) [Size: 234] [--> http://192.168.0.116/blog/]
/admin                (Status: 301) [Size: 235] [--> http://192.168.0.116/admin/]
Progress: 8047 / 220561 (3.65%)^C
[!] Keyboard interrupt detected, terminating.

===============================================================
2023/07/11 13:15:30 Finished
===============================================================
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ whatweb http://192.168.0.116/blog/                     
http://192.168.0.116/blog/ [200 OK] Apache[2.4.37], Country[RESERVED][ZZ], HTML5, HTTPServer[Apache/2.4.37 ()], IP[192.168.0.116], MetaGenerator[WordPress 6.2.2], PHP[7.2.24], PoweredBy[--], Script, Title[Cereal], UncommonHeaders[link], WordPress[6.2.2], X-Powered-By[PHP/7.2.24]
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ gobuster dir -u http://192.168.0.116:80/ -w /usr/share/seclists/Discovery/Web-Content/directory-list-2.3-medium.txt
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ cat /etc/hosts
127.0.0.1	localhost
127.0.1.1	jakin

# The following lines are desirable for IPv6 capable hosts
::1     localhost ip6-localhost ip6-loopback
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ echo -n "192.168.0.116 cereal.ctf" >> /etc/hosts           
zsh: permission denied: /etc/hosts
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ sudo echo -n "192.168.0.116 cereal.ctf" >> /etc/hosts    
zsh: permission denied: /etc/hosts
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ sudo nvim /etc/hosts                                     
[sudo] password for user:                                                                                              
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ sudo echo -n "192.168.0.116 cereal.ctf" >> /etc/hosts
zsh: permission denied: /etc/hosts
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ sudo nvim /etc/hosts                                 
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ gobuster dir -u http://192.168.0.116:44441/ -w /usr/share/seclists/Discovery/Web-Content/directory-list-2.3-medium.txt
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ 
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ gobuster vhost -u http://cereal.ctf:44441/ -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt -t 20
===============================================================
Gobuster v3.5
by OJ Reeves (@TheColonial) & Christian Mehlmauer (@firefart)
===============================================================
[+] Url:             http://cereal.ctf:44441/
[+] Method:          GET
[+] Threads:         20
[+] Wordlist:        /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt
[+] User Agent:      gobuster/3.5
[+] Timeout:         10s
[+] Append Domain:   false
===============================================================
2023/07/11 13:20:45 Starting gobuster in VHOST enumeration mode
===============================================================
Found: 1 Status: 400 [Size: 347]
Found: 11192521404255 Status: 400 [Size: 347]
Found: 11192521403954 Status: 400 [Size: 347]
Found: gc._msdcs Status: 400 [Size: 347]
Found: 2 Status: 400 [Size: 347]
Found: 11285521401250 Status: 400 [Size: 347]
Found: 2012 Status: 400 [Size: 347]
Found: 123 Status: 400 [Size: 347]
Found: 11290521402560 Status: 400 [Size: 347]
Found: 2011 Status: 400 [Size: 347]
Found: 3 Status: 400 [Size: 347]
Found: 4 Status: 400 [Size: 347]
Found: 2013 Status: 400 [Size: 347]
Found: 2010 Status: 400 [Size: 347]
Found: 911 Status: 400 [Size: 347]
Found: 11 Status: 400 [Size: 347]
Found: 24 Status: 400 [Size: 347]
Found: 10 Status: 400 [Size: 347]
Found: 7 Status: 400 [Size: 347]
Found: 99 Status: 400 [Size: 347]
Found: 2009 Status: 400 [Size: 347]
Found: www.1 Status: 400 [Size: 347]
Found: 50 Status: 400 [Size: 347]
Found: 12 Status: 400 [Size: 347]
Found: 20 Status: 400 [Size: 347]
Found: 2008 Status: 400 [Size: 347]
Found: 25 Status: 400 [Size: 347]
Found: www.2 Status: 400 [Size: 347]
Found: 15 Status: 400 [Size: 347]
Found: 5 Status: 400 [Size: 347]Found: 13 Status: 400 [Size: 347]
Found: 100 Status: 400 [Size: 347]
Found: 44 Status: 400 [Size: 347]
Found: 54 Status: 400 [Size: 347]
Found: 9 Status: 400 [Size: 347]
Found: 70 Status: 400 [Size: 347]
Found: 01 Status: 400 [Size: 347]
Found: 16 Status: 400 [Size: 347]
Found: 39 Status: 400 [Size: 347]
Found: 6 Status: 400 [Size: 347]
Found: www.123 Status: 400 [Size: 347]

===============================================================
2023/07/11 13:20:46 Finished
===============================================================
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ gobuster vhost -u http://cereal.ctf:44441/ -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt -t 20
===============================================================
Gobuster v3.5
by OJ Reeves (@TheColonial) & Christian Mehlmauer (@firefart)
===============================================================
[+] Url:             http://cereal.ctf:44441/
[+] Method:          GET
[+] Threads:         20
[+] Wordlist:        /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt
[+] User Agent:      gobuster/3.5
[+] Timeout:         10s
[+] Append Domain:   false
===============================================================
2023/07/11 13:22:21 Starting gobuster in VHOST enumeration mode
===============================================================
Found: 1 Status: 400 [Size: 347]
Found: 11192521404255 Status: 400 [Size: 347]
Found: 11192521403954 Status: 400 [Size: 347]
Found: gc._msdcs Status: 400 [Size: 347]
Found: 2 Status: 400 [Size: 347]
Found: 11285521401250 Status: 400 [Size: 347]
Found: 2012 Status: 400 [Size: 347]
Found: 11290521402560 Status: 400 [Size: 347]
Found: 123 Status: 400 [Size: 347]
Found: 2011 Status: 400 [Size: 347]
Found: 3 Status: 400 [Size: 347]
Found: 4 Status: 400 [Size: 347]
Found: 2013 Status: 400 [Size: 347]
Found: 2010 Status: 400 [Size: 347]
Found: 911 Status: 400 [Size: 347]
Found: 11 Status: 400 [Size: 347]
Found: 24 Status: 400 [Size: 347]
Found: 10 Status: 400 [Size: 347]
Found: 7 Status: 400 [Size: 347]
Found: 99 Status: 400 [Size: 347]
Found: 2009 Status: 400 [Size: 347]
Found: www.1 Status: 400 [Size: 347]
Found: 50 Status: 400 [Size: 347]
Found: 12 Status: 400 [Size: 347]
Found: 20 Status: 400 [Size: 347]Found: 2008 Status: 400 [Size: 347]
Found: 25 Status: 400 [Size: 347]
Found: 15 Status: 400 [Size: 347]
Found: 5 Status: 400 [Size: 347]
Found: www.2 Status: 400 [Size: 347]
Found: 13 Status: 400 [Size: 347]
Found: 100 Status: 400 [Size: 347]
Found: 44 Status: 400 [Size: 347]
Found: 9 Status: 400 [Size: 347]
Found: 54 Status: 400 [Size: 347]
Found: 70 Status: 400 [Size: 347]
Found: 01 Status: 400 [Size: 347]
Found: 16 Status: 400 [Size: 347]
Found: 39 Status: 400 [Size: 347]
Found: 6 Status: 400 [Size: 347]
Found: www.123 Status: 400 [Size: 347]

===============================================================
2023/07/11 13:22:22 Finished
===============================================================
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ gobuster vhost -u http://cereal.ctf:44441/ -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt      
===============================================================
Gobuster v3.5
by OJ Reeves (@TheColonial) & Christian Mehlmauer (@firefart)
===============================================================
[+] Url:             http://cereal.ctf:44441/
[+] Method:          GET
[+] Threads:         10
[+] Wordlist:        /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt
[+] User Agent:      gobuster/3.5
[+] Timeout:         10s
[+] Append Domain:   false
===============================================================
2023/07/11 13:24:02 Starting gobuster in VHOST enumeration mode
===============================================================
Found: 1 Status: 400 [Size: 347]
Found: 11192521404255 Status: 400 [Size: 347]
Found: 11192521403954 Status: 400 [Size: 347]
Found: gc._msdcs Status: 400 [Size: 347]
Found: 2 Status: 400 [Size: 347]
Found: 11285521401250 Status: 400 [Size: 347]
Found: 2012 Status: 400 [Size: 347]
Found: 11290521402560 Status: 400 [Size: 347]
Found: 123 Status: 400 [Size: 347]
Found: 2011 Status: 400 [Size: 347]
Found: 3 Status: 400 [Size: 347]
Found: 4 Status: 400 [Size: 347]
Found: 2013 Status: 400 [Size: 347]
Found: 2010 Status: 400 [Size: 347]
Found: 911 Status: 400 [Size: 347]
Found: 11 Status: 400 [Size: 347]
Found: 24 Status: 400 [Size: 347]
Found: 10 Status: 400 [Size: 347]
Found: 7 Status: 400 [Size: 347]
Found: 99 Status: 400 [Size: 347]
Found: 2009 Status: 400 [Size: 347]
Found: www.1 Status: 400 [Size: 347]Found: 50 Status: 400 [Size: 347]
Found: 12 Status: 400 [Size: 347]
Found: 20 Status: 400 [Size: 347]
Found: 2008 Status: 400 [Size: 347]
Found: 25 Status: 400 [Size: 347]
Found: 5 Status: 400 [Size: 347]
Found: 15 Status: 400 [Size: 347]
Found: www.2 Status: 400 [Size: 347]
Found: 13 Status: 400 [Size: 347]
Found: 100 Status: 400 [Size: 347]
Found: 44 Status: 400 [Size: 347]
Found: 54 Status: 400 [Size: 347]
Found: 9 Status: 400 [Size: 347]
Found: 70 Status: 400 [Size: 347]
Found: 01 Status: 400 [Size: 347]
Found: 16 Status: 400 [Size: 347]
Found: 39 Status: 400 [Size: 347]
Found: 6 Status: 400 [Size: 347]
Found: www.123 Status: 400 [Size: 347]

===============================================================
2023/07/11 13:24:02 Finished
===============================================================
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ grep "secure" /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt
secure
www.secure
secure2
securemail
autodiscover.secure
webdisk.secure
autoconfig.secure
secure1
secure3
secure4
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ gobuster vhost -u http://cereal.ctf:44441/ -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-20000.txt 
===============================================================
Gobuster v3.5
by OJ Reeves (@TheColonial) & Christian Mehlmauer (@firefart)
===============================================================
[+] Url:             http://cereal.ctf:44441/
[+] Method:          GET
[+] Threads:         10
[+] Wordlist:        /usr/share/seclists/Discovery/DNS/subdomains-top1million-20000.txt
[+] User Agent:      gobuster/3.5
[+] Timeout:         10s
[+] Append Domain:   false
===============================================================
2023/07/11 13:24:54 Starting gobuster in VHOST enumeration mode
===============================================================
Found: 1 Status: 400 [Size: 347]
Found: 11192521404255 Status: 400 [Size: 347]
Found: 11192521403954 Status: 400 [Size: 347]
Found: gc._msdcs Status: 400 [Size: 347]Found: 2 Status: 400 [Size: 347]
Found: 11285521401250 Status: 400 [Size: 347]
Found: 2012 Status: 400 [Size: 347]
Found: 11290521402560 Status: 400 [Size: 347]
Found: 123 Status: 400 [Size: 347]
Found: 2011 Status: 400 [Size: 347]
Found: 3 Status: 400 [Size: 347]
Found: 4 Status: 400 [Size: 347]
Found: 2013 Status: 400 [Size: 347]
Found: 2010 Status: 400 [Size: 347]
Found: 911 Status: 400 [Size: 347]
Found: 11 Status: 400 [Size: 347]
Found: 24 Status: 400 [Size: 347]
Found: 10 Status: 400 [Size: 347]
Found: 7 Status: 400 [Size: 347]
Found: 99 Status: 400 [Size: 347]
Found: 2009 Status: 400 [Size: 347]
Found: www.1 Status: 400 [Size: 347]
Found: 50 Status: 400 [Size: 347]
Found: 12 Status: 400 [Size: 347]
Found: 20 Status: 400 [Size: 347]
Found: 2008 Status: 400 [Size: 347]
Found: 25 Status: 400 [Size: 347]
Found: 15 Status: 400 [Size: 347]
Found: 5 Status: 400 [Size: 347]
Found: www.2 Status: 400 [Size: 347]
Found: 13 Status: 400 [Size: 347]
Found: 100 Status: 400 [Size: 347]
Found: 44 Status: 400 [Size: 347]
Found: 54 Status: 400 [Size: 347]
Found: 9 Status: 400 [Size: 347]
Found: 70 Status: 400 [Size: 347]
Found: 01 Status: 400 [Size: 347]
Found: 16 Status: 400 [Size: 347]
Found: 39 Status: 400 [Size: 347]
Found: 6 Status: 400 [Size: 347]
Found: www.123 Status: 400 [Size: 347]
Found: 88 Status: 400 [Size: 347]
Found: 21 Status: 400 [Size: 347]
Found: 17 Status: 400 [Size: 347]
Found: 14 Status: 400 [Size: 347]
Found: 18 Status: 400 [Size: 347]
Found: 37 Status: 400 [Size: 347]
Found: 1234 Status: 400 [Size: 347]
Found: 79 Status: 400 [Size: 347]
Found: 35 Status: 400 [Size: 347]
Found: 49 Status: 400 [Size: 347]
Found: 114 Status: 400 [Size: 347]
Found: 29 Status: 400 [Size: 347]
Found: 8 Status: 400 [Size: 347]
Found: 0 Status: 400 [Size: 347]
Found: 19 Status: 400 [Size: 347]
Found: 1000 Status: 400 [Size: 347]
Found: 48 Status: 400 [Size: 347]
Found: 34 Status: 400 [Size: 347]
Found: 46 Status: 400 [Size: 347]
Found: 51 Status: 400 [Size: 347]
Found: 27 Status: 400 [Size: 347]
Found: 60 Status: 400 [Size: 347]
Found: 26 Status: 400 [Size: 347]
Found: 22 Status: 400 [Size: 347]
Found: 90 Status: 400 [Size: 347]
Found: 80 Status: 400 [Size: 347]
Found: 23 Status: 400 [Size: 347]Found: 31 Status: 400 [Size: 347]
Found: 66 Status: 400 [Size: 347]
Found: 67 Status: 400 [Size: 347]
Found: 40 Status: 400 [Size: 347]
Found: 53 Status: 400 [Size: 347]
Found: 52 Status: 400 [Size: 347]
Found: mail.99 Status: 400 [Size: 347]
Found: www.2012 Status: 400 [Size: 347]
Found: 112 Status: 400 [Size: 347]
Found: 42 Status: 400 [Size: 347]
Found: 45 Status: 400 [Size: 347]
Found: 47 Status: 400 [Size: 347]
Found: 61 Status: 400 [Size: 347]
Found: 69 Status: 400 [Size: 347]
Found: 77 Status: 400 [Size: 347]
Found: 32 Status: 400 [Size: 347]
Found: 360 Status: 400 [Size: 347]
Found: 57 Status: 400 [Size: 347]
Found: 63 Status: 400 [Size: 347]
Found: 30 Status: 400 [Size: 347]
Found: 76 Status: 400 [Size: 347]
Found: www.24 Status: 400 [Size: 347]
Found: 94 Status: 400 [Size: 347]
Found: 64 Status: 400 [Size: 347]
Found: 111 Status: 400 [Size: 347]
Found: 28 Status: 400 [Size: 347]
Found: 33 Status: 400 [Size: 347]
Found: 41 Status: 400 [Size: 347]
Found: 101 Status: 400 [Size: 347]
Found: 163 Status: 400 [Size: 347]
Found: 203 Status: 400 [Size: 347]
Found: 666 Status: 400 [Size: 347]
Found: 365 Status: 400 [Size: 347]
Found: www.2011 Status: 400 [Size: 347]
Found: www.11 Status: 400 [Size: 347]
Found: 777 Status: 400 [Size: 347]
Found: 12345 Status: 400 [Size: 347]
Found: 132 Status: 400 [Size: 347]
Found: mail.85st Status: 400 [Size: 347]
Found: 43 Status: 400 [Size: 347]
Found: 120 Status: 400 [Size: 347]
Found: 65 Status: 400 [Size: 347]
Found: www.4 Status: 400 [Size: 347]
Found: www.3 Status: 400 [Size: 347]
Found: 87 Status: 400 [Size: 347]
Found: 91 Status: 400 [Size: 347]
Found: 89 Status: 400 [Size: 347]
Found: 71 Status: 400 [Size: 347]
Found: 58 Status: 400 [Size: 347]
Found: www.16 Status: 400 [Size: 347]
Found: 56 Status: 400 [Size: 347]
Found: 55 Status: 400 [Size: 347]
Found: 204 Status: 400 [Size: 347]
Found: www.10 Status: 400 [Size: 347]
Found: 103 Status: 400 [Size: 347]
Found: www.2013 Status: 400 [Size: 347]
Found: 110 Status: 400 [Size: 347]
Found: 404 Status: 400 [Size: 347]
Found: www.15 Status: 400 [Size: 347]
Found: 125 Status: 400 [Size: 347]Found: 123456 Status: 400 [Size: 347]
Found: 86 Status: 400 [Size: 347]
Found: 81 Status: 400 [Size: 347]
Found: 75 Status: 400 [Size: 347]
Found: 74 Status: 400 [Size: 347]
Found: 68 Status: 400 [Size: 347]
Found: 62 Status: 400 [Size: 347]
Found: 96 Status: 400 [Size: 347]
Found: www.13 Status: 400 [Size: 347]
Found: www.20 Status: 400 [Size: 347]
Found: www.12 Status: 400 [Size: 347]
Found: 02 Status: 400 [Size: 347]
Found: www.9 Status: 400 [Size: 347]
Found: 222 Status: 400 [Size: 347]
Found: mail.8591 Status: 400 [Size: 347]
Found: mail.77p2p Status: 400 [Size: 347]
Found: 8591 Status: 400 [Size: 347]
Found: 5278 Status: 400 [Size: 347]
Found: mail.5278 Status: 400 [Size: 347]
Found: 228 Status: 400 [Size: 347]
Found: mail.85cc Status: 400 [Size: 347]
Found: www.7 Status: 400 [Size: 347]
Found: 109 Status: 400 [Size: 347]
Found: 129 Status: 400 [Size: 347]
Found: 128 Status: 400 [Size: 347]
Found: 105 Status: 400 [Size: 347]
Found: 118 Status: 400 [Size: 347]
Found: 119 Status: 400 [Size: 347]
Found: 212 Status: 400 [Size: 347]
Found: 121 Status: 400 [Size: 347]
Found: 126 Status: 400 [Size: 347]
Found: 000 Status: 400 [Size: 347]
Found: 106 Status: 400 [Size: 347]
Found: 11091521400593 Status: 400 [Size: 347]
Found: 230 Status: 400 [Size: 347]
Found: 234 Status: 400 [Size: 347]
Found: 080 Status: 400 [Size: 347]
Found: 233 Status: 400 [Size: 347]
Found: 170 Status: 400 [Size: 347]
Found: www.19 Status: 400 [Size: 347]
Found: www.25 Status: 400 [Size: 347]
Found: 93 Status: 400 [Size: 347]
Found: www.18 Status: 400 [Size: 347]
Found: www.17 Status: 400 [Size: 347]
Found: 97 Status: 400 [Size: 347]
Found: 59 Status: 400 [Size: 347]
Found: 95 Status: 400 [Size: 347]
Found: 72 Status: 400 [Size: 347]
Found: 36 Status: 400 [Size: 347]
Found: 92 Status: 400 [Size: 347]
Found: 73 Status: 400 [Size: 347]
Found: 03 Status: 400 [Size: 347]
Found: 38 Status: 400 [Size: 347]
Found: 205 Status: 400 [Size: 347]
Found: mail.666av Status: 400 [Size: 347]
Found: mail.080 Status: 400 [Size: 347]
Found: 1111 Status: 400 [Size: 347]
Found: 235 Status: 400 [Size: 347]Found: www.2010 Status: 400 [Size: 347]
Found: 211 Status: 400 [Size: 347]
Found: 192 Status: 400 [Size: 347]
Found: 2006 Status: 400 [Size: 347]
Found: 209 Status: 400 [Size: 347]
Found: 117 Status: 400 [Size: 347]
Found: 130 Status: 400 [Size: 347]
Found: 007 Status: 400 [Size: 347]
Found: 137 Status: 400 [Size: 347]
Found: www.6 Status: 400 [Size: 347]
Found: www.5 Status: 400 [Size: 347]
Found: www.14 Status: 400 [Size: 347]
Found: 169 Status: 400 [Size: 347]
Found: 237 Status: 400 [Size: 347]
Found: 162 Status: 400 [Size: 347]
Found: 131 Status: 400 [Size: 347]
Found: 134 Status: 400 [Size: 347]

===============================================================
2023/07/11 13:24:57 Finished
===============================================================
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ gobuster vhost -u http://cereal.ctf:44441/ -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-20000.txt -t 20
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ 
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ls
allPorts  images  notesCereal.md  targeted
                                                                                             
┌──(user㉿jakin)-[~/Documents/testing/cereal]
└─$ cat targeted  
# Nmap 7.94 scan initiated Tue Jul 11 13:06:00 2023 as: nmap -sCV -n -vvv -p 21,22,80,139,445,3306,11111,22222,22223,33333,33334,44441,44444,55551,55555 -oN targeted 192.168.0.116
Nmap scan report for 192.168.0.116
Host is up, received syn-ack (0.00044s latency).
Scanned at 2023-07-11 13:06:00 BST for 298s

PORT      STATE SERVICE         REASON  VERSION
21/tcp    open  ftp             syn-ack vsftpd 3.0.3
| ftp-anon: Anonymous FTP login allowed (FTP code 230)
|_drwxr-xr-x    2 0        0               6 Apr 12  2021 pub
| ftp-syst: 
|   STAT: 
| FTP server status:
|      Connected to ::ffff:192.168.0.111
|      Logged in as ftp
|      TYPE: ASCII
|      No session bandwidth limit
|      Session timeout in seconds is 300
|      Control connection is plain text
|      Data connections will be plain text
|      At session startup, client count was 1
|      vsFTPd 3.0.3 - secure, fast, stable
|_End of status
22/tcp    open  ssh             syn-ack OpenSSH 8.0 (protocol 2.0)
| ssh-hostkey: 
|   3072 00:24:2b:ae:41:ba:ac:52:d1:5d:4f:ad:00:ce:39:67 (RSA)
| ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC1YeWXB5by9kXGB7MuGgw5mQ0+E1oj2buX5ReuNg7llxWF88qnGPVL3w+IAKBtFVf+WBtHs49AndSFp7zKFfgCbEvZ8GiBP9/EZvRFPiZ/nuvhsOgJKrtDdPPtdrUpaT7H21bu0c7zUk6H5QH6Ut8U4ekGOEFj41ofG6iypewjowyk2I93Tdx10oiyTYHzYb20S7PsfZpLccEoOqL7QmWTxwzcHEqcerpw4lB3WqGAe/PvQIuvMUe9wGahi5nhaFeTA/VEWcXldQeWecZTkhcBo5gaJJcFnyN1ipCSDBhanMK0J4k6BxvEX6DKxMiyRuMVVgvT+rysvJ3gIMnzP+/JHpVQHV8q5XvZj8OyWYdqHNMNf2Zq5E9jxfY1/KXOrRYHZ9Vcw5uz2x/bZR2VfUNEJDhJ31MgFhZoiL+/VfbKr+9LdrXJ7ayp9FBajwwle8zLZzbG6OdJp/BqH4emVwhLuCxMYaT/hTwKIMQs3f4R4U36OT6Md9uaK+gxVK4DwuU=
|   256 1a:e3:c7:37:52:2e:dc:dd:62:61:03:27:55:1a:86:6f (ECDSA)
| ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBBF9Am1a9LxKgFbVFzdq7u0NA7c27U+45x7ZbKcKvoPwarkpCoTzNAnL/2Zc2OQYifaqFO455pysgVpkX7F8mCA=
|   256 24:fd:e7:80:89:c5:57:fd:f3:e5:c9:2f:01:e1:6b:30 (ED25519)
|_ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIB/z2UKBK9zWIKPuHJXEkheH7z0qbtQCrL/wSb8Fu71c
80/tcp    open  http            syn-ack Apache httpd 2.4.37 (())
|_http-server-header: Apache/2.4.37 ()
| http-methods: 
|   Supported Methods: OPTIONS HEAD GET POST TRACE
|_  Potentially risky methods: TRACE
|_http-title: Apache HTTP Server Test Page powered by: Rocky Linux
139/tcp   open  netbios-ssn?    syn-ack
445/tcp   open  microsoft-ds?   syn-ack
3306/tcp  open  mysql?          syn-ack
| mysql-info: 
|_  MySQL Error: Host '192.168.0.111' is not allowed to connect to this MariaDB server
| fingerprint-strings: 
|   NULL: 
|_    Host '192.168.0.111' is not allowed to connect to this MariaDB server
11111/tcp open  vce?            syn-ack
22222/tcp open  easyengine?     syn-ack
|_ssh-hostkey: ERROR: Script execution failed (use -d to debug)
22223/tcp open  unknown         syn-ack
33333/tcp open  dgi-serv?       syn-ack
33334/tcp open  speedtrace?     syn-ack
44441/tcp open  http            syn-ack Apache httpd 2.4.37 (())
| http-methods: 
|   Supported Methods: OPTIONS HEAD GET POST TRACE
|_  Potentially risky methods: TRACE
|_http-server-header: Apache/2.4.37 ()
|_http-title: Site doesn't have a title (text/html; charset=UTF-8).
44444/tcp open  cognex-dataman? syn-ack
55551/tcp open  unknown         syn-ack
55555/tcp open  unknown         syn-ack
1 service unrecognized despite returning data. If you know the service/version, please submit the following fingerprint at https://nmap.org/cgi-bin/submit.cgi?new-service :
SF-Port3306-TCP:V=7.94%I=7%D=7/11%Time=64AD45A8%P=x86_64-pc-linux-gnu%r(NU
SF:LL,4C,"H\0\0\x01\xffj\x04Host\x20'192\.168\.0\.111'\x20is\x20not\x20all
SF:owed\x20to\x20connect\x20to\x20this\x20MariaDB\x20server");
Service Info: OS: Unix

Host script results:
| p2p-conficker: 
|   Checking for Conficker.C or higher...
|   Check 1 (port 38950/tcp): CLEAN (Couldn't connect)
|   Check 2 (port 65368/tcp): CLEAN (Couldn't connect)
|   Check 3 (port 38179/udp): CLEAN (Failed to receive data)
|   Check 4 (port 42879/udp): CLEAN (Timeout)
|_  0/4 checks are positive: Host is CLEAN or ports are blocked
|_smb2-time: Protocol negotiation failed (SMB2)
|_smb2-security-mode: Couldn't establish a SMBv2 connection.

Read data files from: /usr/bin/../share/nmap
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Tue Jul 11 13:10:58 2023 -- 1 IP address (1 host up) scanned in 298.39 seconds
                                                                                             